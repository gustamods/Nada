import json

def audit(symbol_path,data,start):
 sy=json.load(open(symbol_path))['symbols'];results=[]
 for e in data['externs'][start:]:
  aq=data['types'][e['type']].split(',');name=aq[0];dll=aq[1].strip()+'.dll'
  methods=sy.get(dll,{}).get(name)
  if methods is None:raise ValueError('type not confirmed in dump: '+name+' / '+dll)
  found=[m for m in methods if m['name']==e['name'] and m['argc']==len(e['args'])]
  if not found:raise ValueError('method not confirmed in dump: '+name+'.'+e['name'])
  results.append(name+'.'+found[0]['declaration'])
 # Enum and value types referenced by the new extern methods must also be present.
 for aq in data['types'][34:]:
  x=aq.split(',');assert x[0] in sy.get(x[1].strip()+'.dll',{}),aq
 return results
