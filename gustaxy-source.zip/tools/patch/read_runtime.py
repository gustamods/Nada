import dnfile,struct,pathlib

def read_opcodes(dll):
 pe=dnfile.dnPE(str(dll),clr_lazy_load=True)
 const={c.Parent.row_index:c for c in pe.net.mdtables.Constant if c.Parent.table is pe.net.mdtables.Field}
 types=pe.net.mdtables.TypeDef
 code=next(t for t in types if str(t.TypeNamespace)=='IFix.Core' and str(t.TypeName)=='Code')
 ops={}
 for f in code.FieldList:
  c=const.get(f.row_index)
  if c:ops[struct.unpack('<i',c.Value.value)[0]]=str(f.row.Name)
 instruction=next(t for t in types if str(t.TypeNamespace)=='IFix.Core' and str(t.TypeName)=='Instruction')
 f=next(f for f in instruction.FieldList if str(f.row.Name)=='INSTRUCTION_FORMAT_MAGIC')
 magic=struct.unpack('<Q',const[f.row_index].Value.value)[0]
 return ops,magic

def audit_externs(refs,data,original_extern_count):
 loaded={};results=[]
 for e in data['externs'][original_extern_count:]:
  aq=data['types'][e['type']].split(',');full=aq[0];asm=aq[1].strip()
  if asm not in loaded:loaded[asm]=dnfile.dnPE(str(pathlib.Path(refs)/(asm+'.dll')),clr_lazy_load=True)
  pe=loaded[asm];namespace,_,name=full.rpartition('.')
  t=next((t for t in pe.net.mdtables.TypeDef if str(t.TypeNamespace)==namespace and str(t.TypeName)==name),None)
  if t is None:raise ValueError('Missing runtime type '+full)
  found=[]
  for m in t.MethodList:
   r=m.row
   if str(r.Name)==e['name']:
    sig=r.Signature.value
    # None of the added externs is generic; signature byte then compressed param count.
    argc=sig[1]
    if argc==len(e['args']):found.append(r)
  if not found:raise ValueError('Missing signature '+full+'.'+e['name']+'/'+str(len(e['args'])))
  results.append(full+'.'+e['name']+'/'+str(len(e['args'])))
 return results
