#!/usr/bin/env python3
"""Reproducible, fail-closed IFix-template assembler and bundle packager.
Builds two ACTUAL modified bundles. Does not claim a device/runtime test.
"""
import argparse,pathlib,json,zipfile,hashlib,shutil,struct
import UnityPy
from patch_format import decode,encode
from read_runtime import read_opcodes
from assemble_visuals import build,BRANCHES
from validate_symbols import audit
from simulate_visuals import test

def sha(b):return hashlib.sha256(b).hexdigest()
def text_asset(env):
 objects=[o for o in env.objects if o.type.name=='TextAsset'];assert len(objects)==1
 o=objects[0];d=o.read();s=d.m_Script
 return o,d,s.encode('utf8','surrogateescape') if isinstance(s,str) else bytes(s)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',default='.');ap.add_argument('--output',default='build-output');args=ap.parse_args()
 root=pathlib.Path(args.root).resolve();out=root/args.output;out.mkdir(exist_ok=True,parents=True)
 tool=pathlib.Path(__file__).parent;inputs=root/'patch_inputs'
 manifest=json.loads((inputs/'input-hashes.json').read_text())
 for file,digest in manifest.items():assert sha((inputs/file).read_bytes())==digest,'input altered: '+file
 refs=out/'refs';refs.mkdir(exist_ok=True)
 with zipfile.ZipFile(inputs/'DummyDll.zip') as z:
  # Only one small metadata DLL is necessary; no C# stubs or huge SDK downloads.
  key='DummyDll/IFix.Core.dll';(refs/'IFix.Core.dll').write_bytes(z.read(key))
 ops,magic=read_opcodes(refs/'IFix.Core.dll')
 template=inputs/'template.bundle';env=UnityPy.load(str(template));_,_,raw=text_asset(env)
 original=decode(raw);assert encode(original)==raw,'non-lossless input parser'
 assert original['magic']==magic,'dump and template have different instruction formats'
 assert len(original['methods'])==2 and len(original['externs'])==58
 original_name=manifest['bundle_filename'] if 'bundle_filename' in manifest else (inputs/'bundle-filename.txt').read_text().strip()
 reports=[]
 for variant,enabled in [('somente-cor',False),('nome-animado',True)]:
  data,report,block=build(original,ops,name_enabled=enabled)
  report['api_signatures_confirmed_in_dump']=audit(inputs/'api_symbols.json',data,len(original['externs']))
  if block:report['mock_tests']=test(block,data,ops)
  # Every original relative branch must remain in the code range.
  for method in data['methods']:
   for i,(op,v) in enumerate(method['code']):
    assert op in ops,'unknown opcode'
    if ops[op] in BRANCHES:assert 0<=i+v<len(method['code']),'invalid branch target'
  payload=encode(data);assert decode(payload)==data
  assert data['tail']==original['tail'],'private target bindings changed'
  e=UnityPy.load(str(template));obj,asset,_=text_asset(e)
  asset.m_Script=payload.decode('utf8','surrogateescape');asset.save()
  bundle=e.file.save(packer='none')
  check=UnityPy.load(bundle);_,_,readback=text_asset(check);assert readback==payload,'bundle readback mismatch'
  dest=out/variant;dest.mkdir(exist_ok=True)
  (dest/original_name).write_bytes(bundle)
  # Cache identifiers are preserved exactly as in the already-tested template.
  # MD5 is NOT assumed to be the manifest's algorithm.
  shutil.copy2(inputs/'fileinfo',dest/'fileinfo')
  report.update(template_sha256=sha(template.read_bytes()),original_payload_sha256=sha(raw),
   output_payload_sha256=sha(payload),output_bundle_sha256=sha(bundle),output_bundle_bytes=len(bundle),
   original_payload_bytes=len(raw),output_payload_bytes=len(payload),
   fileinfo_policy='PRESERVED_TEMPLATE_CACHE_IDS_NOT_RECALCULATED',
   tested_on_android_device=False,roundtrip_original_lossless=True,roundtrip_modified_payload=True,
   bundle_readback_matches_payload=True,opcode_count=len(ops),private_magic=magic)
  (dest/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
  reports.append(report)
 # Put the full visual candidate into the Android project's existing asset tree.
 base=root/'app/src/main/assets/ffmax_patch/contentcache/Compulsory/android'
 if base.exists():
  target=base/'gameassetbundles/codepatch';target.mkdir(parents=True,exist_ok=True)
  for old in target.glob('assembly-csharp-patch.*'):old.unlink()
  shutil.copy2(out/'nome-animado'/original_name,target/original_name)
  shutil.copy2(inputs/'fileinfo',base/'fileinfo')
 (out/'build-summary.json').write_text(json.dumps(reports,indent=2,ensure_ascii=False)+'\n')
 print('BUILD OK: two modified UnityFS bundles, reports, preserved fileinfo.')
 print('Device rendering NOT tested; see report.json. No runtime success is asserted.')
 for p in sorted(out.glob('*/*')):
  if p.is_file() and p.parent.name!='refs':print(p.relative_to(root),p.stat().st_size)
if __name__=='__main__':main()
