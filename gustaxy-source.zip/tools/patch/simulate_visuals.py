"""Small mock execution test for ONLY the newly added visual block, not the game."""
import math,colorsys,struct
class Component(dict):
 def __bool__(self):return True
class Node:
 def __init__(self,name='node',parent=None):self.name=name;self.parent=parent;self.children={};self.components={};self.position=(0,0,0);self.rotation=(0,0,0,1)
 def __bool__(self):return True

def run(block,d,ops,existing=False,fonts=True,camera=True,team=False):
 names={int(k):v for k,v in ops.items()};root=Node('root');cg=Node('__cg',root);root.children['__cg']=cg
 head=Node('head');head.position=(0,1.75,0);player={'root':root,'head':head}
 font={'material':'font_material'};cam=Node('camera');cam.rotation=(0,1,0,0)
 if existing:
  tag=Node('__gustaxy_name',cg);tag.components['TextMesh']={'text':'GUSTAXY SAFE'};cg.children[tag.name]=tag
 stack=[];local={6:1,4:0};pc=0;steps=0;seq=block['code']
 while pc<len(seq):
  steps+=1;assert steps<2000
  op,v=seq[pc];name=names[op];nextpc=pc+1
  def pop():return stack.pop()
  if name=='Ldarg':stack.append(player)
  elif name=='Ldloc':stack.append(local.get(v))
  elif name=='Stloc':local[v]=pop()
  elif name=='Ldstr':stack.append(d['strings'][v])
  elif name=='Ldc_I4':stack.append(v)
  elif name=='Ldc_R4':stack.append(struct.unpack('<f',struct.pack('<i',v))[0])
  elif name=='Ldtype':stack.append(d['types'][v].split(',')[0].split('.')[-1])
  elif name=='Nop':pass
  elif name=='Isinst':pass
  elif name=='Ldlen':stack.append(len(pop()))
  elif name=='Conv_I4':stack.append(int(pop()))
  elif name=='Ldelem_Ref':i=pop();arr=pop();stack.append(arr[i])
  elif name=='Ldfld':vec=pop();stack.append(vec[{'x':0,'y':1,'z':2}[d['fields'][v]['name']]])
  elif name in ('Mul','Sub','Div'):
   b=pop();a=pop();stack.append(a*b if name=='Mul' else a-b if name=='Sub' else a/b)
  elif name in ('Br','Brfalse','Brtrue','Bne_Un','Ble','Blt'):
   if name=='Br':jump=True
   elif name in ('Brfalse','Brtrue'):x=pop();jump=(not bool(x)) if name=='Brfalse' else bool(x)
   else:b=pop();a=pop();jump=(a!=b if name=='Bne_Un' else a<=b if name=='Ble' else a<b)
   if jump:nextpc=pc+v
  elif name in ('CallExtern','Newobj'):
   ix=v&65535;argc=v>>16;args=stack[-argc:] if argc else []
   if argc:del stack[-argc:]
   ex=d['externs'][ix];m=ex['name'];type_name=d['types'][ex['type']].split(',')[0];ret=None
   if m=='IsLocalPlayer':ret=False
   elif m=='IsLocalTeammate':ret=team
   elif m=='get_CurHP':ret=100
   elif m=='get_RootTransform':ret=root
   elif m=='GetHeadTF':ret=head
   elif m=='get_position':ret=args[0].position
   elif m=='Find':ret=args[0].children.get(args[1])
   elif m=='.ctor' and type_name.endswith('GameObject'):ret=Node(args[0]);ret.components['Renderer']=Component()
   elif m=='.ctor' and type_name.endswith('Vector3'):ret=tuple(args)
   elif m=='get_transform':ret=args[0]
   elif m=='SetParent':child,parent,_=args;child.parent=parent;parent.children[child.name]=child
   elif m=='AddComponent':go,typ=args;ret=Component();go.components[typ]=ret
   elif m=='GetComponent':ret=args[0].components.get(args[1])
   elif m=='FindObjectsOfTypeAll':ret=[font] if fonts else []
   elif m=='get_material':ret=args[0]['material']
   elif m=='get_main':ret=cam if camera else None
   elif m=='get_rotation':ret=args[0].rotation
   elif m=='get_time':ret=9.
   elif m=='Repeat':ret=args[0]%args[1]
   elif m=='HSVToRGB':ret=colorsys.hsv_to_rgb(*args[:3])+(1.,)
   elif m=='set_localPosition':args[0].position=args[1]
   elif m=='set_rotation':args[0].rotation=args[1]
   elif m.startswith('set_'):args[0][m[4:]]=args[1]
   else:raise ValueError('unmocked '+m)
   if block['effects'][pc][1]:stack.append(ret)
  else:raise ValueError('unknown '+name)
  pc=nextpc
 assert not stack
 if team:assert '__gustaxy_name' not in cg.children
 else:
  tag=cg.children['__gustaxy_name'];tm=tag.components['TextMesh']
  assert tm['text']=='GUSTAXY SAFE';assert abs(tag.position[1]-2.38)<.001
  assert len(tm['color'])==4 and all(0<=v<=1 for v in tm['color'])
  if camera:assert tag.rotation==cam.rotation
 return steps

def test(block,d,ops):
 results=[]
 for scenario in [dict(),dict(existing=True),dict(fonts=False),dict(camera=False),dict(team=True)]:
  results.append(dict(scenario=scenario,steps=run(block,d,ops,**scenario),passed=True))
 return results
