"""Build actual IFix instructions from the template and the dump's opcode map.
No stub Assembly-CSharp is manufactured. No C# DLL is renamed as a patch.
"""
import copy,struct
from patch_format import float_i
BRANCHES={'Br','Brfalse','Brtrue','Beq','Bge','Bgt','Ble','Blt','Bne_Un','Bge_Un','Bgt_Un','Ble_Un','Blt_Un','Leave'}
def build(original,ops,text='GUSTAXY SAFE',name_enabled=True):
 d=copy.deepcopy(original);byname={v:int(k) for k,v in ops.items()};names={int(k):v for k,v in ops.items()}
 code=d['methods'][0]['code'];assert len(code)==919
 # Guarded semantic match: local Color, four floats, exact ctor and start/end setters.
 assert [names[c] for c,v in code[727:739]]==['Ldloca','Ldc_R4','Ldc_R4','Ldc_R4','Ldc_R4','CallExtern','Ldloc','Ldloc','CallExtern','Ldloc','Ldloc','CallExtern']
 assert (code[732][1]&65535)==41 and d['externs'][41]['name']=='.ctor'
 old_color=[struct.unpack('<f',struct.pack('<i',v))[0] for c,v in code[728:732]]
 assert all(abs(a-b)<0.00001 for a,b in zip(old_color,[.65,.25,1,1]))
 for i,v in enumerate([1.,1.,0.,1.]):code[728+i][1]=float_i(v)
 # No aim collider mutation. Preserve this original method's default return path.
 d['methods'][1]['code']=[[byname['StackSpace'],8],[byname['Ldc_I4'],1],[byname['Ret'],1]]
 d['methods'][1]['eh']=[]
 report={'box_before_rgba':old_color,'box_after_rgba':[1,1,0,1],'aimbot_disabled':True,'name_enabled':name_enabled,'private_tail_preserved':True}
 if not name_enabled:return d,report,None
 def typ(name,asm='UnityEngine.CoreModule'):
  aq=f'{name}, {asm}, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null'
  if aq not in d['types']:d['types'].append(aq)
  return d['types'].index(aq)
 tm=typ('UnityEngine.TextMesh','UnityEngine.TextRenderingModule');font=typ('UnityEngine.Font','UnityEngine.TextRenderingModule')
 anchor=typ('UnityEngine.TextAnchor','UnityEngine.TextRenderingModule');align=typ('UnityEngine.TextAlignment','UnityEngine.TextRenderingModule')
 camera=typ('UnityEngine.Camera');quat=typ('UnityEngine.Quaternion');resources=typ('UnityEngine.Resources')
 def ext(t,n,args,static=False,returns=True):
  key=dict(generic=False,type=t,name=n,gargs=[],args=args)
  if key not in d['externs']:d['externs'].append(key)
  ix=d['externs'].index(key);return (ix,len(args)+(0 if static else 1),returns)
 # Descriptor return information is used by the control-flow stack verifier.
 methods={
 'find':(19,2,True),'go_ctor':(23,1,True),'go_tf':(24,1,True),'set_parent':(25,3,False),
 'add':(26,2,True),'component_go':(20,1,True),'get_component':(46,2,True),
 'root':(13,1,True),'head':(14,1,True),'pos':(22,1,True),'hp':(16,1,True),
 'is_local':(17,1,True),'is_team':(18,2,True),'component_tf':(55,1,True),
 'vec_ctor':(33,3,True),'material':(39,2,False)}
 methods.update({
 'text':ext(tm,'set_text',[5],returns=False),'size':ext(tm,'set_fontSize',[3],returns=False),
 'char_size':ext(tm,'set_characterSize',[26],returns=False),'anchor':ext(tm,'set_anchor',[anchor],returns=False),
 'align':ext(tm,'set_alignment',[align],returns=False),'font':ext(tm,'set_font',[font],returns=False),
 'font_material':ext(font,'get_material',[]),'fonts':ext(resources,'FindObjectsOfTypeAll',[23],True),
 'color':ext(tm,'set_color',[1],returns=False),'localpos':ext(16,'set_localPosition',[2],returns=False),
 'cam':ext(camera,'get_main',[],True),'getrot':ext(16,'get_rotation',[]),'setrot':ext(16,'set_rotation',[quat],returns=False),
 'time':ext(6,'get_time',[],True),'repeat':ext(33,'Repeat',[26,26],True),'hsv':ext(1,'HSVToRGB',[26,26,26,9],True)})
 def string(s):
  if s not in d['strings']:d['strings'].append(s)
  return d['strings'].index(s)
 seq=[];labels={};effects={};fix=[]
 def emit(op,arg=0):seq.append([byname[op],arg]);return len(seq)-1
 def label(s):assert s not in labels;labels[s]=len(seq)
 def branch(op,to):fix.append((emit(op),to))
 def call(name,new=False):
  ix,count,ret=methods[name];p=emit('Newobj' if new else 'CallExtern',(count<<16)|ix);effects[p]=(count,1 if ret else 0)
 def f(v):emit('Ldc_R4',float_i(v))
 def s(v):emit('Ldstr',string(v))
 def load(i):emit('Ldloc',i)
 def store(i):emit('Stloc',i)
 # Only draw when the existing patch says visuals are active, on a living opponent.
 load(6);branch('Brfalse','end');load(4);emit('Ldc_I4',0);branch('Bne_Un','end')
 emit('Ldarg',0);call('is_local');branch('Brtrue','end')
 emit('Ldarg',0);call('hp');emit('Ldc_I4',0);branch('Ble','end')
 for team_arg in (0,1):emit('Ldarg',0);emit('Ldc_I4',team_arg);call('is_team');branch('Brtrue','end')
 emit('Ldarg',0);call('root');store(58);load(58);branch('Brfalse','end')
 load(58);s('__cg');call('find');store(59);load(59);branch('Brfalse','end')
 # Height is recomputed on both creation and subsequent update paths.
 emit('Ldarg',0);call('head');store(60);load(60);branch('Brfalse','end')
 load(60);call('pos');emit('Ldfld',0);load(58);call('pos');emit('Ldfld',0);emit('Sub');store(67)
 load(67);f(.6);branch('Blt','height_default');load(67);f(3);branch('Ble','height_ok')
 label('height_default');f(1.75);store(67);label('height_ok')
 load(59);s('__gustaxy_name');call('find');store(60);load(60);branch('Brtrue','existing')
 s('__gustaxy_name');call('go_ctor',True);store(62)
 load(62);call('go_tf');store(60);load(60);load(59);emit('Ldc_I4',0);call('set_parent')
 load(62);emit('Ldtype',tm);emit('Nop');call('add');emit('Isinst',tm);store(61)
 load(61);branch('Brfalse','end');load(61);s(text);call('text')
 load(61);emit('Ldc_I4',48);call('size');load(61);f(.035);call('char_size')
 load(61);emit('Ldc_I4',7);call('anchor');load(61);emit('Ldc_I4',1);call('align')
 # Reuse a loaded legacy font. No hardcoded Arial.ttf/LegacyRuntime.ttf dependency.
 emit('Ldtype',font);emit('Nop');call('fonts');store(64)
 load(64);emit('Ldlen');emit('Conv_I4');emit('Ldc_I4',0);branch('Ble','tick')
 load(64);emit('Ldc_I4',0);emit('Ldelem_Ref');emit('Isinst',font);store(65)
 load(65);branch('Brfalse','tick');load(61);load(65);call('font')
 load(60);s('Renderer');call('get_component');emit('Isinst',25);store(66)
 load(66);branch('Brfalse','tick');load(66);load(65);call('font_material');call('material');branch('Br','tick')
 label('existing');load(60);s('TextMesh');call('get_component');emit('Isinst',tm);store(61)
 label('tick');load(61);branch('Brfalse','end')
 load(60);f(0);load(67);f(1.36);emit('Mul');f(0);call('vec_ctor',True);call('localpos')
 call('cam');store(63);load(63);branch('Brfalse','animate')
 load(60);load(63);call('component_tf');call('getrot');call('setrot')
 label('animate');load(61);call('time');f(18);emit('Div');f(1);call('repeat');f(.85);f(1);emit('Ldc_I4',0);call('hsv');call('color')
 label('end')
 for i,to in fix:seq[i][1]=labels[to]-i
 verify_block(seq,names,effects)
 insertion=917;count=len(seq)
 # Relocate existing relative jumps so the old exit now enters the new visual block.
 for i,(op,arg) in enumerate(code):
  if names[op] in BRANCHES:
   target=i+arg;new_i=i+(count if i>=insertion else 0)
   new_target=target+(count if target>insertion else 0)
   code[i][1]=new_target-new_i
 code[0][1]=(68<<16)|16
 d['methods'][0]['code']=code[:insertion]+seq+code[insertion:]
 report.update(name=text,name_cycle_seconds=18,inserted_instructions=count,new_instruction_count=len(d['methods'][0]['code']),extern_count=len(d['externs']),name_runtime_status='EXPERIMENTAL_NOT_TESTED_ON_DEVICE')
 return d,report,dict(code=seq,effects=effects,labels=labels)
def verify_block(seq,names,effects):
 states={0:0};todo=[0];n=len(seq)
 while todo:
  i=todo.pop();height=states[i]
  if i==n:
   assert height==0,('nonempty exit',height);continue
  op,arg=seq[i];name=names[op]
  if i in effects:pop,push=effects[i]
  elif name in ('Ldarg','Ldloc','Ldc_I4','Ldc_R4','Ldstr','Ldtype'):pop,push=0,1
  elif name=='Stloc':pop,push=1,0
  elif name in ('Ldfld','Isinst','Conv_I4','Ldlen'):pop,push=1,1
  elif name=='Ldelem_Ref':pop,push=2,1
  elif name in ('Sub','Mul','Div'):pop,push=2,1
  elif name in ('Brtrue','Brfalse'):pop,push=1,0
  elif name in BRANCHES-{'Br','Brtrue','Brfalse','Leave'}:pop,push=2,0
  elif name in ('Nop','Br'):pop,push=0,0
  else:raise ValueError('unverified opcode '+name)
  assert height>=pop,('stack underflow',i,name,height,pop)
  h=height-pop+push
  successors=[i+arg] if name=='Br' else [i+1,i+arg] if name in BRANCHES else [i+1]
  for j in successors:
   assert 0<=j<=n,('bad branch',i,j)
   if j in states:assert states[j]==h,('stack mismatch',i,j,h,states[j])
   else:states[j]=h;todo.append(j)
 assert n in states
