"""Reader/writer for the sections decoded from this IFix template.
The private binding tail is deliberately preserved, never fabricated.
"""
import struct,copy
class Reader:
 def __init__(self,b):self.b=b;self.p=0
 def val(self,f):
  v=struct.unpack_from(f,self.b,self.p);self.p+=struct.calcsize(f);return v[0] if len(v)==1 else list(v)
 def i(self):return self.val('<i')
 def s(self):
  n=0;shift=0
  for _ in range(5):
   v=self.val('B');n|=(v&127)<<shift;shift+=7
   if not v&128:break
  else:raise ValueError('invalid string length')
  if self.p+n>len(self.b):raise ValueError('truncated string')
  b=self.b[self.p:self.p+n];self.p+=n;return b.decode('utf8')
 def seq(self,fn):
  n=self.i()
  if not 0<=n<100000:raise ValueError('invalid count')
  return [fn() for _ in range(n)]
 def method(self):
  gen=self.val('<?');t=self.i();name=self.s();ga=self.seq(self.i) if gen else []
  def par():return {'generic':self.s()} if gen and self.val('<?') else self.i()
  return dict(generic=gen,type=t,name=name,gargs=ga,args=self.seq(par))
def decode(raw):
 r=Reader(raw);d=dict(magic=r.val('<Q'),bridge=r.s());d['types']=r.seq(r.s)
 def code():return dict(code=r.seq(lambda:r.val('<ii')),eh=r.seq(lambda:r.val('<iiiiii')))
 d['methods']=r.seq(code);d['externs']=r.seq(r.method);d['strings']=r.seq(r.s)
 def field():
  v=dict(new=r.val('<?'),type=r.i(),name=r.s())
  if v['new']:v.update(ftype=r.i(),ctor=r.i())
  return v
 d['fields']=r.seq(field);d['static_fields']=r.seq(lambda:r.val('<ii'))
 d['anonymous_count']=r.i()
 if d['anonymous_count']!=0:raise ValueError('anonymous classes not supported by this template assembler')
 d['tail']=raw[r.p:];return d
class Writer:
 def __init__(self):self.b=bytearray()
 def val(self,f,*v):self.b+=struct.pack(f,*v)
 def i(self,v):self.val('<i',v)
 def s(self,s):
  raw=s.encode('utf8');n=len(raw)
  while n>=128:self.val('B',(n&127)|128);n>>=7
  self.val('B',n);self.b+=raw
 def seq(self,seq,fn):
  self.i(len(seq))
  for v in seq:fn(v)
 def method(self,m):
  self.val('<?',m['generic']);self.i(m['type']);self.s(m['name'])
  if m['generic']:self.seq(m['gargs'],self.i)
  def par(v):
   if m['generic']:self.val('<?',isinstance(v,dict))
   self.s(v['generic']) if isinstance(v,dict) else self.i(v)
  self.seq(m['args'],par)
def encode(d):
 w=Writer();w.val('<Q',d['magic']);w.s(d['bridge']);w.seq(d['types'],w.s)
 def code(m):
  w.seq(m['code'],lambda v:w.val('<ii',*v));w.seq(m['eh'],lambda v:w.val('<iiiiii',*v))
 w.seq(d['methods'],code);w.seq(d['externs'],w.method);w.seq(d['strings'],w.s)
 def field(v):
  w.val('<?',v['new']);w.i(v['type']);w.s(v['name'])
  if v['new']:w.i(v['ftype']);w.i(v['ctor'])
 w.seq(d['fields'],field);w.seq(d['static_fields'],lambda v:w.val('<ii',*v));w.i(d['anonymous_count']);w.b+=d['tail'];return bytes(w.b)
def float_i(f):return struct.unpack('<i',struct.pack('<f',f))[0]
