import java.time.Instant

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("kotlin-parcelize")
}

// A URL do servidor NUNCA fica em cleartext no código-fonte nem no BuildConfig
// de release — ela é construída em runtime pelo nativo (shards ofuscados em
// gusta.cpp). BuildConfig.API_BASE_URL só é usado como hint em builds DEBUG.
val configuredApiBaseUrl = (System.getenv("GUSTAXY_API_BASE_URL")?.takeIf { it.isNotBlank() } ?: "https://127.0.0.1/api/v1")
    .replace("\\", "\\\\")
    .replace("\"", "\\\"")
val configuredCertificateSha256 = (System.getenv("GUSTAXY_CERT_SHA256")?.takeIf { it.isNotBlank() } ?: "")
    .replace("\\", "\\\\")
    .replace("\"", "\\\"")
val configuredApkSha256 = (System.getenv("GUSTAXY_APK_SHA256")?.takeIf { it.isNotBlank() } ?: "")
    .replace("\\", "\\\\")
    .replace("\"", "\\\"")
val configuredTlsPins = (System.getenv("GUSTAXY_TLS_PINS")?.takeIf { it.isNotBlank() } ?: "")
    .replace("\\", "\\\\")
    .replace("\"", "\\\"")
// Fingerprint de build (epoch UTC) — atrela o sinal de integridade nativo a
// esta compilação exata. Rebuild = sinal diferente.
val buildFingerprint = Instant.now().epochSecond.toString()

private val integrityXorMask = byteArrayOf(
    0x5A.toByte(), 0x3C.toByte(), 0x7F.toByte(), 0x11.toByte(),
    0xA6.toByte(), 0xB3.toByte(), 0x29.toByte(), 0xE1.toByte(),
    0x48.toByte(), 0x92.toByte(), 0x17.toByte(), 0xD4.toByte(),
    0x6E.toByte(), 0x0B.toByte(), 0xF8.toByte(), 0x35.toByte(),
    0xC3.toByte(), 0x71.toByte(), 0x4D.toByte(), 0xAA.toByte(),
    0x18.toByte(), 0xE7.toByte(), 0x53.toByte(), 0x8C.toByte(),
    0xD1.toByte(), 0x26.toByte(), 0x95.toByte(), 0x4A.toByte(),
    0xF0.toByte(), 0x67.toByte(), 0x3B.toByte(), 0xBE.toByte()
)
val configuredIntegritySecretXorHex = (System.getenv("GUSTAXY_INTEGRITY_SECRET")?.takeIf { it.isNotBlank() } ?: "")
    .toByteArray(Charsets.UTF_8)
    .mapIndexed { index, value ->
        (value.toInt() xor (integrityXorMask[index % integrityXorMask.size].toInt() and 0xFF)) and 0xFF
    }
    .joinToString("") { "%02x".format(it) }

val releaseStorePath = System.getenv("GUSTAXY_KEYSTORE_PATH")
val releaseStorePassword = System.getenv("GUSTAXY_KEYSTORE_PASSWORD")
val releaseKeyAlias = System.getenv("GUSTAXY_KEY_ALIAS")
val releaseKeyPassword = System.getenv("GUSTAXY_KEY_PASSWORD") ?: releaseStorePassword

android {
    namespace = "com.gustaxy.android"
    compileSdk = 35
    ndkVersion = "26.3.11579264"

    defaultConfig {
        applicationId = "com.gustaxy.android"
        minSdk = 24
        targetSdk = 35
        versionCode = 3
        versionName = "1.2.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }
        // Em release este valor é ignorado (o nativo é a fonte da URL).
        buildConfigField("String", "API_BASE_URL", "\"$configuredApiBaseUrl\"")
        buildConfigField("String", "EXPECTED_CERT_SHA256", "\"$configuredCertificateSha256\"")
        buildConfigField("String", "EXPECTED_APK_SHA256", "\"$configuredApkSha256\"")
        buildConfigField("String", "TLS_PINS", "\"$configuredTlsPins\"")
        externalNativeBuild {
            cmake {
                arguments(
                    "-DGUSTAXY_INTEGRITY_SECRET_XOR_HEX=$configuredIntegritySecretXorHex",
                    "-DGUSTAXY_BUILD_FINGERPRINT=$buildFingerprint"
                )
            }
        }
    }

    signingConfigs {
        create("release") {
            if (!releaseStorePath.isNullOrBlank()) {
                storeFile = file(releaseStorePath)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isCrunchPngs = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (!releaseStorePath.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
            // Strip completo dos símbolos nativos no empacotamento (superfície ELF mínima).
            ndk { debugSymbolLevel = "NONE" }
            packaging { jniLibs { useLegacyPackaging = false } }
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true; aidl = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.media:media:1.7.0")
    implementation("androidx.savedstate:savedstate:1.2.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
}
