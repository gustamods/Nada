package com.gustaxy.android.security;

/**
 * Interface do UserService do Shizuku.
 * Roda num processo separado com privilégio de shell/root, substituindo
 * o antigo Shizuku.newProcess() (privado desde a API 13.1.x).
 */
interface IShellService {

    /** Método reservado exigido pelo servidor Shizuku (código fixo 16777114). */
    void destroy() = 16777114;

    /** Executa um comando via `sh -c` e devolve stdout+stderr concatenados. */
    String executar(String comando) = 1;
}
