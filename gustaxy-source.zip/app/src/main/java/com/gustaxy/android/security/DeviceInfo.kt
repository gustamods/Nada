package com.gustaxy.android.security

import android.content.Context
import android.media.MediaDrm
import android.os.Build
import android.provider.Settings
import android.util.Base64
import com.gustaxy.android.BuildConfig
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.MessageDigest
import java.util.UUID

/**
 * Identidade de dispositivo estável em camadas.
 *
 * Ordem de prioridade (do mais estável ao menos estável):
 *  1) MediaDrm (Widevine) — sobrevive a reinstalação; só muda em formatação.
 *  2) ANDROID_ID — sobrevive a reinstalação na mesma conta/dispositivo.
 *  3) Fingerprint persistido — gerado uma vez e guardado; âncora quando
 *     MediaDrm/ANDROID_ID oscilam.
 *  4) Keystore EC — apenas fator adicional de diversidade, NUNCA âncora,
 *     porque é apagado na desinstalação.
 *
 * Resultado: o deviceId permanece o mesmo após desinstalar/reinstalar, e só
 * muda quando o aparelho é formatado (restauração de fábrica).
 */
object DeviceInfo {
    private const val KEY_ALIAS = "gustaxy_device_binding_v1"
    private const val WIDEVINE_UUID = "edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"
    private const val PREF_FILE = "gustaxy_identity"
    private const val PREF_FP = "stable_fp"

    @Volatile
    private var cached: String? = null

    @Synchronized
    fun deviceId(context: Context): String {
        cached?.let { return it }

        val drm = runCatching { mediaDrmId() }.getOrNull().orEmpty()
        val androidId = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID
        ).orEmpty()
        val persisted = runCatching { stableFingerprint(context) }.getOrNull().orEmpty()
        val keystoreFp = runCatching { keystoreFingerprint() }.getOrNull().orEmpty()

        val parts = buildList {
            if (drm.isNotBlank()) add("drm=$drm")
            if (androidId.isNotBlank()) add("android=$androidId")
            if (persisted.isNotBlank()) add("persisted=$persisted")
            if (keystoreFp.isNotBlank()) add("ks=$keystoreFp")
            add("app=${BuildConfig.APPLICATION_ID}")
        }

        val id = Base64.encodeToString(
            MessageDigest.getInstance("SHA-256")
                .digest(parts.joinToString("|").toByteArray(StandardCharsets.UTF_8)),
            Base64.NO_WRAP
        )
        cached = id
        return id
    }

    /** Fingerprint estável persistido (marcador de continuidade, sem segredo). */
    private fun stableFingerprint(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)
        prefs.getString(PREF_FP, null)?.takeIf { it.isNotBlank() }?.let { return it }
        val fresh = Base64.encodeToString(
            MessageDigest.getInstance("SHA-256").digest(
                (UUID.randomUUID().toString() + System.nanoTime() + Build.FINGERPRINT)
                    .toByteArray(StandardCharsets.UTF_8)
            ),
            Base64.NO_WRAP
        )
        prefs.edit().putString(PREF_FP, fresh).apply()
        return fresh
    }

    private fun keystoreFingerprint(): String {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            val generator = java.security.KeyPairGenerator.getInstance("EC", "AndroidKeyStore")
            generator.initialize(
                android.security.keystore.KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    android.security.keystore.KeyProperties.PURPOSE_SIGN or
                        android.security.keystore.KeyProperties.PURPOSE_VERIFY
                )
                    .setAlgorithmParameterSpec(java.security.spec.ECGenParameterSpec("secp256r1"))
                    .setDigests(android.security.keystore.KeyProperties.DIGEST_SHA256)
                    .setUserAuthenticationRequired(false)
                    .build()
            )
            generator.generateKeyPair()
        }
        val certificate = keyStore.getCertificate(KEY_ALIAS) ?: return ""
        val digest = MessageDigest.getInstance("SHA-256").digest(certificate.publicKey.encoded)
        return Base64.encodeToString(digest, Base64.NO_WRAP)
    }

    private fun mediaDrmId(): String? = runCatching {
        val uuid = java.util.UUID.fromString(WIDEVINE_UUID)
        val drm = MediaDrm(uuid)
        try {
            val bytes = drm.getPropertyByteArray(MediaDrm.PROPERTY_DEVICE_UNIQUE_ID)
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } finally {
            drm.release()
        }
    }.getOrNull()

    fun deviceName(): String = "${Build.MANUFACTURER} ${Build.MODEL}".trim().take(120)
    fun androidVersion(): String = Build.VERSION.RELEASE.orEmpty().take(32)
}
