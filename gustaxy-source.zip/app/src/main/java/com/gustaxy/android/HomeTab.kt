package com.gustaxy.android

import android.content.Intent
import android.os.Build
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.gustaxy.android.network.ApiClient
import android.os.Handler
import android.os.Looper
import com.gustaxy.android.security.Injector
import com.gustaxy.android.security.ShizukuManager
import rikka.shizuku.Shizuku

/** Aba Início do dashboard, com rolagem vertical para todos os switches. */
@Composable
internal fun HomeTab(session: ApiClient.SessionInfo) {
    val context = LocalContext.current
    var overlayEnabled by remember { mutableStateOf(false) }
    var shizukuAvailable by remember { mutableStateOf(ShizukuManager.isAvailable()) }
    var shizukuGranted by remember { mutableStateOf(ShizukuManager.hasPermission()) }

    // === ESTADO DA INJEÇÃO DO MOD (Free Fire MAX) ===
    var modEnabled by remember { mutableStateOf(false) }
    var menuFlutuanteLib by remember { mutableStateOf(true) }
    var statusInjecao by remember { mutableStateOf("Aguardando...") }
    var injetando by remember { mutableStateOf(false) }

    // === MÉTODO DO PATCH POR ARQUIVOS (ESP/Aimbot) ===
    var espEnabled by remember { mutableStateOf(false) }
    var aimbotEnabled by remember { mutableStateOf(false) }
    var statusPatch by remember { mutableStateOf("Aguardando...") }
    var aplicandoPatch by remember { mutableStateOf(false) }

    // Carrega o config salvo ao abrir a aba — fora da composição e sem Shizuku
    // (apenas backup local), então é seguro e não gera corrida com os switches.
    LaunchedEffect(Unit) {
        LogManager.i("HOME", "Aba Início aberta — carregando config salvo")
        LogManager.i("HOME", "Shizuku: disponível=$shizukuAvailable, permissão=$shizukuGranted")
        val salvo = ConfigManager.carregarConfig(context)
        modEnabled = salvo.modEnabled
        menuFlutuanteLib = salvo.menuFlutuante
    }

    DisposableEffect(Unit) {
        val listener = object : Shizuku.OnRequestPermissionResultListener {
            override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                if (requestCode == ShizukuManager.REQUEST_CODE) {
                    val concedida = grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED ||
                        ShizukuManager.hasPermission()
                    LogManager.i("HOME", "Resposta da permissão Shizuku: ${if (concedida) "CONCEDIDA" else "NEGADA"}")
                    shizukuAvailable = ShizukuManager.isAvailable()
                    shizukuGranted = concedida
                }
            }
        }
        Shizuku.addRequestPermissionResultListener(listener)
        onDispose { Shizuku.removeRequestPermissionResultListener(listener) }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(22.dp))

        StatusCard(
            title = "Conecte-se ao ADB🎸",
            value = if (session.keysPaused) "Pausada" else "Online",
            accent = Color(0xFF2B7BFF)
        )

        Spacer(modifier = Modifier.height(12.dp))
        ShizukuPermissionCard(
            available = shizukuAvailable,
            granted = shizukuGranted,
            onRefresh = {
                shizukuAvailable = ShizukuManager.isAvailable()
                shizukuGranted = ShizukuManager.hasPermission()
                LogManager.i("HOME", "Status Shizuku atualizado: disponível=$shizukuAvailable, permissão=$shizukuGranted")
            },
            onRequest = {
                LogManager.i("HOME", "Solicitando permissão Shizuku...")
                ShizukuManager.requestPermission()
            }
        )

        Spacer(modifier = Modifier.height(24.dp))

        // ==========================================
        // INJEÇÃO DO MOD — FREE FIRE MAX
        // ==========================================
        SectionTitle(title = "🚀 Injeção do Mod (FF MAX)")
        Spacer(modifier = Modifier.height(10.dp))

        // Salvamento assíncrono: o switch responde na hora na UI e o Shizuku
        // roda numa thread de fundo (serializado dentro do ConfigManager/Injector).
        // Assim, dois switches ligados em sequência nunca disparam binds simultâneos.
        FeatureSwitch(
            title = "Ativar Mod Menu",
            description = "Grava mod_enabled=true no local_config.json",
            checked = modEnabled,
            onCheckedChange = { next ->
                modEnabled = next
                LogManager.i("HOME", "Switch 'Ativar Mod Menu' → $next")
                kotlin.concurrent.thread {
                    ConfigManager.salvarConfig(context, ConfigManager.Config(next, menuFlutuanteLib))
                }
            }
        )
        FeatureSwitch(
            title = "Menu flutuante da lib",
            description = "Configuração da lib; requer implementação correspondente",
            checked = menuFlutuanteLib,
            onCheckedChange = { next ->
                menuFlutuanteLib = next
                LogManager.i("HOME", "Switch 'Menu flutuante da lib' → $next")
                kotlin.concurrent.thread {
                    ConfigManager.salvarConfig(context, ConfigManager.Config(modEnabled, next))
                }
            }
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Status: $statusInjecao",
            color = Color(0xFF9DA8BC),
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                if (injetando || statusInjecao.contains("SUCESSO")) return@Button
                LogManager.i("HOME", "▶️ Botão INJETAR pressionado")
                if (!shizukuGranted) {
                    statusInjecao = "❌ Conceda a permissão Shizuku primeiro!"
                    LogManager.e("HOME", "Injeção bloqueada: sem permissão Shizuku")
                    return@Button
                }
                if (!modEnabled) {
                    statusInjecao = "⚠️ Ligue 'Ativar Mod Menu' primeiro!"
                    LogManager.w("HOME", "Injeção bloqueada: Mod Menu desligado")
                    return@Button
                }
                injetando = true
                statusInjecao = "⏳ Salvando local_config.json..."
                // thread { } já inicia automaticamente — sem .start() extra.
                kotlin.concurrent.thread {
                    LogManager.i("HOME", "[1/4] Salvando config no jogo...")
                    val r1 = ConfigManager.salvarConfig(
                        context,
                        ConfigManager.Config(true, menuFlutuanteLib)
                    )
                    if (!r1) {
                        LogManager.e("HOME", "[1/4] FALHOU — não conseguiu salvar o config na pasta do jogo")
                        Handler(Looper.getMainLooper()).post { statusInjecao = "❌ Falha ao salvar o config na pasta do jogo" }
                        Handler(Looper.getMainLooper()).post { injetando = false }
                        return@thread
                    }

                    LogManager.i("HOME", "[2/4] Preparando libproxy.so...")
                    Handler(Looper.getMainLooper()).post { statusInjecao = "📦 Preparando libproxy.so..." }
                    val r2 = Injector.prepararLib(context)
                    if (!r2.sucesso) {
                        LogManager.e("HOME", "[2/4] FALHOU — ${r2.mensagem}")
                        Handler(Looper.getMainLooper()).post { statusInjecao = r2.mensagem }
                        Handler(Looper.getMainLooper()).post { injetando = false }
                        return@thread
                    }

                    LogManager.i("HOME", "[3/4] Abrindo o Free Fire MAX...")
                    Handler(Looper.getMainLooper()).post { statusInjecao = "🎮 Abrindo o Free Fire MAX..." }
                    Injector.abrirJogo(Injector.PACOTE_JOGO)
                    Handler(Looper.getMainLooper()).post { statusInjecao = "⏳ Aguardando o jogo carregar..." }
                    Thread.sleep(8000)

                    // O processo pode demorar a aparecer: tenta algumas vezes
                    // antes de desistir (o pidof rodava só uma vez no código antigo).
                    LogManager.i("HOME", "[4/4] Injetando a lib no processo do jogo...")
                    var r3 = Injector.injetarLib(context)
                    if (!r3.sucesso && r3.mensagem.contains("PID")) {
                        LogManager.w("HOME", "PID ainda não apareceu — tentando novamente (até 3x)...")
                        Handler(Looper.getMainLooper()).post { statusInjecao = "⏳ Jogo ainda iniciando, tentando de novo..." }
                        repeat(3) { tentativa ->
                            Thread.sleep(3000)
                            LogManager.i("HOME", "Nova tentativa de injeção (${tentativa + 1}/3)...")
                            r3 = Injector.injetarLib(context)
                            if (r3.sucesso || !r3.mensagem.contains("PID")) return@repeat
                        }
                    }
                    LogManager.i("HOME", "Resultado final da injeção: ${r3.mensagem}")
                    Handler(Looper.getMainLooper()).post { statusInjecao = r3.mensagem }
                    Handler(Looper.getMainLooper()).post { injetando = false }
                }
            },
            enabled = !injetando,
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFFFB800),
                contentColor = Color(0xFF0B0D11)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(
                text = if (injetando) "INJETANDO..." else "INJETAR & INICIAR JOGO",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(22.dp))

        // ==========================================
        // MÉTODO DO PATCH POR ARQUIVOS (o do seu amigo)
        // ==========================================
        SectionTitle(title = "🎯 Mod por Arquivos (Patch)")
        Spacer(modifier = Modifier.height(10.dp))

        FeatureSwitch(
            title = "ESP Box + Nome",
            description = "Box amarela + nome fixo GUSTAXY SAFE sobre a vida",
            checked = espEnabled,
            onCheckedChange = { next ->
                espEnabled = next
                LogManager.i("HOME", "Switch 'ESP Box' → $next")
            }
        )
        Text("Este patch visual não inclui aimbot.", color = Color(0xFF9DA8BC), fontSize = 12.sp)

        // O segundo botão SÓ aparece quando alguma função do patch está ligada
        if (espEnabled) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Status: $statusPatch",
                color = Color(0xFF9DA8BC),
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    if (aplicandoPatch) return@Button
                    LogManager.i("HOME", "▶️ Botão APLICAR ARQUIVOS pressionado")
                    if (!shizukuGranted) {
                        statusPatch = "❌ Conceda a permissão Shizuku primeiro!"
                        LogManager.e("HOME", "Patch bloqueado: sem permissão Shizuku")
                        return@Button
                    }
                    aplicandoPatch = true
                    statusPatch = "⏳ Aplicando arquivos na pasta do jogo..."
                    kotlin.concurrent.thread {
                        val r = PatchDeployer.implantarPatch(
                            context,
                            PatchDeployer.Opcoes(esp = espEnabled, aimbot = false)
                        )
                        Handler(Looper.getMainLooper()).post { statusPatch = r.mensagem }
                        if (r.sucesso) {
                            LogManager.i("HOME", "Abrindo o FF MAX com o patch aplicado...")
                            Injector.abrirJogo(Injector.PACOTE_JOGO)
                            Handler(Looper.getMainLooper()).post {
                                statusPatch = "Arquivos copiados. Confira o resultado visual no FF MAX."
                            }
                        }
                        Handler(Looper.getMainLooper()).post { aplicandoPatch = false }
                    }
                },
                enabled = !aplicandoPatch,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2BFF88),
                    contentColor = Color(0xFF0B0D11)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = if (aplicandoPatch) "APLICANDO..." else "APLICAR ARQUIVOS & ABRIR JOGO",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        SectionTitle(title = "Menu Hs")
        Spacer(modifier = Modifier.height(10.dp))
        FeatureSwitch("AimPrecision", "Faz a Mira não Passar da Cabeça.")
        FeatureSwitch("HS Alto", "HS Acima da cabeça.")
        FeatureSwitch("HS Alto + Neck", "Hs Acima da Cabeça e no Pescoço.")
        FeatureSwitch("HS Caveira", "Hs Abaixo do Pescoço.")
        FeatureSwitch("HS Neck", "Hs Legit no Pescoço.")
        FeatureSwitch("HS Ombro", "Hs no Ombro.")

        Spacer(modifier = Modifier.height(22.dp))

        SectionTitle(title = "Menu Rage")
        Spacer(modifier = Modifier.height(10.dp))
        FeatureSwitch("BackJump", "Pulinho para Trás.")
        FeatureSwitch("Pulo Alto", "Pular até 2 metros mais alto.")
        FeatureSwitch("Tela Parada", "Tela Parada de Emulador")
        FeatureSwitch("Fake Lag (Beta Risk Black)", "Internet Fake.")

        Spacer(modifier = Modifier.height(22.dp))

        SectionTitle(title = "Funções flutuantes")
        Spacer(modifier = Modifier.height(10.dp))
        FeatureSwitch(
            title = "Menu flutuante sobre outros apps",
            description = "Exibe o overflow controlado por uma notificação.",
            checked = overlayEnabled,
            onCheckedChange = { next ->
                if (next) {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)) {
                        overlayEnabled = true
                        LogManager.i("HOME", "Overlay flutuante ATIVADO")
                        ContextCompat.startForegroundService(
                            context,
                            Intent(context, FloatingOverlayService::class.java)
                        )
                        // Puxa o ícone de manutenção (escolhido no admin) já na ativação.
                        FloatingOverlayService.requestIconRefresh(context)
                    } else {
                        LogManager.w("HOME", "Overlay sem permissão SYSTEM_ALERT_WINDOW — abrindo configurações")
                        context.startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                        )
                    }
                } else {
                    overlayEnabled = false
                    LogManager.i("HOME", "Overlay flutuante DESATIVADO")
                    context.stopService(Intent(context, FloatingOverlayService::class.java))
                }
            }
        )

        Spacer(modifier = Modifier.height(22.dp))

        SectionTitle(title = "Guest")
        Spacer(modifier = Modifier.height(10.dp))
        FeatureSwitch("Reset Guest", "Deletar Conta Convidada")
    }
}

@Composable
private fun ShizukuPermissionCard(
    available: Boolean,
    granted: Boolean,
    onRefresh: () -> Unit,
    onRequest: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF111A2B), RoundedCornerShape(20.dp))
            .padding(18.dp)
    ) {
        Text(
            text = "Permissão Shizuku",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = when {
                !available -> "Shizuku não está disponível no momento."
                granted -> "Permissão concedida. Nenhuma função está sendo executada aqui."
                else -> "Shizuku disponível, mas a permissão ainda não foi concedida."
            },
            color = Color(0xFF9DA8BC),
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onRefresh() },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF293244))
            ) {
                Text("Atualizar", fontSize = 12.sp)
            }
            Button(
                onClick = { onRequest() },
                enabled = available && !granted,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B7BFF))
            ) {
                Text(if (granted) "Concedida" else "Solicitar", fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        color = Color.White,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun FeatureSwitch(
    title: String,
    description: String,
    checked: Boolean? = null,
    onCheckedChange: ((Boolean) -> Unit)? = null,
) {
    var localChecked by remember { mutableStateOf(false) }
    val isChecked = checked ?: localChecked

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .background(
                color = Color(0xFF121722),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(text = description, color = Color(0xFF7D879A), fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.padding(horizontal = 8.dp))
        Switch(
            checked = isChecked,
            onCheckedChange = { next ->
                if (checked == null) localChecked = next
                onCheckedChange?.invoke(next)
            },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF2B7BFF),
                uncheckedThumbColor = Color(0xFFB7BECC),
                uncheckedTrackColor = Color(0xFF2A303C),
                uncheckedBorderColor = Color(0xFF3A4250)
            )
        )
    }
}
