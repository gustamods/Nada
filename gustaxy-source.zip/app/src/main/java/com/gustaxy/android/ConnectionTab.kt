package com.gustaxy.android

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gustaxy.android.network.ApiClient

/** Aba de conexão; não expõe identificadores nem detalhes de device binding na UI. */
@Composable
internal fun ConnectionTab(session: ApiClient.SessionInfo) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("Conexão", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text(
            "Status do acesso atual",
            modifier = Modifier.padding(top = 6.dp),
            color = Color(0xFF9DA8BC),
            fontSize = 14.sp
        )
        Spacer(modifier = Modifier.height(22.dp))
        StatusCard(
            title = "Servidor",
            value = if (session.keysPaused) "Pausa global" else "Online",
            accent = Color(0xFF2B7BFF)
        )
        Spacer(modifier = Modifier.height(12.dp))
        StatusCard(
            title = "Sessão",
            value = "Autenticada",
            accent = Color(0xFFFF3855)
        )
    }
}
