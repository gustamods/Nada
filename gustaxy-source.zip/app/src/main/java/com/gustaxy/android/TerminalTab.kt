package com.gustaxy.android

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Aba Terminal: mostra TODOS os logs do app em tempo real (LogManager).
 * Auto-rola para a linha mais recente e permite limpar ou copiar tudo.
 */
@Composable
internal fun TerminalTab() {
    val entradas = LogManager.logs
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current

    // Auto-scroll para o fim sempre que chegar log novo
    LaunchedEffect(entradas.size) {
        if (entradas.isNotEmpty()) {
            listState.animateScrollToItem(entradas.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Spacer(modifier = Modifier.height(22.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "🖥️ Terminal",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${entradas.size} linhas — logs em tempo real",
                    color = Color(0xFF9DA8BC),
                    fontSize = 12.sp
                )
            }
            Row {
                Button(
                    onClick = { clipboard.setText(AnnotatedString(LogManager.exportarTexto())) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF293244)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Copiar", fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = { LogManager.limpar() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5C2323)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Limpar", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0E16), RoundedCornerShape(14.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            if (entradas.isEmpty()) {
                item {
                    Text(
                        text = "Sem logs ainda. Use o app (switches, injeção, permissões) e tudo aparece aqui na hora.",
                        color = Color(0xFF5A6577),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }
            items(entradas) { entrada ->
                val cor = when (entrada.nivel) {
                    LogManager.Nivel.INFO -> Color(0xFF9DA8BC)
                    LogManager.Nivel.COMANDO -> Color(0xFF66D9EF)
                    LogManager.Nivel.SUCESSO -> Color(0xFF6FE38A)
                    LogManager.Nivel.AVISO -> Color(0xFFFFB800)
                    LogManager.Nivel.ERRO -> Color(0xFFFF5C5C)
                }
                Text(
                    text = "[${entrada.hora}] ${entrada.tag}: ${entrada.mensagem}",
                    color = cor,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 15.sp,
                    modifier = Modifier.padding(vertical = 1.dp)
                )
            }
        }
    }
}
