package com.gustaxy.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media.session.MediaButtonReceiver
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat

class LarkPlaybackService : Service() {
    private var mediaPlayer: MediaPlayer? = null
    private var currentUri: Uri? = null
    private var currentTitle: String = "Lark Player"
    private var currentArtist: String = ""
    private var currentAlbum: String = ""
    private var queue: List<QueueItem> = emptyList()
    private var queueIndex: Int = -1
    private lateinit var mediaSession: MediaSessionCompat

    private data class QueueItem(
        val uri: Uri,
        val title: String,
        val artist: String,
        val album: String,
    )

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        mediaSession = MediaSessionCompat(this, SESSION_TAG).apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() = resumePlayback()
                override fun onPause() = pausePlayback()
                override fun onStop() = stopPlayback()
                override fun onSkipToNext() = playRelative(1)
                override fun onSkipToPrevious() = playRelative(-1)
                override fun onSeekTo(pos: Long) {
                    mediaPlayer?.seekTo(pos.toInt())
                }
            })
            setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                    MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
            )
            isActive = true
        }
        updatePlaybackState(PlaybackStateCompat.STATE_NONE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val uriText = intent.getStringExtra(EXTRA_URI).orEmpty()
                if (uriText.isNotBlank()) {
                    val uris = intent.getStringArrayListExtra(EXTRA_QUEUE_URIS).orEmpty()
                    val titles = intent.getStringArrayListExtra(EXTRA_QUEUE_TITLES).orEmpty()
                    val artists = intent.getStringArrayListExtra(EXTRA_QUEUE_ARTISTS).orEmpty()
                    val albums = intent.getStringArrayListExtra(EXTRA_QUEUE_ALBUMS).orEmpty()
                    queue = uris.mapIndexed { index, uri ->
                        QueueItem(
                            uri = Uri.parse(uri),
                            title = titles.getOrNull(index).orEmpty(),
                            artist = artists.getOrNull(index).orEmpty(),
                            album = albums.getOrNull(index).orEmpty()
                        )
                    }.ifEmpty {
                        listOf(QueueItem(Uri.parse(uriText), intent.getStringExtra(EXTRA_TITLE).orEmpty(), intent.getStringExtra(EXTRA_ARTIST).orEmpty(), intent.getStringExtra(EXTRA_ALBUM).orEmpty()))
                    }
                    queueIndex = intent.getIntExtra(EXTRA_QUEUE_INDEX, queue.indexOfFirst { it.uri.toString() == uriText }.coerceAtLeast(0))
                    val selected = queue.getOrNull(queueIndex) ?: queue.first()
                    prepareAndPlay(selected.uri, selected.title, selected.artist, selected.album)
                }
            }
            ACTION_PAUSE -> pausePlayback()
            ACTION_RESUME -> resumePlayback()
            ACTION_STOP -> stopPlayback()
            ACTION_NEXT -> playRelative(1)
            ACTION_PREVIOUS -> playRelative(-1)
            ACTION_MEDIA_BUTTON -> MediaButtonReceiver.handleIntent(mediaSession, intent)
        }
        return START_NOT_STICKY
    }

    private fun prepareAndPlay(uri: Uri, title: String, artist: String, album: String) {
        releasePlayer()
        currentUri = uri
        currentTitle = title.ifBlank { "Sem título" }
        currentArtist = artist.ifBlank { "Artista desconhecido" }
        currentAlbum = album.ifBlank { "Álbum desconhecido" }
        startForeground(NOTIFICATION_ID, buildNotification(isPlaying = false))
        updatePlaybackState(PlaybackStateCompat.STATE_BUFFERING)

        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            setDataSource(this@LarkPlaybackService, uri)
            setOnPreparedListener { prepared ->
                prepared.start()
                updatePlaybackState(PlaybackStateCompat.STATE_PLAYING)
                refreshNotification(isPlaying = true)
            }
            setOnCompletionListener {
                if (queue.size > 1) {
                    playRelative(1)
                } else {
                    updatePlaybackState(PlaybackStateCompat.STATE_PAUSED)
                    refreshNotification(isPlaying = false)
                }
            }
            setOnErrorListener { _, _, _ ->
                updatePlaybackState(PlaybackStateCompat.STATE_ERROR)
                refreshNotification(isPlaying = false)
                releasePlayer()
                true
            }
            prepareAsync()
        }
    }

    private fun playRelative(delta: Int) {
        if (queue.isEmpty()) return
        queueIndex = (queueIndex + delta + queue.size) % queue.size
        val item = queue[queueIndex]
        prepareAndPlay(item.uri, item.title, item.artist, item.album)
    }

    private fun pausePlayback() {
        mediaPlayer?.takeIf { it.isPlaying }?.pause()
        updatePlaybackState(PlaybackStateCompat.STATE_PAUSED)
        refreshNotification(isPlaying = false)
    }

    private fun resumePlayback() {
        mediaPlayer?.let { player ->
            if (!player.isPlaying) {
                player.start()
                updatePlaybackState(PlaybackStateCompat.STATE_PLAYING)
                refreshNotification(isPlaying = true)
            }
        }
    }

    private fun stopPlayback() {
        releasePlayer()
        updatePlaybackState(PlaybackStateCompat.STATE_NONE)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releasePlayer() {
        mediaPlayer?.runCatching { stop() }
        mediaPlayer?.release()
        mediaPlayer = null
    }

    private fun refreshNotification(isPlaying: Boolean) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(isPlaying))
    }

    private fun buildNotification(isPlaying: Boolean): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            REQUEST_OPEN,
            Intent(this, LarkPlayerActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val previousAction = NotificationCompat.Action(
            android.R.drawable.ic_media_previous,
            "Anterior",
            servicePendingIntent(ACTION_PREVIOUS, REQUEST_PREVIOUS)
        )
        val playPauseAction = if (isPlaying) {
            NotificationCompat.Action(
                android.R.drawable.ic_media_pause,
                "Pausar",
                servicePendingIntent(ACTION_PAUSE, REQUEST_PAUSE)
            )
        } else {
            NotificationCompat.Action(
                android.R.drawable.ic_media_play,
                "Reproduzir",
                servicePendingIntent(ACTION_RESUME, REQUEST_RESUME)
            )
        }
        val nextAction = NotificationCompat.Action(
            android.R.drawable.ic_media_next,
            "Próxima",
            servicePendingIntent(ACTION_NEXT, REQUEST_NEXT)
        )
        val stopAction = NotificationCompat.Action(
            android.R.drawable.ic_menu_close_clear_cancel,
            "Parar",
            servicePendingIntent(ACTION_STOP, REQUEST_STOP)
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(currentTitle)
            .setContentText(currentArtist)
            .setSubText(currentAlbum)
            .setContentIntent(openAppIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .addAction(previousAction)
            .addAction(playPauseAction)
            .addAction(nextAction)
            .addAction(stopAction)
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setMediaSession(mediaSession.sessionToken)
                    .setShowActionsInCompactView(1, 2)
            )
            .build()
    }

    private fun updatePlaybackState(state: Int) {
        val position = mediaPlayer?.currentPosition?.toLong() ?: PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN
        val playbackState = PlaybackStateCompat.Builder()
            .setActions(
                PlaybackStateCompat.ACTION_PLAY or
                    PlaybackStateCompat.ACTION_PAUSE or
                    PlaybackStateCompat.ACTION_PLAY_PAUSE or
                    PlaybackStateCompat.ACTION_STOP or
                    PlaybackStateCompat.ACTION_SEEK_TO or
                    PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                    PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
            )
            .setState(state, position, if (state == PlaybackStateCompat.STATE_PLAYING) 1f else 0f)
            .build()
        mediaSession.setPlaybackState(playbackState)
        mediaSession.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, currentTitle)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, currentArtist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, currentAlbum)
                .build()
        )
    }

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent {
        return PendingIntent.getService(
            this,
            requestCode,
            Intent(this, LarkPlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Reprodução de música",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controles da música em reprodução"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        releasePlayer()
        mediaSession.isActive = false
        mediaSession.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_PLAY = "com.gustaxy.android.action.PLAY"
        const val ACTION_PAUSE = "com.gustaxy.android.action.PAUSE"
        const val ACTION_RESUME = "com.gustaxy.android.action.RESUME"
        const val ACTION_STOP = "com.gustaxy.android.action.STOP"
        const val ACTION_NEXT = "com.gustaxy.android.action.NEXT"
        const val ACTION_PREVIOUS = "com.gustaxy.android.action.PREVIOUS"
        private const val ACTION_MEDIA_BUTTON = "android.intent.action.MEDIA_BUTTON"
        const val EXTRA_URI = "com.gustaxy.android.extra.URI"
        const val EXTRA_TITLE = "com.gustaxy.android.extra.TITLE"
        const val EXTRA_ARTIST = "com.gustaxy.android.extra.ARTIST"
        const val EXTRA_ALBUM = "com.gustaxy.android.extra.ALBUM"
        const val EXTRA_QUEUE_URIS = "com.gustaxy.android.extra.QUEUE_URIS"
        const val EXTRA_QUEUE_TITLES = "com.gustaxy.android.extra.QUEUE_TITLES"
        const val EXTRA_QUEUE_ARTISTS = "com.gustaxy.android.extra.QUEUE_ARTISTS"
        const val EXTRA_QUEUE_ALBUMS = "com.gustaxy.android.extra.QUEUE_ALBUMS"
        const val EXTRA_QUEUE_INDEX = "com.gustaxy.android.extra.QUEUE_INDEX"
        private const val CHANNEL_ID = "lark_playback"
        private const val NOTIFICATION_ID = 412
        private const val SESSION_TAG = "GustaxyLarkPlayback"
        private const val REQUEST_OPEN = 100
        private const val REQUEST_PREVIOUS = 101
        private const val REQUEST_PAUSE = 102
        private const val REQUEST_RESUME = 103
        private const val REQUEST_NEXT = 104
        private const val REQUEST_STOP = 105
    }
}
