package com.gustaxy.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.gustaxy.android.network.ApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Serviço de overlay flutuante.
 *
 * FIX (ícone de manutenção): quando a manutenção está ativa no site admin, o
 * ícone escolhido lá é usado como LargeIcon da notificação E como selo no
 * painel flutuante. O download é validado contra o host permitido e cacheado.
 * Um receiver escuta atualizações de config para trocar o ícone sem reiniciar.
 */
class FloatingOverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {
    private lateinit var windowManager: WindowManager
    private var overlayView: ComposeView? = null
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    @Volatile
    private var maintenanceIcon: Bitmap? = null

    @Volatile
    private var maintenanceActive: Boolean = false

    override val lifecycle: Lifecycle
        get() = lifecycleRegistry

    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    private val configReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_REFRESH_ICON) {
                refreshMaintenanceIcon()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performAttach()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        windowManager = getSystemService(WindowManager::class.java)
        createNotificationChannel()

        val filter = IntentFilter(ACTION_REFRESH_ICON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(configReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(configReceiver, filter)
        }
        refreshMaintenanceIcon()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        if (overlayView == null) showOverlay()
        return START_NOT_STICKY
    }

    /**
     * Busca a config remota e, se a manutenção estiver ativa, baixa o ícone
     * escolhido no admin (validado + cacheado) e atualiza notificação/overlay.
     */
    private fun refreshMaintenanceIcon() {
        serviceScope.launch {
            val api = ApiClient(this@FloatingOverlayService)
            api.config().onSuccess { remote ->
                maintenanceActive = remote.maintenance.enabled
                if (remote.maintenance.enabled && remote.maintenance.imageUrl.isNotBlank()) {
                    api.maintenanceImage(remote.maintenance.imageUrl)
                        .onSuccess { bitmap ->
                            maintenanceIcon = bitmap
                            // Atualiza a notificação em foreground com o LargeIcon.
                            runCatching {
                                getSystemService(NotificationManager::class.java)
                                    ?.notify(NOTIFICATION_ID, buildNotification())
                            }
                            // Recompõe o overlay para exibir o selo.
                            overlayView?.let { view ->
                                runCatching { windowManager.removeView(view) }
                                view.disposeComposition()
                                overlayView = null
                                showOverlay()
                            }
                        }
                }
            }
        }
    }

    private fun showOverlay() {
        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingOverlayService)
            setViewTreeSavedStateRegistryOwner(this@FloatingOverlayService)
            setContent {
                FloatingOverlayContent(
                    maintenanceActive = maintenanceActive,
                    maintenanceIcon = maintenanceIcon,
                    onOpenPlayer = {
                        startActivity(
                            Intent(this@FloatingOverlayService, LarkPlayerActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    },
                    onOpenDashboard = {
                        startActivity(
                            Intent(this@FloatingOverlayService, DashboardActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    },
                    onClose = { stopSelf() }
                )
            }
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12
            y = 86
        }

        runCatching {
            windowManager.addView(view, params)
            overlayView = view
        }.onFailure {
            view.disposeComposition()
            stopSelf()
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this,
            REQUEST_STOP,
            Intent(this, FloatingOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.gustaxy_mark)
            .setContentTitle(if (maintenanceActive) "Manutenção ativa" else "Painel Flutuante Ativo")
            .setContentText(
                if (maintenanceActive) "Servidor em manutenção — toque para parar"
                else "Toque em parar para fechar o Painel"
            )
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", stopIntent)

        // FIX: usa o ícone escolhido no admin como LargeIcon quando disponível.
        maintenanceIcon?.let { builder.setLargeIcon(it) }
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Menu flutuante",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Indica quando o menu sobreposto está ativo"
                    setShowBadge(false)
                }
            )
        }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(configReceiver) }
        serviceScope.cancel()
        overlayView?.let { view ->
            runCatching { windowManager.removeView(view) }
            view.disposeComposition()
        }
        overlayView = null
        maintenanceIcon = null
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.gustaxy.android.action.STOP_FLOATING_OVERLAY"
        const val ACTION_REFRESH_ICON = "com.gustaxy.android.action.REFRESH_MAINTENANCE_ICON"
        private const val CHANNEL_ID = "floating_overlay"
        private const val NOTIFICATION_ID = 913
        private const val REQUEST_STOP = 914

        /** Dispara uma atualização do ícone em um serviço já em execução. */
        fun requestIconRefresh(context: Context) {
            context.sendBroadcast(Intent(ACTION_REFRESH_ICON).setPackage(context.packageName))
        }
    }
}

@Composable
private fun FloatingOverlayContent(
    maintenanceActive: Boolean,
    maintenanceIcon: Bitmap?,
    onOpenPlayer: () -> Unit,
    onOpenDashboard: () -> Unit,
    onClose: () -> Unit,
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var preciseMode by remember { mutableStateOf(false) }
    var responseMode by remember { mutableStateOf(false) }
    var stableMode by remember { mutableStateOf(false) }
    var compactPanel by remember { mutableStateOf(true) }
    var indicators by remember { mutableStateOf(true) }
    var visualFocus by remember { mutableStateOf(false) }
    var auraMode by remember { mutableStateOf(false) }
    var flowMode by remember { mutableStateOf(false) }

    val tabs = listOf("Combate", "Visual", "Místico", "Info")
    val icons = listOf(
        Icons.Outlined.Security,
        Icons.Outlined.Visibility,
        Icons.Outlined.Star,
        Icons.Outlined.Info
    )

    BoxWithConstraints(modifier = Modifier.padding(10.dp)) {
        val panelWidth = (maxWidth - 20.dp).coerceAtMost(338.dp)
        Surface(
            modifier = Modifier.width(panelWidth),
            color = Color.Transparent,
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF161A22), Color(0xFF090B10))
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Selo de manutenção: mostra o ícone escolhido no admin.
                    if (maintenanceActive && maintenanceIcon != null) {
                        Image(
                            bitmap = maintenanceIcon.asImageBitmap(),
                            contentDescription = "Manutenção",
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF202633))
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "GSTX PROXY",
                            color = Color.White,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )
                        Text(
                            text = if (maintenanceActive) "Manutenção ativa" else "@gustaxy Dev",
                            color = if (maintenanceActive) Color(0xFFFF5252) else Color(0xFFFFC107),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.8.sp
                        )
                    }
                    IconButton(onClick = onClose, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Outlined.Close, contentDescription = "Exit", tint = Color.White)
                    }
                }

                Spacer(Modifier.height(10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    tabs.forEachIndexed { index, tab ->
                        Button(
                            onClick = { selectedTab = index },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedTab == index) Color(0xFFFFB800) else Color(0xFF202633),
                                contentColor = if (selectedTab == index) Color(0xFF0B0D11) else Color(0xFFB8C0CF)
                            ),
                            shape = RoundedCornerShape(13.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 9.dp),
                        ) {
                            Icon(icons[index], contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(tab, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(250.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    when (selectedTab) {
                        0 -> {
                            OverlaySwitch("Arquivo 1", "Ainda falta adicionar arquivo+ diretório", preciseMode) { preciseMode = it }
                            OverlaySwitch("Arquivo 2", "Ainda falta adicionar arquivo+ diretório", responseMode) { responseMode = it }
                            OverlaySwitch("Arquivo 3", "Ainda falta adicionar arquivo+ diretório", stableMode) { stableMode = it }
                        }
                        1 -> {
                            OverlaySwitch("Arquivo 4", "Ainda falta adicionar arquivo+ diretório", compactPanel) { compactPanel = it }
                            OverlaySwitch("Arquivo 5", "Ainda falta adicionar arquivo+ diretório", indicators) { indicators = it }
                            OverlaySwitch("Arquivo 6", "Ainda falta adicionar arquivo+ diretório", visualFocus) { visualFocus = it }
                        }
                        2 -> {
                            OverlaySwitch("Arquivo 7", "Ainda falta adicionar arquivo+ diretório", auraMode) { auraMode = it }
                            OverlaySwitch("Arquivo 8", "Ainda falta adicionar arquivo+ diretório", flowMode) { flowMode = it }
                            StatusPill(if (auraMode) "Aura ativa" else "Aura em espera")
                        }
                        else -> {
                            StatusPill("Marca do dispositivo: ${Build.MANUFACTURER}")
                            StatusPill(if (maintenanceActive) "Manutenção: ativa" else "Injeção: estável")
                            Button(
                                onClick = onOpenPlayer,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF252C39)),
                                shape = RoundedCornerShape(14.dp)
                            ) { Text("Abrir player", fontSize = 12.sp) }
                            Button(
                                onClick = onOpenDashboard,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB800), contentColor = Color(0xFF0B0D11)),
                                shape = RoundedCornerShape(14.dp)
                            ) { Text("Abrir dashboard", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "YT : @Gusta_Modz777",
                        color = Color(0xFF6F7889),
                        fontSize = 9.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "V1",
                        color = Color(0xFFFFC107),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun OverlaySwitch(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF121721), RoundedCornerShape(15.dp))
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(description, color = Color(0xFF707A8B), fontSize = 10.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFFFFB800),
                uncheckedThumbColor = Color(0xFFBCC4D2),
                uncheckedTrackColor = Color(0xFF2A303B),
                uncheckedBorderColor = Color(0xFF3A4250)
            )
        )
    }
}

@Composable
private fun StatusPill(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF121721), RoundedCornerShape(15.dp))
            .padding(horizontal = 13.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(
            modifier = Modifier
                .size(8.dp)
                .background(Color(0xFFFFB800), RoundedCornerShape(50))
        )
        Spacer(Modifier.width(9.dp))
        Text(text, color = Color(0xFFE6EAF1), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
