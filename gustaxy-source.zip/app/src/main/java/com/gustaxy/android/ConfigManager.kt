package com.gustaxy.android

import android.content.Context
import com.gustaxy.android.security.Injector
import java.io.File
import java.util.concurrent.locks.ReentrantLock

/**
 * Gerencia o local_config.json — a ponte entre o loader (Kotlin) e a libproxy.so (C++).
 *
 * Destino final lido pela lib:
 * /storage/emulated/0/Android/data/com.dts.freefiremax/files/local_config.json
 *
 * Como o app não tem acesso direto à pasta Android/data de outro app (Android 11+),
 * o JSON é gravado primeiro na pasta externa do próprio loader e copiado ao destino
 * via shell do Shizuku (que tem acesso total ao armazenamento).
 *
 * ESTABILIDADE:
 * - Uma [ReentrantLock] serializa salvar/carregar: nunca existem duas operações
 *   Shizuku simultâneas a partir daqui, mesmo vindo de threads diferentes.
 * - carregarConfig() NÃO usa Shizuku: lê apenas o backup local do app. Isso
 *   elimina I/O de binder na inicialização da UI e qualquer corrida entre o
 *   carregamento inicial e os salvamentos disparados pelos switches.
 *
 * OBSERVABILIDADE: cada etapa é registrada no [LogManager] (aba Terminal).
 */
object ConfigManager {

    data class Config(
        val modEnabled: Boolean,
        val menuFlutuante: Boolean
    )

    private const val TAG = "CONFIG"

    /** Serializa TODAS as operações de config (salvar/carregar), em qualquer thread. */
    private val trava = ReentrantLock()

    private fun montarJson(config: Config): String = """
        {
            "mod_enabled": ${config.modEnabled},
            "floating_menu": ${config.menuFlutuante}
        }
    """.trimIndent()

    /**
     * Salva o JSON localmente e copia para a pasta do FF MAX via Shizuku.
     * Bloqueante — chame sempre fora da main thread (a HomeTab já faz isso).
     */
    fun salvarConfig(context: Context, config: Config): Boolean {
        trava.lock()
        return try {
            LogManager.i(TAG, "💾 Salvando config: mod_enabled=${config.modEnabled}, floating_menu=${config.menuFlutuante}")
            val json = montarJson(config)

            // Backup na pasta interna do app
            File(context.filesDir, "local_config_backup.json").writeText(json)

            // Staging na pasta externa do loader (o shell do Shizuku lê daqui)
            val staging = File(context.getExternalFilesDir(null), "local_config.json")
            staging.writeText(json)
            LogManager.i(TAG, "Staging gravado em ${staging.absolutePath}")

            val destinoDir = File(Injector.CAMINHO_CONFIG_JOGO).parent
            val r = Injector.executarComando(
                "mkdir -p '$destinoDir' && cp '${staging.absolutePath}' " +
                    "'${Injector.CAMINHO_CONFIG_JOGO}' && chmod 644 '${Injector.CAMINHO_CONFIG_JOGO}'"
            )
            val ok = !r.startsWith("ERRO") && !r.contains("Permission denied", true)
            if (ok) {
                LogManager.ok(TAG, "✅ Config copiado para a pasta do jogo")
            } else {
                LogManager.e(TAG, "❌ Falha ao copiar config para o jogo: $r")
            }
            ok
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ Exceção ao salvar config: ${e.javaClass.simpleName}: ${e.message}")
            false
        } finally {
            trava.unlock()
        }
    }

    /**
     * Lê o config salvo. NÃO usa Shizuku: apenas o backup local do app
     * (rápido, seguro para a inicialização da UI e sem risco de corrida
     * com os salvamentos). O estado do jogo é sempre gravado por este app
     * antes, então o backup local é a fonte de verdade para a UI.
     */
    fun carregarConfig(context: Context): Config {
        trava.lock()
        return try {
            val json = runCatching {
                File(context.filesDir, "local_config_backup.json").readText()
            }.getOrNull()

            if (json == null) {
                LogManager.i(TAG, "Nenhum config salvo ainda — usando padrão (mod off, menu on)")
                return Config(modEnabled = false, menuFlutuante = true)
            }

            Config(
                modEnabled = json.contains("\"mod_enabled\": true"),
                menuFlutuante = json.contains("\"floating_menu\": true")
            ).also {
                LogManager.i(TAG, "Config carregado do backup local: mod_enabled=${it.modEnabled}, floating_menu=${it.menuFlutuante}")
            }
        } finally {
            trava.unlock()
        }
    }
}
