package com.gustaxy.android.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.gustaxy.android.BuildConfig
import com.gustaxy.android.security.NativeSecurity
import com.gustaxy.android.security.SecureSessionStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URL
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Cliente de API endurecido.
 *
 * Segurança:
 *  - A base URL NÃO vem de uma constante: é construída em runtime pelo nativo
 *    (shards ofuscados). BuildConfig.API_BASE_URL é apenas hint de debug;
 *    em release a fonte da verdade é o C++.
 *  - Toda chamada passa por um checkpoint nativo independente (quórum).
 *  - O login envia o bitmask de integridade para o servidor (banimento).
 *  - O download do ícone de manutenção valida host permitido + cacheia.
 */
class ApiClient(context: Context) {
    private val appContext = context.applicationContext
    private val session = SecureSessionStore(appContext)

    // Base URL dinâmica: preferência ao nativo; fallback ao BuildConfig só em debug.
    private val baseUrl: String = (
        NativeSecurity.primaryUrl()
            ?: if (BuildConfig.DEBUG) BuildConfig.API_BASE_URL else ""
        ).trimEnd('/').let { if (it.endsWith("/api/v1")) it else "$it/api/v1" }

    private val primaryHost = runCatching { URL(baseUrl).host.lowercase() }.getOrDefault("")
    private val fallbackHost = NativeSecurity.fallbackHost()
    private val virtualHostFallbackBaseUrl = fallbackHost?.let { "https://$it/api/v1" }
    private val virtualHostFallbackName = primaryHost
    private val canUseVirtualHostFallback =
        !BuildConfig.DEBUG &&
            primaryHost.isNotBlank() &&
            !virtualHostFallbackBaseUrl.isNullOrBlank() &&
            baseUrl.startsWith("https://")

    // Hosts permitidos para baixar a imagem de manutenção (anti-SSRF local).
    private val allowedImageHosts: Set<String>
        get() = buildSet {
            if (primaryHost.isNotBlank()) add(primaryHost)
            fallbackHost?.let { add(it) }
        }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .apply {
            CertificatePinning.createOrNull()?.let(::certificatePinner)
        }
        .build()

    data class LoginResult(val token: String, val expiresAt: String, val keyExpiresAt: String)
    data class SessionInfo(val keyExpiresAt: String, val keysPaused: Boolean)
    data class MaintenanceInfo(val enabled: Boolean, val title: String, val description: String, val imageUrl: String)
    data class RemoteConfig(val maintenance: MaintenanceInfo, val keysPaused: Boolean)

    suspend fun config(): Result<RemoteConfig> = withContext(Dispatchers.IO) {
        if (!guardCheckpoint()) return@withContext Result.failure(IOException("Ambiente inválido."))
        val response = runCatching { request("/config", "GET", null, null) }
            .getOrElse { return@withContext Result.failure(IOException("Servidor indisponível.")) }
        if (response.code !in 200..299) return@withContext Result.failure(IOException(response.errorMessage()))
        runCatching {
            val body = JSONObject(response.body)
            val maintenance = body.optJSONObject("maintenance") ?: JSONObject()
            RemoteConfig(
                maintenance = MaintenanceInfo(
                    enabled = maintenance.optBoolean("enabled", false),
                    title = maintenance.optString("title", "Manutenção programada"),
                    description = maintenance.optString("description", "Tente novamente mais tarde."),
                    imageUrl = maintenance.optString("image_url", "")
                ),
                keysPaused = body.optBoolean("keys_paused", false)
            )
        }
    }

    /**
     * Baixa a imagem de manutenção com validação de host e cache em disco.
     * - Só aceita https e host na allowlist (primary/fallback).
     * - Cacheia pelo hash da URL; reutiliza enquanto a URL não mudar.
     */
    suspend fun maintenanceImage(imageUrl: String): Result<Bitmap?> = withContext(Dispatchers.IO) {
        if (imageUrl.isBlank()) return@withContext Result.success(null)
        runCatching {
            val target = URL(imageUrl)
            if (target.protocol != "https" || !allowedImageHosts.contains(target.host.lowercase())) {
                throw IOException("Imagem não autorizada")
            }
            cachedMaintenanceImage(target) ?: downloadImage(target)?.also { cacheMaintenanceImage(target, it) }
        }
    }

    private fun cacheFileFor(target: URL): File {
        val key = MessageDigest.getInstance("SHA-256")
            .digest(target.toString().toByteArray())
            .joinToString("") { "%02x".format(it) }
        return File(appContext.cacheDir, "maint_$key.img")
    }

    private fun cachedMaintenanceImage(target: URL): Bitmap? {
        val file = cacheFileFor(target)
        if (!file.exists() || file.length() == 0L || file.length() > 2_097_152) return null
        return runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()
    }

    private fun cacheMaintenanceImage(target: URL, bitmap: Bitmap) {
        runCatching {
            val file = cacheFileFor(target)
            FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
        }
    }

    private fun downloadImage(target: URL): Bitmap? {
        return try {
            downloadImageOnce(target)
        } catch (error: IOException) {
            if (!canUseVirtualHostFallback || virtualHostFallbackBaseUrl == null || fallbackHost == null) throw error
            val fallbackTarget = URL("$virtualHostFallbackBaseUrl${target.file}")
            downloadImageOnce(fallbackTarget, virtualHostFallbackName)
        }
    }

    private fun downloadImageOnce(target: URL, hostOverride: String? = null): Bitmap? {
        val request = Request.Builder()
            .url(target)
            .get()
            .header("Accept", "image/*")
            .header("Cache-Control", "no-store")
            .apply {
                if (!hostOverride.isNullOrBlank()) header("Host", hostOverride)
            }
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Imagem indisponível")
            val body = response.body ?: throw IOException("Imagem indisponível")
            if (body.contentLength() > 2_097_152) throw IOException("Imagem muito grande")
            val bytes = body.byteStream().use { it.readBytes() }
            if (bytes.size > 2_097_152) throw IOException("Imagem muito grande")
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }
    }

    suspend fun login(
        key: String,
        deviceId: String,
        deviceName: String,
        appVersion: String,
        androidVersion: String,
        integrity: Map<String, String>
    ): Result<LoginResult> = withContext(Dispatchers.IO) {
        if (!guardCheckpoint()) return@withContext Result.failure(IOException("Ambiente inválido."))
        if (!BuildConfig.DEBUG && !baseUrl.startsWith("https://")) {
            return@withContext Result.failure(IOException("API insegura"))
        }
        val json = JSONObject().apply {
            put("key", key.trim())
            put("device_id", deviceId)
            put("device_name", deviceName)
            put("app_version", appVersion)
            put("android_version", androidVersion)
            // Bitmask de integridade para o servidor decidir banimento.
            put("integrity_flags", NativeSecurity.flagsForServer())
            integrity.forEach { (name, value) -> put(name, value) }
        }
        val response = runCatching { request("/auth/login", "POST", json.toString(), null) }
            .getOrElse { return@withContext Result.failure(IOException("Servidor indisponível.")) }
        if (response.code !in 200..299) return@withContext Result.failure(IOException(response.errorMessage()))
        runCatching {
            val body = JSONObject(response.body)
            val token = body.getString("token")
            LoginResult(token, body.optString("expires_at"), body.optString("key_expires_at")).also {
                session.saveKey(key.trim())
                session.saveToken(token)
            }
        }
    }

    suspend fun current(): Result<SessionInfo> = withContext(Dispatchers.IO) {
        if (!guardCheckpoint()) return@withContext Result.failure(IOException("Ambiente inválido."))
        val token = session.readToken() ?: return@withContext Result.failure(IOException("Sessão ausente"))
        val response = runCatching { request("/auth/me", "GET", null, token) }
            .getOrElse { return@withContext Result.failure(IOException("Servidor indisponível.")) }
        if (response.code !in 200..299) {
            session.clearToken()
            return@withContext Result.failure(IOException(response.errorMessage()))
        }
        runCatching {
            val body = JSONObject(response.body)
            SessionInfo(
                keyExpiresAt = body.optString("key_expires_at"),
                keysPaused = body.optBoolean("keys_paused", false)
            )
        }
    }

    suspend fun logout(): Result<Unit> = withContext(Dispatchers.IO) {
        val token = session.readToken()
        if (token != null) runCatching { request("/auth/logout", "POST", "{}", token) }
        session.clearToken()
        Result.success(Unit)
    }

    fun savedKey(): String? = session.readKey()
    fun hasSession(): Boolean = session.readToken() != null

    /**
     * Guarda de quórum chamada antes de CADA request. Em release, se o
     * checkpoint falhar, aplica o enforcement híbrido (fecha silencioso).
     */
    private fun guardCheckpoint(): Boolean {
        if (BuildConfig.DEBUG) return true
        return NativeSecurity.enforceOrDie(appContext)
    }

    private fun request(path: String, method: String, body: String?, bearer: String?): Response {
        return try {
            requestOnce(baseUrl, path, method, body, bearer)
        } catch (error: IOException) {
            if (!canUseVirtualHostFallback || virtualHostFallbackBaseUrl == null || fallbackHost == null) throw error
            requestOnce(virtualHostFallbackBaseUrl, path, method, body, bearer, virtualHostFallbackName)
        }
    }

    private fun requestOnce(
        rootUrl: String,
        path: String,
        method: String,
        body: String?,
        bearer: String?,
        hostOverride: String? = null
    ): Response {
        val builder = Request.Builder()
            .url(rootUrl + path)
            .header("Accept", "application/json")
            .header("Cache-Control", "no-store")
            .header("X-Request-Nonce", UUID.randomUUID().toString())
            .header("X-Gustaxy-App", BuildConfig.APPLICATION_ID)
        if (bearer != null) builder.header("Authorization", "Bearer $bearer")
        if (!hostOverride.isNullOrBlank()) builder.header("Host", hostOverride)
        val requestBody = body?.toRequestBody("application/json; charset=utf-8".toMediaType())
        builder.method(method, requestBody)
        client.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            return Response(response.code, text)
        }
    }

    private data class Response(val code: Int, val body: String) {
        fun errorMessage(): String = runCatching {
            JSONObject(body).optString("error", "Falha na comunicação.")
        }.getOrDefault("Falha na comunicação.")
    }
}
