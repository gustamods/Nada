package com.gustaxy.android.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import com.gustaxy.android.BuildConfig
import java.io.FileInputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import kotlin.system.exitProcess

/**
 * Camada nativa de integridade e hardening — v2 (paranoica).
 *
 * Modelo anti-bypass:
 *  - NENHUM ponto único de decisão. Cada chamada sensível executa um
 *    checkpoint próprio (nativo + Java) e cruza os resultados.
 *  - A detecção é HÍBRIDA: na 1ª violação o app fecha silenciosamente;
 *    violações persistentes fazem o próximo request entregar o bitmask de
 *    integridade ao servidor, que marca o device_id como banido.
 *  - Um watchdog nativo roda em thread própria (15–45s aleatório) e um
 *    heartbeat por timestamp é conferido a cada checkpoint — se alguém
 *    congelar a thread, o silêncio é detectado.
 */
object NativeSecurity {
    private var nativeLoaded = false

    private val localViolations = AtomicInteger(0)

    init {
        nativeLoaded = try {
            System.loadLibrary("gusta")
            runCatching { nativeArm() }
            true
        } catch (_: UnsatisfiedLinkError) {
            false
        } catch (_: Throwable) {
            false
        }
    }

    private external fun nativeSha256(data: ByteArray): ByteArray
    private external fun nativeHashInit(): Long
    private external fun nativeHashUpdate(handle: Long, chunk: ByteArray, len: Int)
    private external fun nativeHashFinal(handle: Long): ByteArray
    private external fun nativeIntegritySignal(certHash: ByteArray, apkHash: ByteArray, deviceId: String, nonce: String): String
    private external fun nativeSecureEquals(a: String, b: String): Boolean
    private external fun nativeDebuggerAttached(): Boolean
    private external fun nativeFridaDetected(): Boolean
    private external fun nativeEmulatorDetected(): Boolean
    private external fun nativeFallbackHost(): String
    private external fun nativePrimaryUrl(): String
    private external fun nativeCheckpoint(): Int
    private external fun nativeArm()

    data class Report(
        val nativeLoaded: Boolean,
        val certificateSha256: String,
        val apkSha256: String,
        val signatureMatches: Boolean,
        val apkMatches: Boolean,
        val debuggerAttached: Boolean,
        val fridaDetected: Boolean,
        val emulatorDetected: Boolean,
        val rooted: Boolean,
        val fridaPortOpen: Boolean,
        val nativeFlags: Int,
        val nonce: String,
        val nativeSignal: String,
    ) {
        /**
         * Quórum de aceitação: TODOS os sinais limpos E checkpoint nativo == 0.
         * Um único hook em `acceptable` não basta: os callsites também usam
         * [quickCheckpoint] e [enforceOrDie] de forma independente.
         */
        val acceptable: Boolean
            get() = nativeLoaded &&
                signatureMatches &&
                apkMatches &&
                !debuggerAttached &&
                !fridaDetected &&
                !emulatorDetected &&
                !rooted &&
                !fridaPortOpen &&
                nativeFlags == 0
    }

    fun inspect(context: Context, deviceId: String): Report {
        val certBytes = if (nativeLoaded) certificateBytes(context) else null
        val certDigest = certBytes?.let { runCatching { nativeSha256(it) }.getOrNull() }
        val apkDigest = if (nativeLoaded) nativeFileSha256(context.applicationInfo.sourceDir) else null
        val cert = certDigest?.let { hex(it) } ?: ""
        val apk = apkDigest?.let { hex(it) } ?: ""
        val expectedCert = normalize(BuildConfig.EXPECTED_CERT_SHA256)
        val expectedApk = normalize(BuildConfig.EXPECTED_APK_SHA256)
        val nonce = UUID.randomUUID().toString()
        val signal = if (nativeLoaded && certDigest != null && apkDigest != null) {
            runCatching { nativeIntegritySignal(certDigest, apkDigest, deviceId, nonce) }.getOrDefault("")
        } else ""

        val debuggerAttached = Debug.isDebuggerConnected() ||
            Debug.waitingForDebugger() ||
            (nativeLoaded && runCatching { nativeDebuggerAttached() }.getOrDefault(false))
        val fridaDetected = (nativeLoaded && runCatching { nativeFridaDetected() }.getOrDefault(false))
        val emulatorDetected = (nativeLoaded && runCatching { nativeEmulatorDetected() }.getOrDefault(false))
        val rooted = isRooted(context)
        val fridaPort = fridaPortOpen() || fridaPortOpen(27043)
        val flags = if (nativeLoaded) runCatching { nativeCheckpoint() }.getOrDefault(64) else 64

        return Report(
            nativeLoaded = nativeLoaded,
            certificateSha256 = cert,
            apkSha256 = apk,
            signatureMatches = expectedCert.isBlank() ||
                (nativeLoaded && cert.isNotBlank() && nativeSecureEquals(cert, expectedCert)),
            apkMatches = expectedApk.isBlank() ||
                (nativeLoaded && apk.isNotBlank() && nativeSecureEquals(apk, expectedApk)),
            debuggerAttached = debuggerAttached,
            fridaDetected = fridaDetected,
            emulatorDetected = emulatorDetected,
            rooted = rooted,
            fridaPortOpen = fridaPort,
            nativeFlags = flags,
            nonce = nonce,
            nativeSignal = signal,
        )
    }

    /**
     * Checkpoint rápido para ser chamado ANTES de qualquer operação sensível
     * (login, request HTTP, dashboard, overlay). Não reusa o resultado de
     * [inspect]: executa verificações novas e independentes.
     */
    fun quickCheckpoint(context: Context): Boolean {
        if (BuildConfig.DEBUG) return true
        if (!nativeLoaded) return false
        val flags = runCatching { nativeCheckpoint() }.getOrDefault(64)
        if (flags != 0) return false
        if (Debug.isDebuggerConnected() || fridaPortOpen()) return false
        val certBytes = certificateBytes(context) ?: return false
        val expectedCert = normalize(BuildConfig.EXPECTED_CERT_SHA256)
        if (expectedCert.isNotBlank()) {
            val cert = runCatching { nativeSha256(certBytes) }.getOrNull() ?: return false
            if (!nativeSecureEquals(hex(cert), expectedCert)) return false
        }
        return true
    }

    /**
     * Enforcement híbrido: fecha silencioso na 1ª detecção; em reincidência
     * o servidor bane o device_id (o login entrega `integrity_flags`).
     */
    fun enforceOrDie(context: Context): Boolean {
        if (BuildConfig.DEBUG) return true
        val ok = quickCheckpoint(context)
        if (!ok) {
            localViolations.incrementAndGet()
            exitProcess(0)
        }
        return true
    }

    /** Bitmask de flags para envio ao servidor no login. */
    fun flagsForServer(): String {
        if (!nativeLoaded) return "64"
        return runCatching { nativeCheckpoint() }.getOrDefault(64).toString()
    }

    fun fallbackHost(): String? = if (!nativeLoaded) null else {
        runCatching { nativeFallbackHost() }
            .getOrNull()
            ?.trim()
            ?.takeIf { it.isNotEmpty() && it.matches(Regex("^[a-z0-9.-]+$")) }
    }

    /** URL primária construída em runtime pelo nativo (shards ofuscados). */
    fun primaryUrl(): String? = if (!nativeLoaded) null else {
        runCatching { nativePrimaryUrl() }
            .getOrNull()
            ?.trim()
            ?.takeIf { it.startsWith("https://") }
    }

    fun isRooted(context: Context): Boolean {
        val suPaths = arrayOf(
            "/system/xbin/su", "/system/bin/su", "/sbin/su",
            "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
            "/system/bin/failsafe/su", "/su/bin/su", "/data/adb/magisk",
            "/sbin/.magisk", "/data/adb/ksu", "/data/adb/ap"
        )
        if (suPaths.any { java.io.File(it).exists() }) return true

        val rootApps = arrayOf(
            "com.topjohnwu.magisk", "com.kingroot.kinguser",
            "com.noshufou.android.su", "eu.chainfire.supersu",
            "me.weishu.kernelsu", "com.franco.kernel", "io.github.huskydg.magisk"
        )
        if (rootApps.any { packageInstalled(context, it) }) return true

        val tags = Build.TAGS
        if (tags != null && tags.contains("test-keys")) return true

        return runCatching {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            try {
                process.waitFor() == 0
            } finally {
                process.destroy()
            }
        }.getOrDefault(false)
    }

    private fun packageInstalled(context: Context, packageName: String): Boolean = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(packageName, 0)
        }
        true
    }.getOrDefault(false)

    private fun fridaPortOpen(port: Int = 27042): Boolean = runCatching {
        Socket().use { socket ->
            socket.connect(InetSocketAddress("127.0.0.1", port), 180)
            true
        }
    }.getOrDefault(false)

    private fun certificateBytes(context: Context): ByteArray? = runCatching {
        val packageInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
        }
        val signature = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.signingInfo?.apkContentsSigners?.firstOrNull()
        } else {
            @Suppress("DEPRECATION")
            packageInfo.signatures?.firstOrNull()
        } ?: return@runCatching null
        signature.toByteArray()
    }.getOrNull()

    private fun nativeFileSha256(path: String): ByteArray? {
        val handle = runCatching { nativeHashInit() }.getOrNull()?.takeIf { it != 0L } ?: return null
        var finalized = false
        return try {
            FileInputStream(path).use { input ->
                val buffer = ByteArray(8192)
                while (true) {
                    val count = input.read(buffer)
                    if (count <= 0) break
                    nativeHashUpdate(handle, buffer, count)
                }
            }
            nativeHashFinal(handle).also { finalized = true }
        } catch (_: Exception) {
            null
        } finally {
            if (!finalized) runCatching { nativeHashFinal(handle) }
        }
    }

    private fun normalize(value: String): String = value
        .replace(":", "")
        .replace("-", "")
        .trim()
        .uppercase(Locale.ROOT)

    private fun hex(bytes: ByteArray): String = bytes.joinToString("") {
        "%02X".format(Locale.ROOT, it)
    }
}
