package com.gustaxy.android

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Logout
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.gustaxy.android.network.ApiClient
import com.gustaxy.android.security.DeviceInfo
import com.gustaxy.android.security.NativeSecurity
import com.gustaxy.android.ui.theme.GustaxyAndroidTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startIntegrityWatchdog()
        setContent {
            GustaxyAndroidTheme {
                DashboardScreen(
                    onUnauthorized = {
                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                    },
                    onLogout = {
                        lifecycleScope.launch {
                            ApiClient(this@DashboardActivity).logout()
                            startActivity(Intent(this@DashboardActivity, LoginActivity::class.java))
                            finish()
                        }
                    }
                )
            }
        }
    }

    /**
     * Watchdog do dashboard: intervalo ALEATÓRIO (18–42s), checkpoint nativo
     * independente (não reusa Report), enforcement híbrido (fecha silencioso
     * na 1ª violação; persistência → banimento no servidor via próximo login).
     * O watchdog nativo (thread C++ 15–45s) corre em paralelo — duas camadas
     * que se cobrem: se o atacante matar uma, a outra detecta o silêncio.
     */
    private fun startIntegrityWatchdog() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.RESUMED) {
                while (isActive) {
                    val waitMs = 18_000L + kotlin.random.Random.nextLong(0L, 24_000L)
                    kotlinx.coroutines.delay(waitMs)
                    if (BuildConfig.DEBUG) continue
                    val clean = withContext(Dispatchers.Default) {
                        NativeSecurity.quickCheckpoint(this@DashboardActivity)
                    }
                    if (!clean) {
                        // Encerramento silencioso (sem toast, sem redirect com log).
                        runCatching { ApiClient(this@DashboardActivity).logout() }
                        finishAffinity()
                        kotlin.system.exitProcess(0)
                    }
                }
            }
        }
    }
}

/**
 * Casca do Dashboard: cabeçalho, NavigationBar e troca de aba.
 * O conteúdo de cada aba mora em HomeTab.kt / ConnectionTab.kt / InfoTab.kt.
 * O StatusCard usado pelas três abas mora em DashboardComponents.kt.
 */
@Composable
private fun DashboardScreen(onUnauthorized: () -> Unit, onLogout: () -> Unit) {
    val context = LocalContext.current
    var session by remember { mutableStateOf<ApiClient.SessionInfo?>(null) }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var refreshKey by remember { mutableIntStateOf(0) }
    LaunchedEffect(refreshKey) {
        LogManager.i("APP", "Dashboard carregado — buscando sessão")
        ApiClient(context).current()
            .onSuccess {
                session = it
                LogManager.ok("APP", "Sessão ativa: usuário autenticado")
            }
            .onFailure {
                LogManager.e("APP", "Sessão inválida/expirada: ${it.message} — voltando ao login")
                onUnauthorized()
            }
    }
    val activeSession = session ?: return
    val tabs = listOf("Início", "Conexão", "Info", "Terminal", "Sair")
    val icons = listOf(Icons.Outlined.Home, Icons.Outlined.Wifi, Icons.Outlined.Info, Icons.Outlined.Terminal, Icons.Outlined.Logout)

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF05070D)) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D1422), tonalElevation = 0.dp) {
                    tabs.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { if (index == 4) onLogout() else selectedTab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Color.White,
                                indicatorColor = Color(0xFF245DCD),
                                unselectedIconColor = Color(0xFF8392AA),
                                unselectedTextColor = Color(0xFF8392AA)
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color(0xFF09101D), Color(0xFF05070D)))
                ).padding(innerPadding).padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedTab = 0 }) {
                        Icon(painterResource(R.drawable.gustaxy_mark), contentDescription = "Gustaxy", tint = Color.Unspecified, modifier = Modifier.size(42.dp))
                    }
                    Text("Gustaxy", modifier = Modifier.padding(start = 8.dp), color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.weight(1f))
                    IconButton(onClick = { refreshKey++ }) { Icon(Icons.Outlined.Refresh, contentDescription = "Atualizar", tint = Color(0xFFB9C8E4)) }
                }
                Spacer(modifier = Modifier.height(20.dp))
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (selectedTab) {
                        0 -> HomeTab(activeSession)
                        1 -> ConnectionTab(activeSession)
                        2 -> InfoTab()
                        3 -> TerminalTab()
                        else -> InfoTab()
                    }
                }
            }
        }
    }
}
