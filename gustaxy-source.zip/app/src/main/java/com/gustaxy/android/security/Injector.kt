package com.gustaxy.android.security

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.gustaxy.android.LogManager
import rikka.shizuku.Shizuku
import java.io.File
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock

/**
 * Executor de comandos shell via Shizuku (privilégio de ADB/Shell, sem root)
 * + preparação da libproxy.so e injeção no Free Fire MAX (com.dts.freefiremax).
 *
 * Fluxo: a lib sai dos assets do APK -> /data/local/tmp/gustaxy/ -> o binário
 * injetor (ptrace, etapa C++) faz o dlopen dentro do processo do jogo.
 *
 * Os comandos rodam no [ShellService] (UserService do Shizuku), que substitui o
 * antigo Shizuku.newProcess() — privado/descontinuado desde a API 13.1.x.
 *
 * ESTABILIDADE (correção do IllegalThreadStateException / race conditions):
 * - TODAS as chamadas passam por um [ReentrantLock]: nunca existem dois ciclos
 *   bind/execução simultâneos, mesmo que UI e threads de fundo chamem juntas.
 * - O serviço fica vinculado UMA vez e é reutilizado (cache de binder). Não há
 *   mais unbind a cada comando — era isso que criava a janela de corrida entre
 *   bindUserService -> callback -> unbindUserService compartilhando conexão.
 * - A fila de espera do binder é LOCAL a cada (re)vínculo: nenhuma resposta de
 *   conexão pode ser consumida pela operação errada.
 * - Se o binder morrer (Shizuku reiniciado etc.), o cache é invalidado via
 *   DeathRecipient e o próximo comando refaz o vínculo automaticamente.
 *
 * OBSERVABILIDADE: cada etapa é registrada no [LogManager] (aba Terminal):
 * bind, conexão, morte do binder, cada comando enviado e sua saída completa.
 */
object Injector {

    const val PACOTE_JOGO = "com.dts.freefiremax"
    const val NOME_LIB = "libproxy.so"
    const val CAMINHO_CONFIG_JOGO =
        "/storage/emulated/0/Android/data/com.dts.freefiremax/files/local_config.json"

    /** Pasta do shell (uid 2000) onde a lib fica pronta para o injetor. */
    private const val DIR_TMP = "/data/local/tmp/gustaxy"

    private const val VERSAO_SERVICO = 1
    private const val TIMEOUT_BIND_MS = 10_000L
    private const val TAG = "SHIZUKU"

    /**
     * Args do UserService: o `tag` é estável mesmo com R8/ProGuard, como
     * recomenda a documentação oficial do Shizuku (o nome da classe não é).
     */
    private val userServiceArgs =
        Shizuku.UserServiceArgs(
            ComponentName(com.gustaxy.android.BuildConfig.APPLICATION_ID, ShellService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("shell_service")
            .debuggable(false)
            .tag("gustaxy_shell")
            .version(VERSAO_SERVICO)

    data class Resultado(val sucesso: Boolean, val mensagem: String)

    // ---------------------------------------------------------------------
    // Serialização global: uma operação Shizuku por vez, em qualquer thread.
    // ---------------------------------------------------------------------
    private val trava = ReentrantLock()

    /** Binder/serviço em cache — reutilizado entre comandos enquanto estiver vivo. */
    @Volatile private var binderAtual: IBinder? = null
    @Volatile private var servicoAtual: IShellService? = null

    /** Executa um comando shell com privilégio de ADB via Shizuku (UserService). */
    fun executarComando(comando: String): String {
        trava.lock()
        return try {
            LogManager.c(TAG, "$ $comando")
            runCatching {
                val saida = obterServico().executar(comando)
                val resumo = if (saida.length > 1500) saida.take(1500) + "… [truncado]" else saida
                if (saida.startsWith("ERRO")) {
                    LogManager.e(TAG, "↩ ${resumo.ifBlank { "(sem saída)" }}")
                } else {
                    LogManager.ok(TAG, "↩ ${resumo.ifBlank { "(ok, sem saída)" }}")
                }
                saida
            }.getOrElse { e ->
                LogManager.e(TAG, "↩ Exceção ao executar: ${e.javaClass.simpleName}: ${e.message}")
                "ERRO: ${e.message}"
            }
        } finally {
            trava.unlock()
        }
    }

    /** Retorna o PID do processo do jogo, ou -1 se não estiver aberto. */
    fun pegarPidJogo(pacote: String = PACOTE_JOGO): Int {
        val saida = executarComando("pidof $pacote")
        val pid = saida.trim().split(" ").firstOrNull()?.toIntOrNull() ?: -1
        LogManager.i(TAG, "pidof $pacote → $pid")
        return pid
    }

    /** Abre o jogo simulando o toque no ícone (comando monkey). */
    fun abrirJogo(pacote: String = PACOTE_JOGO): Boolean {
        LogManager.i(TAG, "🎮 Abrindo o jogo: $pacote")
        val r = executarComando("monkey -p $pacote -c android.intent.category.LAUNCHER 1")
        val ok = !r.startsWith("ERRO")
        if (ok) LogManager.ok(TAG, "Comando de abertura enviado") else LogManager.e(TAG, "Falha ao abrir o jogo: $r")
        return ok
    }

    /** Extrai um arquivo dos assets do APK para a pasta interna do app. */
    private fun extrairAsset(context: Context, nome: String): File? {
        return runCatching {
            // CORREÇÃO: usa a pasta EXTERNA do app (/sdcard/Android/data/<pkg>/files).
            // O shell do Shizuku (uid 2000) NÃO consegue ler a pasta interna
            // (/data/user/0/<pkg>/files) por causa do SELinux — era isso que
            // causava "cp: bad ... Permission denied" e o injetor nunca era
            // criado em /data/local/tmp (erro 127). A pasta externa o shell lê
            // sem problema (o fluxo do config.json já prova isso no log).
            val destino = File(context.getExternalFilesDir(null), nome)
            context.assets.open(nome).use { entrada ->
                destino.outputStream().use { saida -> entrada.copyTo(saida) }
            }
            destino
        }.getOrNull()
    }

    /**
     * Copia a libproxy.so (embutida nos assets) para /data/local/tmp/gustaxy/
     * com permissão de execução/leitura, pronta para o injetor.
     */
    fun prepararLib(context: Context): Resultado {
        val local = extrairAsset(context, NOME_LIB)
            ?: return Resultado(false, "\u274c $NOME_LIB n\u00e3o encontrada nos assets do APK")
        val r = executarComando(
            "mkdir -p $DIR_TMP && cp '${local.absolutePath}' $DIR_TMP/$NOME_LIB " +
                "&& chmod 755 $DIR_TMP/$NOME_LIB && test -s $DIR_TMP/$NOME_LIB && ls -l $DIR_TMP/$NOME_LIB"
        )
        // Só declara sucesso se o arquivo EXISTIR de verdade (test -s) e não
        // houver erro de permissão — antes ele mentia sucesso mesmo com o cp falhando.
        val falhou = r.contains("Permission denied") || r.contains("bad '") ||
            r.contains("No such file") || r.startsWith("ERRO")
        return if (!falhou && r.contains(NOME_LIB)) {
            Resultado(true, "\u2705 Lib preparada em $DIR_TMP/$NOME_LIB")
        } else {
            Resultado(false, "\u274c Falha ao copiar a lib: $r")
        }
    }

    /**
     * Injeta a lib no processo do jogo.
     * Requer o binário injetor (ptrace -> dlopen) em assets/injector — etapa C++.
     * Enquanto ele não existir, a função prepara tudo e avisa o que falta.
     */
    fun injetarLib(context: Context): Resultado {
        LogManager.i(TAG, "\ud83d\udc89 Iniciando inje\u00e7\u00e3o da $NOME_LIB (modo launch: injeta no nascimento do processo)...")

        val injetorLocal = extrairAsset(context, "injector")
            ?: return Resultado(false, "\u274c Bin\u00e1rio 'injector' n\u00e3o encontrado nos assets")
                    .also { LogManager.e(TAG, it.mensagem) }
        LogManager.i(TAG, "Asset extra\u00eddo: injector \u2192 ${injetorLocal.absolutePath} (${injetorLocal.length()} bytes)")

        val prep = executarComando(
            "mkdir -p $DIR_TMP && cp '${injetorLocal.absolutePath}' $DIR_TMP/injetor " +
                "&& chmod 755 $DIR_TMP/injetor && test -x $DIR_TMP/injetor && echo __PREP_OK__"
        )
        if (!prep.contains("__PREP_OK__")) {
            return Resultado(false, "\u274c Falha ao preparar o injetor em $DIR_TMP: $prep")
                .also { LogManager.e(TAG, it.mensagem) }
        }

        // MODO LAUNCH: o injetor for\u00e7a o fechamento do jogo, relan\u00e7a o
        // processo e injeta a lib logo no nascimento \u2014 ANTES das prote\u00e7\u00f5es
        // anti-ptrace do jogo subirem. Anexar num processo j\u00e1 rodando (modo
        // --pid antigo) travava em sil\u00eancio: o anti-cheat j\u00e1 estava de p\u00e9.
        LogManager.i(TAG, "Fechando o jogo para reiniciar limpo e injetar no boot do processo...")
        executarComando("am force-stop $PACOTE_JOGO")

        LogManager.i(TAG, "Executando injetor: --package $PACOTE_JOGO --libs $DIR_TMP/$NOME_LIB --memfd --launch")
        val r = executarComando(
            "timeout 120 $DIR_TMP/injetor --package $PACOTE_JOGO --libs $DIR_TMP/$NOME_LIB --memfd --launch 2>&1; echo \"INJ_EXIT:\$?\""
        )
        val codigoSaida = Regex("INJ_EXIT:(\\d+)").find(r)?.groupValues?.get(1)?.toIntOrNull() ?: -1
        val motivo = when (codigoSaida) {
            0 -> null
            2 -> "processo do jogo n\u00e3o encontrado pelo injetor"
            3 -> "falha no ptrace attach \u2014 anti-debug do jogo, SELinux ou Shizuku caiu"
            4 -> "arquitetura incompat\u00edvel (jogo 32-bit vs injetor/lib 64-bit)"
            5 -> "falha ao inicializar o injetor dentro do processo alvo"
            6 -> "libproxy.so inv\u00e1lida \u2014 n\u00e3o \u00e9 um ELF arm64 v\u00e1lido"
            7 -> "syscall remoto falhou dentro do processo do jogo"
            8 -> "dlopen falhou \u2014 a lib n\u00e3o carregou dentro do jogo (depend\u00eancia ou s\u00edmbolo ausente)"
            9 -> "falha ao desanexar do processo ap\u00f3s a inje\u00e7\u00e3o"
            124 -> "tempo esgotado (120s) \u2014 o injetor ficou monitorando, mas o jogo n\u00e3o abriu ou n\u00e3o foi detectado"
            127 -> "bin\u00e1rio do injetor n\u00e3o existia em $DIR_TMP na hora de executar"
            else -> "sa\u00edda inesperada do injetor (c\u00f3digo $codigoSaida)"
        }
        if (codigoSaida != 0) {
            return Resultado(false, "\u274c Falha na inje\u00e7\u00e3o (c\u00f3digo $codigoSaida): $motivo")
                .also { LogManager.e(TAG, "${it.mensagem}\n--- sa\u00edda do injetor ---\n$r") }
        }

        return Resultado(true, "\u2705 SUCESSO! Lib injetada no nascimento do processo (antes do anti-cheat subir)")
            .also { LogManager.ok(TAG, it.mensagem) }
    }

    // ---------------------------------------------------------------------
    // Vínculo do UserService (persistente, com cache e re-vínculo automático)
    // ---------------------------------------------------------------------

    /** Resultado interno do vínculo: binder do serviço ou mensagem de falha. */
    private sealed class ResultadoVinculo {
        data class Conectado(val binder: IBinder) : ResultadoVinculo()
        data class Falha(val mensagem: String) : ResultadoVinculo()
    }

    /**
     * Devolve o serviço pronto para uso. Reutiliza o binder em cache enquanto
     * ele estiver vivo; caso contrário, faz UM novo bind e aguarda o callback.
     *
     * Deve ser chamado apenas com [trava] adquirida e fora da main thread —
     * os pontos de chamada do app (HomeTab/ConfigManager) já rodam em IO.
     */
    private fun obterServico(): IShellService {
        val binderCache = binderAtual
        val servicoCache = servicoAtual
        if (servicoCache != null && binderCache != null && binderCache.pingBinder()) {
            return servicoCache
        }
        if (binderCache != null) {
            LogManager.w(TAG, "Binder em cache morreu — refazendo o vínculo")
        }
        return vincularServico()
    }

    /**
     * Faz o bind do UserService e bloqueia até a conexão (ou falha/timeout).
     * A fila de espera é local a ESTE vínculo: nenhuma outra chamada pode
     * consumir o resultado, porque a trava garante um bind por vez e o
     * binder resultante fica em cache para os comandos seguintes.
     */
    private fun vincularServico(): IShellService {
        check(contextoShizuku()) {
            "Shizuku indisponível ou sem permissão".also { LogManager.e(TAG, it) }
        }
        check(Shizuku.getVersion() >= 10) {
            "Requer Shizuku v10 ou superior".also { LogManager.e(TAG, it) }
        }

        LogManager.i(TAG, "🔗 Vinculando UserService (tag=gustaxy_shell, v$VERSAO_SERVICO)...")
        val esperaBinder = ArrayBlockingQueue<ResultadoVinculo>(1)

        val vigiaMorte = IBinder.DeathRecipient {
            // Binder morreu (Shizuku caiu/reiniciou): invalida o cache para
            // que o próximo comando faça um novo bind automaticamente.
            LogManager.w(TAG, "💀 Binder do ShellService morreu — cache invalidado")
            binderAtual = null
            servicoAtual = null
        }

        val conexaoServico = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder?) {
                if (binder != null && binder.pingBinder()) {
                    runCatching { binder.linkToDeath(vigiaMorte, 0) }
                    LogManager.ok(TAG, "✅ Conectado ao ShellService: ${name.className}")
                    esperaBinder.offer(ResultadoVinculo.Conectado(binder))
                } else {
                    LogManager.e(TAG, "onServiceConnected com binder inválido/nulo")
                    esperaBinder.offer(ResultadoVinculo.Falha("binder inválido"))
                }
            }

            override fun onServiceDisconnected(name: ComponentName) {
                LogManager.w(TAG, "⚠️ ShellService desconectado: ${name.className}")
                binderAtual = null
                servicoAtual = null
                esperaBinder.offer(ResultadoVinculo.Falha("serviço desconectado"))
            }
        }

        Shizuku.bindUserService(userServiceArgs, conexaoServico)

        val resultado = esperaBinder.poll(TIMEOUT_BIND_MS, TimeUnit.MILLISECONDS)
            ?: throw IllegalStateException(
                "timeout aguardando o serviço Shizuku".also { LogManager.e(TAG, "⏱️ $it") }
            )

        return when (resultado) {
            is ResultadoVinculo.Conectado -> {
                binderAtual = resultado.binder
                IShellService.Stub.asInterface(resultado.binder)
                    .also { servicoAtual = it }
            }
            is ResultadoVinculo.Falha ->
                throw IllegalStateException(
                    resultado.mensagem.also { LogManager.e(TAG, "Falha no vínculo: $it") }
                )
        }
    }

    /** Verifica binder vivo + permissão concedida, sem lançar exceção. */
    private fun contextoShizuku(): Boolean = runCatching {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)
}
