package com.gustaxy.android

import android.content.ClipboardManager
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gustaxy.android.network.ApiClient
import com.gustaxy.android.security.DeviceInfo
import com.gustaxy.android.security.NativeSecurity
import com.gustaxy.android.ui.theme.GustaxyAndroidTheme
import kotlinx.coroutines.launch
import kotlin.random.Random

/* ------------------------------------------------------------------ */
/*  PALETA                                                             */
/* ------------------------------------------------------------------ */

private object Ink {
    val Base = Color(0xFF000000)          // preto puro
    val Panel = Color(0xFF08090A)         // painel
    val PanelLine = Color(0xFF1C1E21)     // borda do painel
    val Field = Color(0xFF0C0D0F)         // fundo do campo
    val FieldLine = Color(0xFF23262A)     // borda do campo

    val Amber = Color(0xFFE3A317)         // amarelo/ouro das pinceladas
    val AmberDeep = Color(0xFFB57C0B)     // ouro escuro
    val Silver = Color(0xFFDDDFE2)        // prata clara
    val SilverDim = Color(0xFF8A8E94)     // prata fosca

    val TextHigh = Color(0xFFF2F3F4)
    val TextLow = Color(0xFF6E7278)
    val Danger = Color(0xFFD9483F)
}

/* ------------------------------------------------------------------ */
/*  ACTIVITY                                                           */
/* ------------------------------------------------------------------ */

class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GustaxyAndroidTheme {
                LoginScreen(
                    onSuccess = {
                        startActivity(android.content.Intent(this, DashboardActivity::class.java))
                        finish()
                    },
                    onInvalidIntegrity = { finishAndRemoveTask() }
                )
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  FUNDO: PINCELADAS DIAGONAIS + LINHAS GEOMÉTRICAS                   */
/* ------------------------------------------------------------------ */

/**
 * Desenha uma pincelada "seca": várias lâminas finas paralelas, com
 * comprimentos e opacidades irregulares, formando as pontas rasgadas.
 * Tudo com cor chapada — nenhum blur, sombra ou brilho.
 */
private fun DrawScope.brushStroke(
    center: Offset,
    angle: Float,
    length: Float,
    width: Float,
    color: Color,
    seed: Int,
    slivers: Int = 14,
    maxAlpha: Float = 1f
) {
    val rnd = Random(seed)
    rotate(degrees = angle, pivot = center) {
        val left = center.x - width / 2f
        val top = center.y - length / 2f
        val step = width / slivers
        repeat(slivers) { i ->
            val x = left + i * step + rnd.nextFloat() * step * 0.5f
            val thick = step * (0.30f + rnd.nextFloat() * 1.15f)
            val headCut = rnd.nextFloat() * length * 0.32f
            val tailCut = rnd.nextFloat() * length * 0.26f
            val body = length - headCut - tailCut
            if (body <= 0f) return@repeat

            val alpha = (0.16f + rnd.nextFloat() * 0.84f) * maxAlpha
            drawRect(
                color = color.copy(alpha = alpha),
                topLeft = Offset(x, top + headCut),
                size = Size(thick, body)
            )

            // respingos soltos nas pontas (textura de pincel)
            if (rnd.nextFloat() > 0.52f) {
                val fleck = length * (0.03f + rnd.nextFloat() * 0.09f)
                val gap = length * (0.03f + rnd.nextFloat() * 0.10f)
                drawRect(
                    color = color.copy(alpha = alpha * 0.65f),
                    topLeft = Offset(x, top + headCut - gap - fleck),
                    size = Size(thick, fleck)
                )
            }
            if (rnd.nextFloat() > 0.62f) {
                val fleck = length * (0.02f + rnd.nextFloat() * 0.07f)
                val gap = length * (0.02f + rnd.nextFloat() * 0.09f)
                drawRect(
                    color = color.copy(alpha = alpha * 0.55f),
                    topLeft = Offset(x, top + length - tailCut + gap),
                    size = Size(thick, fleck)
                )
            }
        }
    }
}

/** Linha fina quebrada em ângulo (detalhe geométrico âmbar). */
private fun DrawScope.angledLine(
    p1: Offset,
    p2: Offset,
    p3: Offset,
    color: Color,
    strokeWidth: Float
) {
    val path = Path().apply {
        moveTo(p1.x, p1.y)
        lineTo(p2.x, p2.y)
        lineTo(p3.x, p3.y)
    }
    drawPath(path, color, style = Stroke(width = strokeWidth))
}

@Composable
private fun Backdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val hair = 1.dp.toPx()
        val tilt = 34f // inclinação das pinceladas

        drawRect(Ink.Base)

        clipRect {
            /* ---------- CANTO SUPERIOR ESQUERDO ---------- */
            brushStroke(Offset(w * -0.02f, h * 0.045f), tilt, h * 0.20f, w * 0.11f, Ink.Silver, 11, 15, 0.95f)
            brushStroke(Offset(w * 0.09f, h * 0.030f), tilt, h * 0.17f, w * 0.09f, Ink.SilverDim, 12, 13, 0.70f)
            brushStroke(Offset(w * 0.14f, h * 0.055f), tilt, h * 0.19f, w * 0.10f, Ink.Amber, 13, 14, 1.00f)
            brushStroke(Offset(w * 0.20f, h * 0.040f), tilt, h * 0.14f, w * 0.06f, Ink.AmberDeep, 14, 10, 0.85f)
            brushStroke(Offset(w * 0.26f, h * 0.020f), tilt, h * 0.15f, w * 0.08f, Ink.Silver, 15, 12, 0.80f)
            brushStroke(Offset(w * 0.05f, h * 0.150f), tilt, h * 0.10f, w * 0.05f, Ink.SilverDim, 16, 9, 0.45f)
            brushStroke(Offset(w * 0.01f, h * 0.190f), tilt, h * 0.07f, w * 0.04f, Ink.AmberDeep, 17, 8, 0.40f)

            /* ---------- CANTO INFERIOR DIREITO ---------- */
            brushStroke(Offset(w * 1.02f, h * 0.760f), tilt, h * 0.19f, w * 0.10f, Ink.Silver, 21, 15, 0.95f)
            brushStroke(Offset(w * 0.93f, h * 0.815f), tilt, h * 0.21f, w * 0.11f, Ink.Silver, 22, 15, 0.85f)
            brushStroke(Offset(w * 0.86f, h * 0.870f), tilt, h * 0.16f, w * 0.07f, Ink.SilverDim, 23, 12, 0.65f)
            brushStroke(Offset(w * 0.97f, h * 0.930f), tilt, h * 0.17f, w * 0.09f, Ink.Amber, 24, 14, 1.00f)
            brushStroke(Offset(w * 0.78f, h * 0.955f), tilt, h * 0.15f, w * 0.08f, Ink.Amber, 25, 13, 0.90f)
            brushStroke(Offset(w * 0.68f, h * 0.985f), tilt, h * 0.12f, w * 0.06f, Ink.AmberDeep, 26, 10, 0.70f)
            brushStroke(Offset(w * 0.60f, h * 0.965f), tilt, h * 0.09f, w * 0.05f, Ink.SilverDim, 27, 9, 0.45f)
            brushStroke(Offset(w * 0.45f, h * 1.005f), tilt, h * 0.08f, w * 0.05f, Ink.Silver, 28, 9, 0.40f)

            /* ---------- LINHAS GEOMÉTRICAS FINAS ---------- */
            angledLine(
                Offset(w * 0.40f, -h * 0.01f),
                Offset(w * 0.46f, h * 0.055f),
                Offset(w * 0.30f, h * 0.055f),
                Ink.AmberDeep.copy(alpha = 0.75f), hair
            )
            angledLine(
                Offset(w * 1.02f, h * 0.575f),
                Offset(w * 0.79f, h * 0.575f),
                Offset(w * 0.68f, h * 0.660f),
                Ink.AmberDeep.copy(alpha = 0.70f), hair
            )
            angledLine(
                Offset(w * -0.02f, h * 0.855f),
                Offset(w * 0.26f, h * 0.855f),
                Offset(w * 0.40f, h * 0.760f),
                Ink.AmberDeep.copy(alpha = 0.70f), hair
            )
            angledLine(
                Offset(w * 0.08f, h * 0.905f),
                Offset(w * 0.18f, h * 0.905f),
                Offset(w * 0.24f, h * 0.860f),
                Ink.AmberDeep.copy(alpha = 0.40f), hair
            )
        }
    }
}

/* ------------------------------------------------------------------ */
/*  TELA                                                               */
/* ------------------------------------------------------------------ */

@Composable
private fun LoginScreen(onSuccess: () -> Unit, onInvalidIntegrity: () -> Unit) {
    val context = LocalContext.current
    val client = remember(context) { ApiClient(context) }
    var key by rememberSaveable { mutableStateOf(client.savedKey().orEmpty()) }
    var loading by rememberSaveable { mutableStateOf(false) }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var maintenance by remember { mutableStateOf<ApiClient.MaintenanceInfo?>(null) }
    var maintenanceImage by remember { mutableStateOf<Bitmap?>(null) }
    val clipboard = remember(context) { context.getSystemService(ClipboardManager::class.java) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        client.config().onSuccess { remote ->
            if (remote.maintenance.enabled) {
                maintenance = remote.maintenance
                if (remote.maintenance.imageUrl.isNotBlank()) {
                    client.maintenanceImage(remote.maintenance.imageUrl)
                        .onSuccess { maintenanceImage = it }
                }
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Ink.Base) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val compact = maxWidth < 360.dp
            val sidePadding = if (compact) 22.dp else 30.dp
            val logoSize = (maxWidth * 0.34f).coerceIn(96.dp, 138.dp)
            val gap = if (maxHeight < 650.dp) 26.dp else 40.dp

            Backdrop(modifier = Modifier.fillMaxSize())

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .imePadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = sidePadding, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {

                Image(
                    painter = painterResource(R.drawable.gustaxy_mark),
                    contentDescription = null,
                    modifier = Modifier.size(logoSize)
                )

                Spacer(Modifier.height(14.dp))

                // marcador âmbar: barra curta chapada
                Box(
                    modifier = Modifier
                        .width(46.dp)
                        .height(2.dp)
                        .background(Ink.Amber)
                )

                Spacer(Modifier.height(gap))

                /* ---------------- PAINEL ---------------- */
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Ink.Panel, RoundedCornerShape(20.dp))
                        .border(1.dp, Ink.PanelLine, RoundedCornerShape(20.dp))
                        .padding(horizontal = 18.dp, vertical = 20.dp)
                ) {
                    OutlinedTextField(
                        value = key,
                        onValueChange = { key = it; message = null },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("key", fontSize = 14.sp) },
                        leadingIcon = {
                            Icon(Icons.Outlined.Key, contentDescription = null, modifier = Modifier.size(20.dp))
                        },
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = {
                                    val clip = clipboard?.primaryClip
                                    val pasted = if (clip != null && clip.itemCount > 0)
                                        clip.getItemAt(0).coerceToText(context).toString().trim() else ""
                                    if (pasted.isNotEmpty()) {
                                        key = pasted
                                        message = null
                                    } else {
                                        message = "Copie uma key antes de colar."
                                    }
                                }) {
                                    Icon(
                                        Icons.Outlined.ContentPaste,
                                        contentDescription = "Colar key",
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { key = ""; message = null },
                                    enabled = key.isNotEmpty()
                                ) {
                                    Icon(
                                        Icons.Outlined.DeleteOutline,
                                        contentDescription = "Limpar key",
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        },
                        isError = message != null,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Ink.Field,
                            unfocusedContainerColor = Ink.Field,
                            errorContainerColor = Ink.Field,
                            focusedBorderColor = Ink.Amber,
                            unfocusedBorderColor = Ink.FieldLine,
                            errorBorderColor = Ink.Danger,
                            cursorColor = Ink.Amber,
                            errorCursorColor = Ink.Danger,
                            focusedTextColor = Ink.TextHigh,
                            unfocusedTextColor = Ink.TextHigh,
                            errorTextColor = Ink.TextHigh,
                            focusedPlaceholderColor = Ink.TextLow,
                            unfocusedPlaceholderColor = Ink.TextLow,
                            focusedLeadingIconColor = Ink.Amber,
                            unfocusedLeadingIconColor = Ink.TextLow,
                            errorLeadingIconColor = Ink.Danger,
                            focusedTrailingIconColor = Ink.SilverDim,
                            unfocusedTrailingIconColor = Ink.TextLow,
                            disabledTrailingIconColor = Color(0xFF3A3D42)
                        )
                    )

                    message?.let {
                        Text(
                            it,
                            color = Ink.Danger,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp, start = 4.dp)
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // ação secundária (grupo) — ícone, sem texto
                        OutlinedButton(
                            onClick = { message = "Link do grupo ainda não configurado." },
                            modifier = Modifier
                                .size(54.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, Ink.FieldLine),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Ink.Field,
                                contentColor = Ink.SilverDim
                            )
                        ) {
                            Icon(
                                Icons.Outlined.ChatBubbleOutline,
                                contentDescription = "Grupo",
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // ação principal — âmbar chapado
                        Button(
                            onClick = {
                                if (key.trim().isEmpty() || loading) {
                                    message = "Informe uma key."
                                    return@Button
                                }
                                scope.launch {
                                    loading = true
                                    message = null
                                    val deviceId = DeviceInfo.deviceId(context)
                                    val report = NativeSecurity.inspect(context, deviceId)
                                    if (!BuildConfig.DEBUG && !report.acceptable) {
                                        loading = false
                                        onInvalidIntegrity()
                                        return@launch
                                    }
                                    val result = client.login(
                                        key = key.trim(),
                                        deviceId = deviceId,
                                        deviceName = DeviceInfo.deviceName(),
                                        appVersion = BuildConfig.VERSION_NAME,
                                        androidVersion = DeviceInfo.androidVersion(),
                                        integrity = mapOf(
                                            "apk_sha256" to report.apkSha256,
                                            "cert_sha256" to report.certificateSha256,
                                            "native_signal" to report.nativeSignal,
                                            "nonce" to report.nonce
                                        )
                                    )
                                    loading = false
                                    result
                                        .onSuccess { onSuccess() }
                                        .onFailure { message = it.message ?: "Não foi possível entrar." }
                                }
                            },
                            enabled = !loading,
                            modifier = Modifier
                                .weight(1f)
                                .height(54.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Ink.Amber,
                                contentColor = Ink.Base,
                                disabledContainerColor = Color(0xFF3B2E12),
                                disabledContentColor = Color(0xFF7A6A46)
                            ),
                            elevation = ButtonDefaults.buttonElevation(0.dp, 0.dp, 0.dp, 0.dp, 0.dp)
                        ) {
                            if (loading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Ink.Base,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    Icons.Outlined.ArrowForward,
                                    contentDescription = "Entrar",
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))

                // traço prata discreto de fechamento
                Box(
                    modifier = Modifier
                        .width(26.dp)
                        .height(1.dp)
                        .background(Ink.SilverDim.copy(alpha = 0.45f))
                )
            }
        }
    }

    maintenance?.let { info ->
        AlertDialog(
            onDismissRequest = { maintenance = null },
            containerColor = Ink.Panel,
            titleContentColor = Ink.TextHigh,
            textContentColor = Ink.TextLow,
            shape = RoundedCornerShape(20.dp),
            tonalElevation = 0.dp,
            title = { Text(info.title, fontSize = 17.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    maintenanceImage?.let { bitmap ->
                        Image(
                            bitmap.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                                .background(Ink.Field, RoundedCornerShape(12.dp))
                        )
                    }
                    Text(info.description, fontSize = 13.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { maintenance = null }) {
                    Text("OK", color = Ink.Amber, fontSize = 14.sp)
                }
            }
        )
    }
}
