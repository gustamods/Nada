package com.gustaxy.android

import android.content.Context
import com.gustaxy.android.security.Injector
import java.io.File

/**
 * MÉTODO DO PATCH POR ARQUIVOS (o que seu amigo mostrou).
 *
 * Em vez de injetar a libproxy.so na memória, este módulo planta os arquivos
 * do hotupdate DENTRO da pasta do próprio jogo:
 *
 *   /storage/emulated/0/Android/data/com.dts.freefiremax/files/
 *     ├── localConfig.json   <- {"hotUpdateUsePersistentDataPath":true,...} + toggles do mod
 *     ├── modes.dat / ff_sess.dat / ff_cache.dat
 *     └── contentcache/Compulsory/android/gameassetbundles/codepatch/assembly-csharp-patch.*
 *
 * O jogo (Unity + IFix) carrega esse bundle SOZINHO na inicialização, como se
 * fosse uma atualização oficial — sem ptrace, sem injetor binário. O Shizuku
 * entra apenas para copiar os arquivos para a pasta Android/data do jogo.
 *
 * O bundle do patch vem embutido nos assets do APK (pasta assets/ffmax_patch/).
 */
object PatchDeployer {

    private const val TAG = "PATCH"
    private const val ASSET_DIR = "ffmax_patch"

    /** Pasta files/ do Free Fire MAX (destino final dos arquivos). */
    private val PASTA_JOGO =
        "/storage/emulated/0/Android/data/${Injector.PACOTE_JOGO}/files"

    data class Opcoes(
        val esp: Boolean,
        val aimbot: Boolean,
        val corEsp: String = "amarelo",        // cor pedida para a ESP box
        val nomeEsp: String = "GUSTAXY SAFE",  // nome fixo sobre a barra de vida
        val animacaoCor: Boolean = true,       // ciclo de cores ligado
        val velocidadeAnimacao: String = "lento"
    )

    /**
     * localConfig.json = interruptor do hotupdate (campos originais do jogo)
     * + os toggles do mod que o patch lê via ReadAllText(persistentDataPath
     * + "/localConfig.json"). Os campos __esp/__aimbot/esp_box_color/esp_name
     * são preferências do loader, não prova de que o binário as lê.
     * Neste build, cor e nome estão montados nas instruções do patch.
     */
    private fun montarLocalConfig(o: Opcoes): String = """
        {
            "hotUpdateUsePersistentDataPath": true,
            "skipResourceDownload": true,
            "__esp": ${o.esp},
            "__aimbot": false,
            "esp_box_color": "${o.corEsp}",
            "esp_name": "${o.nomeEsp}",
            "esp_color_anim": ${o.animacaoCor},
            "esp_color_speed": "${o.velocidadeAnimacao}",
            "floating_menu": true
        }
    """.trimIndent()

    /** Copia recursivamente a árvore assets/ffmax_patch para o staging externo. */
    private fun extrairArvore(context: Context, rel: String, destinoRaiz: File) {
        val caminhoAsset = if (rel.isEmpty()) ASSET_DIR else "$ASSET_DIR/$rel"
        val filhos = context.assets.list(caminhoAsset) ?: emptyArray()
        if (filhos.isEmpty()) {
            // É um arquivo: copia preservando o caminho relativo
            val out = File(destinoRaiz, rel)
            out.parentFile?.mkdirs()
            context.assets.open(caminhoAsset).use { entrada ->
                out.outputStream().use { saida -> entrada.copyTo(saida) }
            }
        } else {
            for (f in filhos) {
                extrairArvore(context, if (rel.isEmpty()) f else "$rel/$f", destinoRaiz)
            }
        }
    }

    /**
     * Planta todos os arquivos do patch na pasta do jogo via Shizuku.
     * Bloqueante — chame sempre fora da main thread (a HomeTab já faz isso).
     */
    fun implantarPatch(context: Context, opcoes: Opcoes): Injector.Resultado {
        LogManager.i(TAG, "🎯 Aplicando patch por arquivos: esp=${opcoes.esp}, aimbot=${opcoes.aimbot}, cor=${opcoes.corEsp}, nome=${opcoes.nomeEsp}")

        // 1) Staging na pasta externa do loader (o shell do Shizuku lê daqui)
        val staging = File(context.getExternalFilesDir(null), "ffmax_patch_staging")
        staging.deleteRecursively()
        staging.mkdirs()

        val temPatch = runCatching {
            extrairArvore(context, "", staging)
            File(staging, "localConfig.json").exists() ||
                File(staging, "contentcache").exists()
        }.getOrDefault(false)

        if (!temPatch) {
            return Injector.Resultado(
                false,
                "❌ Arquivos do patch não encontrados nos assets (assets/$ASSET_DIR)"
            ).also { LogManager.e(TAG, it.mensagem) }
        }

        // 2) Sobrescreve o localConfig.json com as opções dos switches
        File(staging, "localConfig.json").writeText(montarLocalConfig(opcoes))
        // Bit 4 controls visuals in this template. Aim bits 1 and 2 stay off.
        File(staging, "modes.dat").writeBytes(byteArrayOf(if (opcoes.esp) 4.toByte() else 0.toByte()))
        LogManager.i(TAG, "localConfig.json gerado com os toggles do mod")

        // 3) Copia tudo para a pasta files/ do jogo via shell do Shizuku
        val r = Injector.executarComando(
            "mkdir -p '$PASTA_JOGO' && cp -r '${staging.absolutePath}/.' '$PASTA_JOGO/' " +
                "&& ls '$PASTA_JOGO'"
        )
        val ok = !r.startsWith("ERRO") &&
            !r.contains("Permission denied", true) &&
            r.contains("localConfig.json")

        return if (ok) {
            Injector.Resultado(true, "✅ Arquivos aplicados na pasta do jogo!")
                .also { LogManager.ok(TAG, it.mensagem) }
        } else {
            Injector.Resultado(false, "❌ Falha ao copiar arquivos: $r")
                .also { LogManager.e(TAG, it.mensagem) }
        }
    }
}
