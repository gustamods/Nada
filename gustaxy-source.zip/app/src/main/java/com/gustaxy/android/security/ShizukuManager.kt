package com.gustaxy.android.security

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Somente a preparação/solicitação de permissão; nenhum comando Shizuku é executado aqui. */
object ShizukuManager {
    const val REQUEST_CODE = 701

    fun isAvailable(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    fun hasPermission(): Boolean = runCatching {
        isAvailable() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    fun requestPermission() {
        runCatching {
            if (isAvailable() && !hasPermission()) {
                Shizuku.requestPermission(REQUEST_CODE)
            }
        }
    }
}
