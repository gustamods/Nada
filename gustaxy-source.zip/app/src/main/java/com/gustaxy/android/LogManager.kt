package com.gustaxy.android

import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Log global do app, visível na aba "Terminal" em tempo real.
 *
 * Tudo que importa passa por aqui: comandos shell do Shizuku, etapas da
 * injeção, salvamento de config, permissões, erros e crashes. Cada entrada
 * também é espelhada no logcat (tag "Gustaxy/<tag>").
 *
 * Thread-safe: pode ser chamado de qualquer thread (UI, injeção, callbacks
 * do Shizuku). A lista é observável pelo Compose — a aba Terminal atualiza
 * sozinha a cada nova linha.
 */
object LogManager {

    enum class Nivel { INFO, COMANDO, SUCESSO, AVISO, ERRO }

    data class Entrada(
        val hora: String,
        val nivel: Nivel,
        val tag: String,
        val mensagem: String
    )

    /** Lista observável pelo Compose. */
    val logs = mutableStateListOf<Entrada>()

    private const val MAX_LINHAS = 500
    private val formatoHora = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun log(nivel: Nivel, tag: String, mensagem: String) {
        val entrada = Entrada(formatoHora.format(Date()), nivel, tag, mensagem)
        logs.add(entrada)
        while (logs.size > MAX_LINHAS) logs.removeAt(0)

        // Espelha no logcat para depuração via ADB também
        val tagLogcat = "Gustaxy/$tag"
        when (nivel) {
            Nivel.INFO -> Log.i(tagLogcat, mensagem)
            Nivel.COMANDO -> Log.d(tagLogcat, mensagem)
            Nivel.SUCESSO -> Log.i(tagLogcat, mensagem)
            Nivel.AVISO -> Log.w(tagLogcat, mensagem)
            Nivel.ERRO -> Log.e(tagLogcat, mensagem)
        }
    }

    fun i(tag: String, mensagem: String) = log(Nivel.INFO, tag, mensagem)

    /** Comando shell enviado ao Shizuku. */
    fun c(tag: String, mensagem: String) = log(Nivel.COMANDO, tag, mensagem)

    fun ok(tag: String, mensagem: String) = log(Nivel.SUCESSO, tag, mensagem)
    fun w(tag: String, mensagem: String) = log(Nivel.AVISO, tag, mensagem)
    fun e(tag: String, mensagem: String) = log(Nivel.ERRO, tag, mensagem)

    @Synchronized
    fun limpar() = logs.clear()

    /** Exporta tudo como texto (para o botão "Copiar" da aba Terminal). */
    @Synchronized
    fun exportarTexto(): String =
        logs.joinToString("\n") { "[${it.hora}] ${it.nivel}/${it.tag}: ${it.mensagem}" }
}
