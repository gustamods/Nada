package com.gustaxy.android.security

import android.content.Context
import android.util.Log
import androidx.annotation.Keep
import kotlin.system.exitProcess

/**
 * UserService do Shizuku: processo separado com privilégio de shell/root.
 * Substitui o antigo Shizuku.newProcess(), que virou privado na API 13.1.x.
 */
class ShellService : IShellService.Stub {

    /** Construtor padrão: obrigatório (Shizuku < v13 usa este). */
    constructor() {
        Log.i(TAG, "constructor")
    }

    /**
     * Construtor com Context (Shizuku v13+ tenta este primeiro).
     * O [Keep] impede que o R8/ProGuard o remova no build release.
     */
    @Keep
    constructor(context: Context) {
        Log.i(TAG, "constructor with Context: $context")
    }

    /** Método reservado: chamado pelo Shizuku para encerrar o processo. */
    override fun destroy() {
        Log.i(TAG, "destroy")
        exitProcess(0)
    }

    /** Executa [comando] via `sh -c` e devolve stdout+stderr concatenados. */
    override fun executar(comando: String): String {
        return runCatching {
            val processo = Runtime.getRuntime().exec(arrayOf("sh", "-c", comando))
            val saida = processo.inputStream.readBytes().toString(Charsets.UTF_8)
            val erro = processo.errorStream.readBytes().toString(Charsets.UTF_8)
            processo.waitFor()
            (saida + "\n" + erro).trim()
        }.getOrElse { e -> "ERRO: ${e.message}" }
    }

    private companion object {
        const val TAG = "ShellService"
    }
}
