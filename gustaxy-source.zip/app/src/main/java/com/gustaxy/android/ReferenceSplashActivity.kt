package com.gustaxy.android

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.gustaxy.android.ui.theme.GustaxyAndroidTheme
import kotlinx.coroutines.delay

/**
 * Entrada independente inspirada na inicialização do APK de referência.
 * Não substitui a InicialActivity: ela abre primeiro a biblioteca Lark e
 * deixa o fluxo original do Gustaxy para depois do comando de pesquisa.
 */
class ReferenceSplashActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        window.statusBarColor = AndroidColor.BLACK
        window.navigationBarColor = AndroidColor.BLACK
        setContent {
            GustaxyAndroidTheme {
                ReferenceSplashScreen {
                    startActivity(
                        Intent(this, LarkPlayerActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        }
                    )
                    finish()
                }
            }
        }
    }
}

@Composable
private fun ReferenceSplashScreen(onFinished: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    val logoAlpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(380, easing = FastOutSlowInEasing),
        label = "reference-logo-alpha"
    )
    val logoScale by animateFloatAsState(
        targetValue = if (visible) 1f else 0.92f,
        animationSpec = tween(480, easing = FastOutSlowInEasing),
        label = "reference-logo-scale"
    )

    LaunchedEffect(Unit) {
        visible = true
        delay(900L)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A)),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.lark_reference_splash_logo),
            contentDescription = "Lark Player",
            modifier = Modifier
                .size(288.dp)
                .graphicsLayer(alpha = logoAlpha, scaleX = logoScale, scaleY = logoScale)
        )
    }
}
