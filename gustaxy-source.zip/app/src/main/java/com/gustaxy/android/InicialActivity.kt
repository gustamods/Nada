package com.gustaxy.android

import android.content.Intent
import android.os.Bundle
import android.content.pm.ActivityInfo
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gustaxy.android.network.ApiClient
import com.gustaxy.android.security.DeviceInfo
import com.gustaxy.android.security.NativeSecurity
import com.gustaxy.android.ui.theme.GustaxyAndroidTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.sin

class InicialActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // O fluxo normal do projeto permanece vertical.
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        setContent {
            GustaxyAndroidTheme {
                InitialScreen { report, hasSession ->

                    if (BuildConfig.DEBUG || report.acceptable) {

                        val destination =
                            if (hasSession) {
                                DashboardActivity::class.java
                            } else {
                                LoginActivity::class.java
                            }

                        startActivity(
                            Intent(this, destination)
                        )

                        finish()

                    } else {
                        finishAndRemoveTask()
                    }
                }
            }
        }
    }
}

@Composable
private fun InitialScreen(
    onFinished: (NativeSecurity.Report, Boolean) -> Unit
) {

    val progress = remember {
        Animatable(0f)
    }

    val context = androidx.compose.ui.platform.LocalContext.current

    var showContent by remember {
        mutableStateOf(false)
    }

    /*
     * Animação bem leve no logo.
     * Não é glow: é apenas uma pequena variação
     * de escala para não deixar a splash parada.
     */
    val infiniteTransition =
        rememberInfiniteTransition(
            label = "gustaxy-motion"
        )

    val logoScale by infiniteTransition.animateFloat(
        initialValue = 0.985f,
        targetValue = 1.015f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1500
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logo-scale"
    )

    /*
     * Pequena movimentação das linhas geométricas.
     */
    val lineOffset by infiniteTransition.animateFloat(
        initialValue = -0.08f,
        targetValue = 0.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 2200
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "line-motion"
    )

    LaunchedEffect(Unit) {

        showContent = true

        val report =
            withContext(Dispatchers.Default) {
                NativeSecurity.inspect(
                    context,
                    DeviceInfo.deviceId(context)
                )
            }

        progress.animateTo(
            targetValue = 0.25f,
            animationSpec = tween(250)
        )

        progress.animateTo(
            targetValue = 0.55f,
            animationSpec = tween(320)
        )

        val hasSession =
            if (BuildConfig.DEBUG || report.acceptable) {

                withContext(Dispatchers.IO) {
                    ApiClient(context)
                        .current()
                        .isSuccess
                }

            } else {
                false
            }

        progress.animateTo(
            targetValue = 0.82f,
            animationSpec = tween(280)
        )

        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(300)
        )

        onFinished(
            report,
            hasSession
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {

        /*
         * =========================================================
         * FUNDO
         * =========================================================
         */
        Image(
            painter = painterResource(
                id = R.drawable.background_gustaxy
            ),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        /*
         * Máscara escura para o logo e textos continuarem legíveis.
         * Mantive praticamente preto, igual à arte.
         */
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xF5000000),
                            Color(0x6D000000),
                            Color(0x19000000),
                            Color(0x65000000),
                            Color(0xEA000000)
                        )
                    )
                )
        )

        /*
         * Outra camada discreta na parte inferior.
         */
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Transparent,
                            Color(0xA6000000)
                        )
                    )
                )
        )

        /*
         * =========================================================
         * DETALHES GEOMÉTRICOS ANIMADOS
         * =========================================================
         */
        AnimatedAccentLines(
            modifier = Modifier.fillMaxSize(),
            offset = lineOffset
        )

        /*
         * =========================================================
         * CONTEÚDO PRINCIPAL
         * =========================================================
         */
        AnimatedVisibility(
            visible = showContent,
            enter = fadeIn(
                animationSpec = tween(550)
            ) + scaleIn(
                initialScale = 0.96f,
                animationSpec = tween(550)
            ),
            exit = fadeOut()
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 28.dp, vertical = 28.dp)
            ) {
                val compact = maxWidth < 640.dp
                if (compact) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Image(
                            painter = painterResource(R.drawable.gustaxy_mark),
                            contentDescription = "Gustaxy Proxy",
                            modifier = Modifier
                                .fillMaxWidth(0.78f)
                                .scale(logoScale)
                                .alpha(0.98f),
                            contentScale = ContentScale.Fit
                        )
                        Spacer(Modifier.height(18.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.32f)
                                .height(3.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color(0xFFFFC107),
                                            Color(0xFFFFA000),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                        Spacer(Modifier.height(14.dp))
                        Text(
                            text = "GUSTAXY PROXY",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 4.sp
                        )
                        Spacer(Modifier.height(30.dp))
                        Column(
                            modifier = Modifier.fillMaxWidth(0.80f),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = "${(progress.value * 100).toInt()}%",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )
                            Spacer(Modifier.height(10.dp))
                            HorizontalLoadingBar(
                                progress = progress.value,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                text = when {
                                    progress.value < 0.25f -> "VERIFICANDO DISPOSITIVO"
                                    progress.value < 0.55f -> "VALIDANDO AMBIENTE"
                                    progress.value < 0.82f -> "SINCRONIZANDO SESSÃO"
                                    else -> "CARREGAMENTO CONCLUÍDO"
                                },
                                color = Color.White.copy(alpha = 0.55f),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Medium,
                                letterSpacing = 1.7.sp
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1.25f),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.Start
                        ) {
                            Image(
                                painter = painterResource(R.drawable.gustaxy_mark),
                                contentDescription = "Gustaxy Proxy",
                                modifier = Modifier
                                    .fillMaxWidth(0.75f)
                                    .scale(logoScale)
                                    .alpha(0.98f),
                                contentScale = ContentScale.Fit
                            )
                            Spacer(Modifier.height(18.dp))
                            Box(
                                modifier = Modifier
                                    .width(125.dp)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(
                                                Color(0xFFFFC107),
                                                Color(0xFFFFA000),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )
                            Spacer(Modifier.height(14.dp))
                            Text(
                                text = "GUSTAXY PROXY",
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 4.sp
                            )
                        }
                        Spacer(Modifier.width(48.dp))
                        Column(
                            modifier = Modifier.weight(0.8f),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = "${(progress.value * 100).toInt()}%",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )
                            Spacer(Modifier.height(10.dp))
                            HorizontalLoadingBar(
                                progress = progress.value,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                text = when {
                                    progress.value < 0.25f -> "VERIFICANDO DISPOSITIVO"
                                    progress.value < 0.55f -> "VALIDANDO AMBIENTE"
                                    progress.value < 0.82f -> "SINCRONIZANDO SESSÃO"
                                    else -> "CARREGAMENTO CONCLUÍDO"
                                },
                                color = Color.White.copy(alpha = 0.55f),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Medium,
                                letterSpacing = 1.7.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

/*
 * =============================================================
 * BARRA DE CARREGAMENTO
 * =============================================================
 */
@Composable
private fun HorizontalLoadingBar(
    progress: Float,
    modifier: Modifier = Modifier
) {

    Box(
        modifier = modifier
            .height(5.dp)
            .clip(
                RoundedCornerShape(
                    50.dp
                )
            )
            .background(
                Color.White.copy(
                    alpha = 0.13f
                )
            )
    ) {

        Box(
            modifier = Modifier
                .fillMaxWidth(
                    progress.coerceIn(
                        0f,
                        1f
                    )
                )
                .fillMaxHeight()
                .clip(
                    RoundedCornerShape(
                        50.dp
                    )
                )
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFFFFFFFF),
                            Color(0xFFFFD54F),
                            Color(0xFFFFB300)
                        )
                    )
                )
        )
    }
}

/*
 * =============================================================
 * LINHAS GEOMÉTRICAS
 * =============================================================
 *
 * Elas são simples, sem glow.
 * Servem apenas para dar aquela sensação de arte feita
 * manualmente no estilo da imagem.
 */
@Composable
private fun AnimatedAccentLines(
    modifier: Modifier = Modifier,
    offset: Float
) {

    Canvas(
        modifier = modifier
            .alpha(0.42f)
    ) {

        val width = size.width
        val height = size.height

        val gold = Color(
            0xFFFFB900
        )

        val white = Color(
            0xFFE5E5E5
        )

        /*
         * Linha superior esquerda
         */
        drawLine(
            color = gold,
            start = Offset(
                x = width * (0.03f + offset),
                y = height * 0.13f
            ),
            end = Offset(
                x = width * 0.23f,
                y = height * 0.04f
            ),
            strokeWidth = 2.2f
        )

        /*
         * Segunda linha superior
         */
        drawLine(
            color = white.copy(alpha = 0.45f),
            start = Offset(
                x = width * 0.00f,
                y = height * 0.23f
            ),
            end = Offset(
                x = width * 0.16f,
                y = height * 0.10f
            ),
            strokeWidth = 1.4f
        )

        /*
         * Detalhe geométrico superior direito.
         */
        drawLine(
            color = gold,
            start = Offset(
                x = width * 0.77f,
                y = height * 0.07f
            ),
            end = Offset(
                x = width * 0.93f,
                y = height * 0.17f
            ),
            strokeWidth = 1.8f
        )

        /*
         * Linha inferior esquerda.
         */
        drawLine(
            color = gold,
            start = Offset(
                x = width * 0.04f,
                y = height * 0.91f
            ),
            end = Offset(
                x = width * 0.19f,
                y = height * 0.78f
            ),
            strokeWidth = 2f
        )

        /*
         * Detalhe inferior direito.
         */
        drawLine(
            color = white.copy(alpha = 0.45f),
            start = Offset(
                x = width * 0.80f,
                y = height * 0.96f
            ),
            end = Offset(
                x = width * 0.99f,
                y = height * 0.78f
            ),
            strokeWidth = 1.5f
        )

        /*
         * Pequenas barras diagonais.
         */
        drawLine(
            color = gold,
            start = Offset(
                x = width * 0.38f,
                y = height * 0.08f
            ),
            end = Offset(
                x = width * 0.43f,
                y = height * 0.04f
            ),
            strokeWidth = 1.2f
        )

        drawLine(
            color = gold,
            start = Offset(
                x = width * 0.58f,
                y = height * 0.94f
            ),
            end = Offset(
                x = width * 0.63f,
                y = height * 0.90f
            ),
            strokeWidth = 1.2f
        )
    }
}