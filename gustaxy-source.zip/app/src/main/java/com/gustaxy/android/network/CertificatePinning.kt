package com.gustaxy.android.network

import com.gustaxy.android.BuildConfig
import okhttp3.CertificatePinner

/**
 * TLS pinning is supplied at build time so certificate rotations do not force
 * hardcoded pins into source control. Format:
 * host=sha256/BASE64PIN|sha256/ANOTHER_PIN,other-host=sha256/BASE64PIN
 *
 * When no pin is configured the normal Android trust chain remains active;
 * this keeps local/debug builds and existing CI configurations buildable.
 */
object CertificatePinning {
    fun createOrNull(): CertificatePinner? {
        val raw = BuildConfig.TLS_PINS.trim()
        if (raw.isBlank()) return null

        val builder = CertificatePinner.Builder()
        var added = false
        raw.split(',').forEach { entry ->
            val parts = entry.trim().split('=', limit = 2)
            if (parts.size != 2) return@forEach
            val host = parts[0].trim().removePrefix("https://").substringBefore('/').lowercase()
            if (host.isBlank()) return@forEach
            parts[1].split('|').map { it.trim() }.filter { it.startsWith("sha256/") }.forEach { pin ->
                builder.add(host, pin)
                added = true
            }
        }
        return if (added) builder.build() else null
    }
}
