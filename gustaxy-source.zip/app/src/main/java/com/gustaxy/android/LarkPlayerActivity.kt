package com.gustaxy.android

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.OndemandVideo
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Sort
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.gustaxy.android.ui.theme.GustaxyAndroidTheme
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LarkPlayerActivity : ComponentActivity() {
    private var audioPermissionGranted by mutableStateOf(false)

    private val mediaPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        audioPermissionGranted = hasAudioPermission()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        audioPermissionGranted = hasAudioPermission()
        setContent {
            GustaxyAndroidTheme {
                LarkPlayerRoot(canReadAudio = audioPermissionGranted)
            }
        }
        if (!audioPermissionGranted) {
            window.decorView.postDelayed({ requestMediaPermissions() }, 350L)
        }
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestMediaPermissions() {
        val permissions = buildList {
            if (!hasAudioPermission()) {
                add(
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Manifest.permission.READ_MEDIA_AUDIO
                    } else {
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                )
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(
                    this@LarkPlayerActivity,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (permissions.isNotEmpty()) {
            mediaPermissionLauncher.launch(permissions.toTypedArray())
        }
    }

    @Composable
    private fun LarkPlayerRoot(canReadAudio: Boolean) {
        LarkLibraryScreen(
            canReadAudio = canReadAudio,
            onRequestPermission = ::requestMediaPermissions,
            onReferenceSearchAccepted = {
                startActivity(
                    Intent(this, InicialActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                )
                finish()
            }
        )
    }
}

private data class LocalTrack(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val uri: Uri,
)

private const val SEARCH_COMMAND_SHA256 =
    "b527ce5580d8333dfe193069380c65e7d900434e250e0092262bfc71dfd35cb5"

private fun normalizeSearch(value: String): String {
    val withoutAccents = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
    return withoutAccents.trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")
}

private fun isReferenceSearchCommand(value: String): Boolean {
    val digest = MessageDigest.getInstance("SHA-256")
        .digest(normalizeSearch(value).toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { byte -> "%02x".format(byte) } == SEARCH_COMMAND_SHA256
}

@Composable
private fun LarkLibraryScreen(
    canReadAudio: Boolean,
    onRequestPermission: () -> Unit,
    onReferenceSearchAccepted: () -> Unit,
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val isTablet = LocalConfiguration.current.screenWidthDp >= 600
    val sidePadding = if (isTablet) 32.dp else 20.dp
    var tracks by remember { mutableStateOf<List<LocalTrack>>(emptyList()) }
    var isLoading by remember { mutableStateOf(canReadAudio) }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var searchText by rememberSaveable { mutableStateOf("") }
    var searchSubmitted by rememberSaveable { mutableStateOf(false) }
    BackHandler(enabled = searchOpen) {
        searchText = ""
        searchSubmitted = false
        searchOpen = false
    }
    var activeTrack by rememberSaveable { mutableStateOf<LocalTrack?>(null) }
    var isPlaying by rememberSaveable { mutableStateOf(false) }
    var selectedTab by rememberSaveable { mutableIntStateOf(1) }
    var sortMode by rememberSaveable { mutableStateOf("Título") }
    var ascending by rememberSaveable { mutableStateOf(true) }
    var showFullPlayer by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(canReadAudio) {
        if (canReadAudio) {
            isLoading = true
            tracks = queryLocalTracks(context)
            isLoading = false
        } else {
            isLoading = false
        }
    }

    val filteredTracks = remember(tracks, searchText) {
        val query = searchText.trim().lowercase(Locale.ROOT)
        if (query.isBlank() || isReferenceSearchCommand(query)) {
            tracks
        } else {
            tracks.filter {
                it.title.lowercase(Locale.ROOT).contains(query) ||
                    it.artist.lowercase(Locale.ROOT).contains(query) ||
                    it.album.lowercase(Locale.ROOT).contains(query)
            }
        }
    }

    val visibleTracks = remember(filteredTracks, sortMode, ascending) {
        val sorted = when (sortMode) {
            "Artista" -> filteredTracks.sortedBy { it.artist.lowercase(Locale.ROOT) }
            "Álbum" -> filteredTracks.sortedBy { it.album.lowercase(Locale.ROOT) }
            else -> filteredTracks.sortedBy { it.title.lowercase(Locale.ROOT) }
        }
        if (ascending) sorted else sorted.asReversed()
    }

    fun submitSearch() {
        focusManager.clearFocus()
        searchSubmitted = true
        if (isReferenceSearchCommand(searchText)) {
            onReferenceSearchAccepted()
        }
    }

    Scaffold(
        containerColor = Color(0xFF0A0A0A),
        bottomBar = {
            activeTrack?.let { track ->
                MiniPlayer(
                    track = track,
                    isPlaying = isPlaying,
                    onPlayPause = {
                        sendPlaybackCommand(
                            context,
                            if (isPlaying) {
                                LarkPlaybackService.ACTION_PAUSE
                            } else {
                                LarkPlaybackService.ACTION_RESUME
                            }
                        )
                        isPlaying = !isPlaying
                    },
                    onReplay = {
                        startPlayback(context, track)
                        isPlaying = true
                    },
                    onExpand = { showFullPlayer = true }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0A0A))
                .padding(padding)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Header(
                searchOpen = searchOpen,
                searchText = searchText,
                onSearchTextChange = {
                    searchText = it
                    searchSubmitted = false
                },
                onSearchClick = { searchOpen = true },
                onBack = {
                    searchText = ""
                    searchSubmitted = false
                    searchOpen = false
                },
                onSearchSubmit = ::submitSearch,
                onSortClick = { ascending = !ascending },
                onSortSelected = { sortMode = it; ascending = true },
                onSettingsClick = { showSettings = true }
            )
            CategoryTabs(selectedTab = selectedTab, onSelected = { selectedTab = it })
            when {
                isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF2196F3))
                }
                !canReadAudio -> PermissionState(onRequestPermission)
                selectedTab != 1 -> MetadataLibraryTab(
                    tabIndex = selectedTab,
                    tracks = tracks,
                    onTrackClick = { track ->
                        activeTrack = track
                        isPlaying = true
                        startPlayback(context, track, tracks, tracks.indexOfFirst { it.id == track.id })
                    }
                )
                visibleTracks.isEmpty() -> EmptyLibrary(
                    title = if (searchSubmitted) "Nenhum resultado encontrado" else "Nenhuma música encontrada",
                    body = if (searchSubmitted) {
                        "Pesquise por outro título, artista ou álbum."
                    } else {
                        "Adicione músicas ao dispositivo para carregar sua biblioteca."
                    }
                )
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = sidePadding, end = if (isTablet) 26.dp else 14.dp, top = 12.dp, bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(visibleTracks, key = { it.id }) { track ->
                        TrackRow(
                            track = track,
                            isActive = activeTrack?.id == track.id,
                            onClick = {
                                activeTrack = track
                                isPlaying = true
                                startPlayback(context, track, visibleTracks, visibleTracks.indexOfFirst { it.id == track.id })
                            }
                        )
                    }
                }
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Configurações", color = Color.White) },
            text = { Text("Biblioteca local, notificações e reprodução em segundo plano estão disponíveis.", color = Color(0xFFBDBDBD)) },
            confirmButton = {
                TextButton(onClick = { showSettings = false }) { Text("Fechar", color = Color(0xFF2596FF)) }
            },
            containerColor = Color(0xFF202020)
        )
    }

    if (showFullPlayer && activeTrack != null) {
        AlertDialog(
            onDismissRequest = { showFullPlayer = false },
            title = { Text(activeTrack!!.title, color = Color.White) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Artwork(activeTrack!!, Modifier.size(220.dp))
                    Text(activeTrack!!.artist, color = Color(0xFFBDBDBD), modifier = Modifier.padding(top = 12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 14.dp)) {
                        IconButton(onClick = {
                            val index = visibleTracks.indexOfFirst { it.id == activeTrack!!.id }
                            val previous = visibleTracks.getOrNull((index - 1 + visibleTracks.size) % visibleTracks.size)
                            if (previous != null) {
                                activeTrack = previous
                                isPlaying = true
                                startPlayback(context, previous, visibleTracks, (index - 1 + visibleTracks.size) % visibleTracks.size)
                            } else {
                                sendPlaybackCommand(context, LarkPlaybackService.ACTION_PREVIOUS)
                            }
                        }) { Icon(Icons.Outlined.Replay, "Anterior", tint = Color.White) }
                        IconButton(onClick = {
                            sendPlaybackCommand(context, if (isPlaying) LarkPlaybackService.ACTION_PAUSE else LarkPlaybackService.ACTION_RESUME)
                            isPlaying = !isPlaying
                        }) { Icon(if (isPlaying) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, "Reproduzir", tint = Color.White) }
                        IconButton(onClick = {
                            val index = visibleTracks.indexOfFirst { it.id == activeTrack!!.id }
                            val next = visibleTracks.getOrNull((index + 1).mod(visibleTracks.size))
                            if (next != null) {
                                activeTrack = next
                                isPlaying = true
                                startPlayback(context, next, visibleTracks, (index + 1).mod(visibleTracks.size))
                            } else {
                                sendPlaybackCommand(context, LarkPlaybackService.ACTION_NEXT)
                            }
                        }) { Icon(Icons.Outlined.PlayArrow, "Próxima", tint = Color.White) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showFullPlayer = false }) { Text("Fechar", color = Color(0xFF2596FF)) } },
            containerColor = Color(0xFF202020)
        )
    }
}

@Composable
private fun Header(
    searchOpen: Boolean,
    searchText: String,
    onSearchTextChange: (String) -> Unit,
    onSearchClick: () -> Unit,
    onBack: () -> Unit,
    onSearchSubmit: () -> Unit,
    onSortClick: () -> Unit,
    onSortSelected: (String) -> Unit,
    onSettingsClick: () -> Unit,
) {
    val focusManager = LocalFocusManager.current
    var sortMenuOpen by rememberSaveable { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (searchOpen) {
            IconButton(onClick = onBack) {
                Icon(Icons.Outlined.ArrowBack, contentDescription = "Voltar", tint = Color.White)
            }
            OutlinedTextField(
                value = searchText,
                onValueChange = onSearchTextChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Pesquisar", color = Color(0xFF777777)) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        focusManager.clearFocus()
                        onSearchSubmit()
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF2596FF),
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = Color(0xFF2596FF),
                    focusedContainerColor = Color(0xFF171717),
                    unfocusedContainerColor = Color(0xFF171717)
                ),
                shape = RoundedCornerShape(14.dp)
            )
            IconButton(onClick = onSearchSubmit) {
                Icon(Icons.Outlined.Search, contentDescription = "Pesquisar", tint = Color.White)
            }
        } else {
            Image(
                painter = painterResource(R.drawable.lark_reference_icon),
                contentDescription = "Lark Player",
                modifier = Modifier.size(32.dp),
                contentScale = ContentScale.Fit
            )
            Image(
                painter = painterResource(R.drawable.lark_reference_wordmark),
                contentDescription = "Lark Player",
                modifier = Modifier
                    .padding(start = 8.dp)
                    .size(width = 120.dp, height = 32.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onSearchClick) {
                Icon(Icons.Outlined.Search, contentDescription = "Pesquisar", tint = Color.White, modifier = Modifier.size(28.dp))
            }
            Box {
                IconButton(onClick = { sortMenuOpen = true }) {
                    Icon(Icons.Outlined.Sort, contentDescription = "Ordenar", tint = Color.White, modifier = Modifier.size(26.dp))
                }
                DropdownMenu(
                    expanded = sortMenuOpen,
                    onDismissRequest = { sortMenuOpen = false }
                ) {
                    listOf("Título", "Artista", "Álbum").forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                sortMenuOpen = false
                                onSortSelected(option)
                            }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Inverter ordem") },
                        onClick = {
                            sortMenuOpen = false
                            onSortClick()
                        }
                    )
                }
            }
            IconButton(onClick = onSettingsClick) {
                Icon(Icons.Outlined.Settings, contentDescription = "Configurações", tint = Color.White, modifier = Modifier.size(26.dp))
            }
        }
    }
}

@Composable
private fun CategoryTabs(selectedTab: Int, onSelected: (Int) -> Unit) {
    val tabs = listOf("Vídeos", "Músicas", "Playlists", "Pastas", "Artistas", "Álbuns")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        tabs.forEachIndexed { index, tab ->
            val selected = index == selectedTab
            Surface(
                color = if (selected) Color(0xFF2596FF) else Color(0xFF191919),
                shape = RoundedCornerShape(24.dp)
            ) {
                Row(
                    modifier = Modifier
                        .clickable { onSelected(index) }
                        .padding(horizontal = 16.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (tab == "Vídeos") {
                        Icon(Icons.Outlined.OndemandVideo, contentDescription = null, tint = Color(0xFFAAAAAA), modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp))
                    }
                    Text(tab, color = if (selected) Color.White else Color(0xFFAAAAAA), fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun TrackRow(track: LocalTrack, isActive: Boolean, onClick: () -> Unit) {
    val isTablet = LocalConfiguration.current.screenWidthDp >= 600
    val artworkSize = if (isTablet) 72.dp else 56.dp
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isActive) Color(0xFF191919) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(track = track, modifier = Modifier.size(artworkSize))
        Column(modifier = Modifier.weight(1f).padding(start = 14.dp)) {
            Text(
                text = track.title.ifBlank { "Sem título" },
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = "LETRA  ${track.artist.ifBlank { "Artista desconhecido" }}",
                color = Color(0xFF9C9C9C),
                fontSize = 12.sp,
                maxLines = 1,
                modifier = Modifier.padding(top = 4.dp)
            )
            Text(
                text = track.album.ifBlank { "Álbum desconhecido" },
                color = Color(0xFF777777),
                fontSize = 11.sp,
                maxLines = 1,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
        Icon(Icons.Outlined.MoreVert, contentDescription = "Mais opções", tint = Color(0xFF888888), modifier = Modifier.padding(horizontal = 4.dp))
    }
}

@Composable
private fun Artwork(track: LocalTrack, modifier: Modifier) {
    val context = LocalContext.current
    var bitmap by remember(track.uri) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(track.uri) {
        bitmap = withContext(Dispatchers.IO) { readEmbeddedArtwork(context, track.uri) }
    }
    if (bitmap != null) {
        Image(
            bitmap = bitmap!!.asImageBitmap(),
            contentDescription = track.album,
            modifier = modifier.clip(RoundedCornerShape(14.dp)),
            contentScale = ContentScale.Crop
        )
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF272727)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(R.drawable.lark_reference_icon),
                contentDescription = null,
                modifier = Modifier.size(32.dp),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
private fun MetadataLibraryTab(
    tabIndex: Int,
    tracks: List<LocalTrack>,
    onTrackClick: (LocalTrack) -> Unit,
) {
    val values = when (tabIndex) {
        2 -> tracks.map { it.album.ifBlank { "Playlist local" } }.distinct()
        3 -> tracks.map { "Armazenamento do dispositivo" }.distinct()
        4 -> tracks.map { it.artist.ifBlank { "Artista desconhecido" } }.distinct()
        else -> tracks.map { it.album.ifBlank { "Álbum desconhecido" } }.distinct()
    }
    if (values.isEmpty()) {
        EmptyLibrary("Nenhum item encontrado", "Adicione músicas ao dispositivo para preencher esta aba.")
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(values) { value ->
                val sample = tracks.firstOrNull { it.album == value || it.artist == value } ?: tracks.first()
                TrackRow(sample.copy(title = value), isActive = false, onClick = { onTrackClick(sample) })
            }
        }
    }
}

@Composable
private fun MiniPlayer(
    track: LocalTrack,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onReplay: () -> Unit,
    onExpand: () -> Unit = {},
) {
    Surface(color = Color(0xFF3D3D3D), tonalElevation = 0.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Artwork(track = track, modifier = Modifier.size(52.dp).clickable(onClick = onExpand))
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(track.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                Text(track.artist, color = Color(0xFFBEBEBE), fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(top = 3.dp))
            }
            IconButton(onClick = onReplay) {
                Icon(Icons.Outlined.Replay, contentDescription = "Repetir", tint = Color.White)
            }
            IconButton(onClick = onPlayPause) {
                Icon(
                    if (isPlaying) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                    contentDescription = if (isPlaying) "Pausar" else "Reproduzir",
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
private fun PermissionState(onRequestPermission: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(R.drawable.lark_reference_icon),
            contentDescription = null,
            modifier = Modifier.size(68.dp),
            contentScale = ContentScale.Fit
        )
        Text("Permissão necessária", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
        Text("Permita o acesso às músicas do dispositivo para carregar sua biblioteca.", color = Color(0xFF9B9B9B), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        Button(
            onClick = onRequestPermission,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2596FF)),
            modifier = Modifier.padding(top = 18.dp)
        ) {
            Text("Permitir acesso")
        }
    }
}

@Composable
private fun EmptyLibrary(title: String, body: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(R.drawable.lark_reference_icon),
            contentDescription = null,
            modifier = Modifier.size(68.dp),
            contentScale = ContentScale.Fit
        )
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
        Text(body, color = Color(0xFF9B9B9B), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

private suspend fun queryLocalTracks(context: Context): List<LocalTrack> = withContext(Dispatchers.IO) {
    val projection = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION
    )
    val result = mutableListOf<LocalTrack>()
    runCatching {
        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 0",
            null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            while (cursor.moveToNext() && result.size < 500) {
                val id = cursor.getLong(idIndex)
                result += LocalTrack(
                    id = id,
                    title = cursor.getString(titleIndex).orEmpty(),
                    artist = cursor.getString(artistIndex).orEmpty(),
                    album = cursor.getString(albumIndex).orEmpty(),
                    uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                )
            }
        }
    }
    result
}

private suspend fun readEmbeddedArtwork(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
    runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            retriever.embeddedPicture?.let { bytes ->
                android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
        } finally {
            retriever.release()
        }
    }.getOrNull()
}

private fun startPlayback(
    context: Context,
    track: LocalTrack,
    queue: List<LocalTrack> = listOf(track),
    queueIndex: Int = 0,
) {
    val intent = Intent(context, LarkPlaybackService::class.java).apply {
        action = LarkPlaybackService.ACTION_PLAY
        putExtra(LarkPlaybackService.EXTRA_URI, track.uri.toString())
        putExtra(LarkPlaybackService.EXTRA_TITLE, track.title)
        putExtra(LarkPlaybackService.EXTRA_ARTIST, track.artist)
        putExtra(LarkPlaybackService.EXTRA_ALBUM, track.album)
        putStringArrayListExtra(LarkPlaybackService.EXTRA_QUEUE_URIS, ArrayList(queue.map { it.uri.toString() }))
        putStringArrayListExtra(LarkPlaybackService.EXTRA_QUEUE_TITLES, ArrayList(queue.map { it.title }))
        putStringArrayListExtra(LarkPlaybackService.EXTRA_QUEUE_ARTISTS, ArrayList(queue.map { it.artist }))
        putStringArrayListExtra(LarkPlaybackService.EXTRA_QUEUE_ALBUMS, ArrayList(queue.map { it.album }))
        putExtra(LarkPlaybackService.EXTRA_QUEUE_INDEX, queueIndex.coerceAtLeast(0))
    }
    ContextCompat.startForegroundService(context, intent)
}

private fun sendPlaybackCommand(context: Context, action: String) {
    ContextCompat.startForegroundService(
        context,
        Intent(context, LarkPlaybackService::class.java).setAction(action)
    )
}
