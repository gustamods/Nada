package com.gustaxy.android

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Aba "Info" do Dashboard.
 * StatusCard vem de DashboardComponents.kt. BuildConfig é gerado no mesmo pacote,
 * então não precisa de import.
 */
@Composable
internal fun InfoTab() {
    Text("Info", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
    Text("Gustaxy Android", modifier = Modifier.padding(top = 6.dp), color = Color(0xFF9DA8BC), fontSize = 14.sp)
    Spacer(modifier = Modifier.height(22.dp))
    StatusCard(title = "Versão", value = BuildConfig.VERSION_NAME, accent = Color(0xFF2B7BFF))
    Spacer(modifier = Modifier.height(12.dp))
    StatusCard(title = "Integridade", value = "Nativa ativa", accent = Color(0xFFFF3855))
}
