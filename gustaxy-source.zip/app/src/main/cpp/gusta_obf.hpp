#pragma once
// ============================================================================
// gusta_obf.hpp — camada de ofuscação / anti-tamper / syscalls diretas.
// Uso exclusivo interno da libgusta. Nenhuma string sensível aparece em
// cleartext no binário: tudo nasce já ofuscado em tempo de compilação.
// ============================================================================
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdlib>
#include <string>
#include <new>

#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ptrace.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/auxv.h>
#include <pthread.h>
#include <dlfcn.h>
#include <link.h>
#include <elf.h>
#include <errno.h>

#include "crypto_core.hpp"

// ---------------------------------------------------------------------------
// 1. String obfuscation em tempo de compilação (XOR multi-byte + rotate)
//    A chave mistura um salt constante com a posição — cada byte tem chave
//    diferente. Nada é armazenado como texto plano no .rodata.
// ---------------------------------------------------------------------------
namespace gustaobf {

// PRNG determinístico em compile-time (splitmix32) para derivar chaves.
constexpr uint32_t cx_next(uint32_t& s) {
    s += 0x9E3779B9u;
    uint32_t z = s;
    z = (z ^ (z >> 16)) * 0x21F0AAADu;
    z = (z ^ (z >> 15)) * 0x735A2D97u;
    return z ^ (z >> 15);
}

constexpr uint8_t cx_keybyte(uint32_t seed, size_t i) {
    uint32_t s = seed ^ (0xA5A5A5A5u + static_cast<uint32_t>(i) * 0x01010101u);
    uint32_t r = 0;
    r ^= cx_next(s); r ^= cx_next(s); r ^= cx_next(s);
    return static_cast<uint8_t>((r >> ((i & 3u) * 8u)) & 0xFFu);
}

constexpr uint8_t cx_rotl8(uint8_t v, unsigned n) {
    return static_cast<uint8_t>((v << (n & 7)) | (v >> ((8 - (n & 7)) & 7)));
}
constexpr uint8_t cx_rotr8(uint8_t v, unsigned n) {
    return static_cast<uint8_t>((v >> (n & 7)) | (v << ((8 - (n & 7)) & 7)));
}

// Codifica (compile-time): byte -> rotl(xor)
constexpr uint8_t cx_encode(uint8_t plain, uint32_t seed, size_t i) {
    const uint8_t k = cx_keybyte(seed, i);
    const unsigned rot = static_cast<unsigned>((k ^ seed) & 7u);
    return cx_rotl8(static_cast<uint8_t>(plain ^ k), rot);
}
// Decodifica (runtime): byte -> xor(rotr)
inline uint8_t cx_decode(uint8_t enc, uint32_t seed, size_t i) {
    const uint8_t k = cx_keybyte(seed, i);
    const unsigned rot = static_cast<unsigned>((k ^ seed) & 7u);
    return static_cast<uint8_t>(cx_rotr8(enc, rot) ^ k);
}

// Array ofuscado em compile-time; o caller decodifica para buffer local e
// zera logo após o uso. NUNCA retorna ponteiro persistente.
template <size_t N, uint32_t Seed>
struct ObfStr {
    uint8_t data[N];
    constexpr ObfStr(const char (&s)[N]) : data{} {
        for (size_t i = 0; i < N; ++i) {
            data[i] = cx_encode(static_cast<uint8_t>(s[i]), Seed, i);
        }
    }
    void decode(char* out) const {
        for (size_t i = 0; i < N; ++i) out[i] = static_cast<char>(cx_decode(data[i], Seed, i));
    }
};

} // namespace gustaobf

// Macro para criar e decodificar uma string ofuscada num buffer local `dst`.
// Uso: GUSTA_STR(dst, "texto"); ... usar dst ... ; secureZero(dst, len)
#define GUSTA_OBF_SEED2(cnt) (0x6D2B79F5u ^ (static_cast<uint32_t>(cnt) * 0x1F123BB5u))
#define GUSTA_STR(dst, literal)                                                       \
    constexpr auto _gusta_obf_##dst = ::gustaobf::ObfStr<sizeof(literal),             \
        GUSTA_OBF_SEED2(__COUNTER__)>(literal);                                       \
    char dst[sizeof(literal)]; _gusta_obf_##dst.decode(dst)

namespace gustaobf {

// ---------------------------------------------------------------------------
// 2. Syscalls diretas (bypass de hooks em libc).
// ---------------------------------------------------------------------------
inline int sys_openat(int dirfd, const char* path, int flags, mode_t mode) {
    return static_cast<int>(::syscall(SYS_openat, dirfd, path, flags, mode));
}
inline ssize_t sys_read(int fd, void* buf, size_t count) {
    return ::syscall(SYS_read, fd, buf, count);
}
inline int sys_close(int fd) {
    return static_cast<int>(::syscall(SYS_close, fd));
}
inline int sys_faccessat(int dirfd, const char* path, int mode) {
    return static_cast<int>(::syscall(SYS_faccessat, dirfd, path, mode, 0));
}
inline ssize_t sys_getrandom(void* buf, size_t len, unsigned flags) {
    return ::syscall(SYS_getrandom, buf, len, flags);
}

// PRNG de runtime com entropia do kernel (não-determinístico).
inline uint32_t rnd32() {
    uint32_t v = 0;
    if (sys_getrandom(&v, sizeof(v), 0) != sizeof(v)) {
        v = static_cast<uint32_t>(::getpid()) ^ 0x9E3779B9u;
        v ^= static_cast<uint32_t>(reinterpret_cast<uintptr_t>(&v) >> 3);
        struct timespec ts{};
        ::clock_gettime(CLOCK_MONOTONIC, &ts);
        v ^= static_cast<uint32_t>(ts.tv_nsec) ^ static_cast<uint32_t>(ts.tv_sec);
        v ^= v << 13; v ^= v >> 17; v ^= v << 5;
    }
    return v;
}

inline uint32_t rnd_range(uint32_t loMs, uint32_t hiMs) {
    if (hiMs <= loMs) return loMs;
    return loMs + (rnd32() % (hiMs - loMs + 1u));
}

// ---------------------------------------------------------------------------
// 3. Anti-debug: leitura de TracerPid via syscall com tracer PERMITIDO.
//    Quando aplicamos PTRACE_TRACEME defensivo, o TracerPid passa a ser o
//    processo-pai — isso é legítimo e NÃO pode ser tratado como debugger
//    (caso contrário todo usuário legítimo seria encerrado).
// ---------------------------------------------------------------------------
inline bool tracer_is_debugger(pid_t allowedTracer) {
    const uint8_t enc[] = {
        static_cast<uint8_t>('/' ^ 0x5A), static_cast<uint8_t>('p' ^ 0x5A),
        static_cast<uint8_t>('r' ^ 0x5A), static_cast<uint8_t>('o' ^ 0x5A),
        static_cast<uint8_t>('c' ^ 0x5A), static_cast<uint8_t>('/' ^ 0x5A),
        static_cast<uint8_t>('s' ^ 0x5A), static_cast<uint8_t>('e' ^ 0x5A),
        static_cast<uint8_t>('l' ^ 0x5A), static_cast<uint8_t>('f' ^ 0x5A),
        static_cast<uint8_t>('/' ^ 0x5A), static_cast<uint8_t>('s' ^ 0x5A),
        static_cast<uint8_t>('t' ^ 0x5A), static_cast<uint8_t>('a' ^ 0x5A),
        static_cast<uint8_t>('t' ^ 0x5A), static_cast<uint8_t>('u' ^ 0x5A),
        static_cast<uint8_t>('s' ^ 0x5A)
    };
    char path[sizeof(enc) + 1];
    for (size_t i = 0; i < sizeof(enc); ++i) path[i] = static_cast<char>(enc[i] ^ 0x5A);
    path[sizeof(enc)] = '\0';

    int fd = sys_openat(AT_FDCWD, path, O_RDONLY | O_CLOEXEC, 0);
    gustacrypto::secureZero(path, sizeof(path));
    if (fd < 0) return false;
    char buf[2048];
    ssize_t n = sys_read(fd, buf, sizeof(buf) - 1);
    sys_close(fd);
    if (n <= 0) { gustacrypto::secureZero(buf, sizeof(buf)); return false; }
    buf[n] = '\0';

    const char* p = std::strstr(buf, "TracerPid:");
    if (!p) { gustacrypto::secureZero(buf, sizeof(buf)); return false; }
    p += 10;
    while (*p == ' ' || *p == '\t') ++p;
    const long tracer = std::strtol(p, nullptr, 10);
    gustacrypto::secureZero(buf, sizeof(buf));
    if (tracer == 0) return false;                             // ninguém tracando
    if (allowedTracer > 0 && tracer == allowedTracer) return false; // pai defensivo
    return true;                                                // tracer estranho = debugger
}

// Compat: checagem sem tracer permitido (qualquer TracerPid != 0 é suspeito).
inline bool debugger_present() {
    return tracer_is_debugger(0);
}

// Self-attach defensivo: um processo só pode ter 1 tracer. Falha (EPERM)
// quando um debugger externo já anexou primeiro.
inline bool anti_debug_self_attach() {
    return ::ptrace(PTRACE_TRACEME, 0, nullptr, nullptr) >= 0;
}

// ---------------------------------------------------------------------------
// 4. Varredura de /proc/self/maps por assinaturas (path ofuscado + syscalls).
// ---------------------------------------------------------------------------
inline bool scan_maps_for(const char* needle) {
    const uint8_t encMaps[] = {
        static_cast<uint8_t>('/' ^ 0x5A), static_cast<uint8_t>('p' ^ 0x5A),
        static_cast<uint8_t>('r' ^ 0x5A), static_cast<uint8_t>('o' ^ 0x5A),
        static_cast<uint8_t>('c' ^ 0x5A), static_cast<uint8_t>('/' ^ 0x5A),
        static_cast<uint8_t>('s' ^ 0x5A), static_cast<uint8_t>('e' ^ 0x5A),
        static_cast<uint8_t>('l' ^ 0x5A), static_cast<uint8_t>('f' ^ 0x5A),
        static_cast<uint8_t>('/' ^ 0x5A), static_cast<uint8_t>('m' ^ 0x5A),
        static_cast<uint8_t>('a' ^ 0x5A), static_cast<uint8_t>('p' ^ 0x5A),
        static_cast<uint8_t>('s' ^ 0x5A)
    };
    char mapsPath[sizeof(encMaps) + 1];
    for (size_t i = 0; i < sizeof(encMaps); ++i) mapsPath[i] = static_cast<char>(encMaps[i] ^ 0x5A);
    mapsPath[sizeof(encMaps)] = '\0';

    int fd = sys_openat(AT_FDCWD, mapsPath, O_RDONLY | O_CLOEXEC, 0);
    gustacrypto::secureZero(mapsPath, sizeof(mapsPath));
    if (fd < 0) return false;

    char chunk[4096];
    ssize_t n;
    bool found = false;
    std::string carry;
    const size_t needleLen = std::strlen(needle);
    while ((n = sys_read(fd, chunk, sizeof(chunk))) > 0) {
        std::string data = carry + std::string(chunk, static_cast<size_t>(n));
        if (data.find(needle) != std::string::npos) { found = true; break; }
        carry = (needleLen > 1 && data.size() >= needleLen - 1)
            ? data.substr(data.size() - (needleLen - 1)) : data;
    }
    sys_close(fd);
    gustacrypto::secureZero(chunk, sizeof(chunk));
    return found;
}

// Varre maps por UMA assinatura ofuscada em compile-time (GUSTA_STR): o
// literal nunca vai para o .rodata — só o array ofuscado. O buffer decodado
// é zerado imediatamente após a varredura.
#define GUSTA_SCAN_MAPS(literal, hitVar)                                  \
    do {                                                                  \
        GUSTA_STR(_scanbuf, literal);                                     \
        if (scan_maps_for(_scanbuf)) {                                    \
            gustacrypto::secureZero(_scanbuf, sizeof(_scanbuf));          \
            hitVar = true;                                                \
        } else {                                                          \
            gustacrypto::secureZero(_scanbuf, sizeof(_scanbuf));          \
        }                                                                 \
    } while (0)

// Detecta Frida/Gadget por assinaturas ofuscadas (nada em cleartext no ELF).
inline bool frida_detected() {
    bool hit = false;
    GUSTA_SCAN_MAPS("frida-agent", hit);  if (hit) return true;
    GUSTA_SCAN_MAPS("frida-gadget", hit); if (hit) return true;
    GUSTA_SCAN_MAPS("libfrida", hit);     if (hit) return true;
    GUSTA_SCAN_MAPS("re.frida", hit);     if (hit) return true;
    GUSTA_SCAN_MAPS("/frida/", hit);      if (hit) return true;
    GUSTA_SCAN_MAPS("gum-js-loop", hit);  if (hit) return true;
    GUSTA_SCAN_MAPS("linjector", hit);    if (hit) return true;
    return false;
}

// Detecta Xposed/Magisk/LSPosed conhecidos — mesma ofuscação das assinaturas.
inline bool injection_detected() {
    bool hit = false;
    GUSTA_SCAN_MAPS("xposed", hit);    if (hit) return true;
    GUSTA_SCAN_MAPS("lsposed", hit);   if (hit) return true;
    GUSTA_SCAN_MAPS("substrate", hit); if (hit) return true;
    GUSTA_SCAN_MAPS("riru", hit);      if (hit) return true;
    GUSTA_SCAN_MAPS("zygisk", hit);    if (hit) return true;
    GUSTA_SCAN_MAPS("edxposed", hit);  if (hit) return true;
    GUSTA_SCAN_MAPS("dreamland", hit); if (hit) return true;
    return false;
}

// ---------------------------------------------------------------------------
// 5. Detecção de emulador (paths + drivers) via syscall, tudo ofuscado.
// ---------------------------------------------------------------------------
#define GUSTA_CHECK_PATH(literal, hitVar)                                 \
    do {                                                                  \
        GUSTA_STR(_pbuf, literal);                                        \
        if (sys_faccessat(AT_FDCWD, _pbuf, F_OK) == 0) {                  \
            gustacrypto::secureZero(_pbuf, sizeof(_pbuf));                \
            hitVar = true;                                                \
        } else {                                                          \
            gustacrypto::secureZero(_pbuf, sizeof(_pbuf));                \
        }                                                                 \
    } while (0)

inline bool emulator_detected() {
    bool hit = false;
    GUSTA_CHECK_PATH("/dev/goldfish_pipe", hit);                    if (hit) return true;
    GUSTA_CHECK_PATH("/dev/vboxguest", hit);                        if (hit) return true;
    GUSTA_CHECK_PATH("/dev/socket/qemud", hit);                     if (hit) return true;
    GUSTA_CHECK_PATH("/system/lib/libc_malloc_debug_qemu.so", hit); if (hit) return true;
    GUSTA_CHECK_PATH("/sys/qemu_trace", hit);                       if (hit) return true;
    GUSTA_CHECK_PATH("/dev/socket/genyd", hit);                     if (hit) return true;
    GUSTA_CHECK_PATH("/dev/socket/baseband_genyd", hit);            if (hit) return true;

    // /proc/tty/drivers (path ofuscado por XOR 0x5A)
    const uint8_t encDrv[] = {
        static_cast<uint8_t>('/' ^ 0x5A), static_cast<uint8_t>('p' ^ 0x5A),
        static_cast<uint8_t>('r' ^ 0x5A), static_cast<uint8_t>('o' ^ 0x5A),
        static_cast<uint8_t>('c' ^ 0x5A), static_cast<uint8_t>('/' ^ 0x5A),
        static_cast<uint8_t>('t' ^ 0x5A), static_cast<uint8_t>('t' ^ 0x5A),
        static_cast<uint8_t>('y' ^ 0x5A), static_cast<uint8_t>('/' ^ 0x5A),
        static_cast<uint8_t>('d' ^ 0x5A), static_cast<uint8_t>('r' ^ 0x5A),
        static_cast<uint8_t>('i' ^ 0x5A), static_cast<uint8_t>('v' ^ 0x5A),
        static_cast<uint8_t>('e' ^ 0x5A), static_cast<uint8_t>('r' ^ 0x5A),
        static_cast<uint8_t>('s' ^ 0x5A)
    };
    char drvPath[sizeof(encDrv) + 1];
    for (size_t i = 0; i < sizeof(encDrv); ++i) drvPath[i] = static_cast<char>(encDrv[i] ^ 0x5A);
    drvPath[sizeof(encDrv)] = '\0';
    int fd = sys_openat(AT_FDCWD, drvPath, O_RDONLY | O_CLOEXEC, 0);
    gustacrypto::secureZero(drvPath, sizeof(drvPath));
    if (fd < 0) return false;

    char buf[4096];
    ssize_t n = sys_read(fd, buf, sizeof(buf) - 1);
    sys_close(fd);
    if (n <= 0) { gustacrypto::secureZero(buf, sizeof(buf)); return false; }
    buf[n] = '\0';

    // Keywords de drivers ofuscadas (não aparecem em cleartext no .rodata).
    GUSTA_STR(kGold, "goldfish");
    GUSTA_STR(kVbox, "vbox");
    GUSTA_STR(kQemu, "qemu");
    const bool found = std::strstr(buf, kGold) != nullptr ||
                       std::strstr(buf, kVbox) != nullptr ||
                       std::strstr(buf, kQemu) != nullptr;
    gustacrypto::secureZero(kGold, sizeof(kGold));
    gustacrypto::secureZero(kVbox, sizeof(kVbox));
    gustacrypto::secureZero(kQemu, sizeof(kQemu));
    gustacrypto::secureZero(buf, sizeof(buf));
    return found;
}

// ---------------------------------------------------------------------------
// 6. Anti-tamper da própria .so: valida o ELF header da região carregada em
//    memória (detecta sobrescrita/patch do cabeçalho).
// ---------------------------------------------------------------------------
inline bool elf_header_sane() {
    Dl_info info{};
    if (dladdr(reinterpret_cast<const void*>(&elf_header_sane), &info) == 0 || info.dli_fbase == nullptr) {
        return false;
    }
    const auto* ehdr = reinterpret_cast<const ElfW(Ehdr)*>(info.dli_fbase);
    if (ehdr->e_ident[EI_MAG0] != ELFMAG0 || ehdr->e_ident[EI_MAG1] != ELFMAG1 ||
        ehdr->e_ident[EI_MAG2] != ELFMAG2 || ehdr->e_ident[EI_MAG3] != ELFMAG3) {
        return false;
    }
    return true;
}

// ---------------------------------------------------------------------------
// 7. Util: existência de arquivo via syscall.
// ---------------------------------------------------------------------------
inline bool file_exists(const char* path) {
    return sys_faccessat(AT_FDCWD, path, F_OK) == 0;
}

} // namespace gustaobf
