#include <jni.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <new>
#include <atomic>
#include <thread>
#include <chrono>
#include <ctime>
#include <unistd.h>
#include "crypto_core.hpp"
#include "gusta_obf.hpp"

#ifndef GUSTAXY_INTEGRITY_SECRET_XOR_HEX
#define GUSTAXY_INTEGRITY_SECRET_XOR_HEX ""
#endif

#ifndef GUSTAXY_BUILD_FINGERPRINT
#define GUSTAXY_BUILD_FINGERPRINT ""
#endif

using namespace gustacrypto;
using namespace gustaobf;

// ---------------------------------------------------------------------------
// Estado global protegido (não-exportado).
// ---------------------------------------------------------------------------
namespace {

std::atomic<bool> g_tampered{false};
std::atomic<bool> g_armed{false};
// Heartbeat como TIMESTAMP (epoch s) da última varredura bem-sucedida.
// Contador causaria falso positivo nos primeiros 45s; timestamp não.
std::atomic<int64_t> g_heartbeat{0};
pthread_t g_watchdog{};
std::atomic<bool> g_watchdog_started{false};
// PID do processo-pai registrado quando o anti-debug defensivo é armado; o
// watchdog o trata como tracer legítimo (evita falso positivo do TRACEME).
std::atomic<pid_t> g_allowed_tracer{0};

// Contador de violações persistentes → comportamento híbrido.
std::atomic<uint32_t> g_violations{0};

// opaque predicate: sempre verdadeiro, mas o compilador/analisador não prova.
inline bool opaque_true(uint32_t x) {
    volatile uint32_t v = x;
    return ((v * v + v) & 1u) == 0u;
}

inline void secure_kill_process() {
    // Fecha silencioso: sem toast, sem log, sem crash óbvio.
    ::_exit(0);
}

void report_violation_to_server(const char* reason) {
    (void)reason;
    g_violations.fetch_add(1, std::memory_order_relaxed);
}

// Ação híbrida: 1º fecha silencioso; persistência → banimento no servidor.
[[noreturn]] inline void enforce(const char* reason) {
    g_tampered.store(true, std::memory_order_release);
    report_violation_to_server(reason);
    const uint32_t delay = 120u + (rnd32() % 400u);
    std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    secure_kill_process();
    __builtin_unreachable();
}

// Redundância: duas vias independentes de detecção de debugger.
inline bool check_debug_a() {
    return tracer_is_debugger(g_allowed_tracer.load(std::memory_order_acquire));
}
inline bool check_debug_b() {
    const uint8_t e[] = {
        static_cast<uint8_t>('/' ^ 0x5A), static_cast<uint8_t>('p' ^ 0x5A),
        static_cast<uint8_t>('r' ^ 0x5A), static_cast<uint8_t>('o' ^ 0x5A),
        static_cast<uint8_t>('c' ^ 0x5A), static_cast<uint8_t>('/' ^ 0x5A),
        static_cast<uint8_t>('s' ^ 0x5A), static_cast<uint8_t>('e' ^ 0x5A),
        static_cast<uint8_t>('l' ^ 0x5A), static_cast<uint8_t>('f' ^ 0x5A),
        static_cast<uint8_t>('/' ^ 0x5A), static_cast<uint8_t>('s' ^ 0x5A),
        static_cast<uint8_t>('t' ^ 0x5A), static_cast<uint8_t>('a' ^ 0x5A),
        static_cast<uint8_t>('t' ^ 0x5A), static_cast<uint8_t>('u' ^ 0x5A),
        static_cast<uint8_t>('s' ^ 0x5A)
    };
    char path[sizeof(e) + 1];
    for (size_t i = 0; i < sizeof(e); ++i) path[i] = static_cast<char>(e[i] ^ 0x5A);
    path[sizeof(e)] = '\0';
    int fd = sys_openat(AT_FDCWD, path, O_RDONLY | O_CLOEXEC, 0);
    secureZero(path, sizeof(path));
    if (fd < 0) return false;
    char buf[1024];
    ssize_t n = sys_read(fd, buf, sizeof(buf) - 1);
    sys_close(fd);
    if (n <= 0) return false;
    buf[n] = '\0';
    const char* p = std::strstr(buf, "TracerPid:");
    bool dbg = false;
    if (p) {
        p += 10;
        while (*p == ' ' || *p == '\t') ++p;
        const long tracer = std::strtol(p, nullptr, 10);
        const pid_t allowed = g_allowed_tracer.load(std::memory_order_acquire);
        // TracerPid == pai defensivo (TRACEME) NÃO é debugger.
        dbg = (tracer != 0) && !(allowed > 0 && tracer == allowed);
    }
    secureZero(buf, sizeof(buf));
    return dbg;
}

// Watchdog nativo: thread própria, intervalo aleatório, validação contínua.
void* watchdog_main(void*) {
    // Registra o pai ANTES do TRACEME: após o self-attach, TracerPid==ppid,
    // e esse pai passa a ser o tracer permitido (não é debugger).
    const pid_t parent = ::getppid();
    g_allowed_tracer.store(parent, std::memory_order_release);
    if (!anti_debug_self_attach()) {
        // Já existe um tracer externo e NÃO é o pai legítimo → violação.
        if (tracer_is_debugger(parent)) {
            enforce("ptrace");
        }
        g_allowed_tracer.store(0, std::memory_order_release);
    }
    g_armed.store(true, std::memory_order_release);
    // Marca o heartbeat inicial para evitar falso positivo de arranque.
    g_heartbeat.store(static_cast<int64_t>(::time(nullptr)), std::memory_order_release);

    for (;;) {
        const uint32_t interval = rnd_range(15000u, 45000u); // 15–45s
        std::this_thread::sleep_for(std::chrono::milliseconds(interval));

        // Heartbeat prova que o watchdog está vivo e não-hookeado.
        g_heartbeat.store(static_cast<int64_t>(::time(nullptr)), std::memory_order_relaxed);

        // Checagens redundantes (ordem variável por iteração).
        const uint32_t order = rnd32();
        if (order & 1u) {
            if (check_debug_a() || check_debug_b()) enforce("dbg");
            if (frida_detected()) enforce("frida");
            if (injection_detected()) enforce("inject");
        } else {
            if (frida_detected()) enforce("frida");
            if (injection_detected()) enforce("inject");
            if (check_debug_a() || check_debug_b()) enforce("dbg");
        }
        if (emulator_detected()) enforce("emu");
        if (!elf_header_sane()) enforce("elf");
    }
    return nullptr;
}

inline void ensure_watchdog() {
    bool expected = false;
    if (g_watchdog_started.compare_exchange_strong(expected, true)) {
        if (pthread_create(&g_watchdog, nullptr, &watchdog_main, nullptr) == 0) {
            pthread_detach(g_watchdog);
        } else {
            g_watchdog_started.store(false);
        }
    }
}

// Watchdog vivo: último heartbeat não pode ser mais velho que ~120s.
inline bool watchdog_alive() {
    const int64_t hb = g_heartbeat.load(std::memory_order_relaxed);
    if (hb == 0) return true; // janela de arranque — não punir
    const int64_t now = static_cast<int64_t>(::time(nullptr));
    return (now - hb) <= 120;
}

} // namespace

// ---------------------------------------------------------------------------
// URL do servidor: construção dinâmica em runtime a partir de shards ofuscados
// em compile-time. A URL NUNCA existe completa no binário nem em memória por
// mais que alguns microssegundos.
// ---------------------------------------------------------------------------
namespace {

void build_primary_host(char* out, size_t outCap) {
    if (outCap < 64) return;
    GUSTA_STR(s1, "gst"); GUSTA_STR(s2, "xon"); GUSTA_STR(s3, "lin");
    GUSTA_STR(s4, "e.x1"); GUSTA_STR(s5, "0.m"); GUSTA_STR(s6, "x");
    std::string host;
    host.reserve(32);
    host += s1; host += s2; host += s3; host += s4; host += s5; host += s6;
    secureZero(s1, sizeof(s1)); secureZero(s2, sizeof(s2)); secureZero(s3, sizeof(s3));
    secureZero(s4, sizeof(s4)); secureZero(s5, sizeof(s5)); secureZero(s6, sizeof(s6));
    // monta o esquema ofuscado + host (sem literal em cleartext no .rodata)
    GUSTA_STR(scheme, "https://");
    std::string full = scheme;
    secureZero(scheme, sizeof(scheme));
    full += host;
    const size_t n = full.size() < outCap - 1 ? full.size() : outCap - 1;
    std::memcpy(out, full.data(), n);
    out[n] = '\0';
    secureZero(host.data(), host.size());
    secureZero(full.data(), full.size());
}

void build_fallback_host(char* out, size_t outCap) {
    if (outCap < 64) return;
    GUSTA_STR(f1, "x12"); GUSTA_STR(f2, ".x1"); GUSTA_STR(f3, "0ho");
    GUSTA_STR(f4, "sti"); GUSTA_STR(f5, "ng."); GUSTA_STR(f6, "com");
    std::string host;
    host += f1; host += f2; host += f3; host += f4; host += f5; host += f6;
    secureZero(f1, sizeof(f1)); secureZero(f2, sizeof(f2)); secureZero(f3, sizeof(f3));
    secureZero(f4, sizeof(f4)); secureZero(f5, sizeof(f5)); secureZero(f6, sizeof(f6));
    const size_t n = host.size() < outCap - 1 ? host.size() : outCap - 1;
    std::memcpy(out, host.data(), n);
    out[n] = '\0';
    secureZero(host.data(), host.size());
}

} // namespace

// ---------------------------------------------------------------------------
// JNI — registrado dinamicamente via RegisterNatives (não Java_com_...).
// ---------------------------------------------------------------------------

static jbyteArray JNICALL n_sha(JNIEnv* env, jobject, jbyteArray data) {
    ensure_watchdog();
    if (g_tampered.load(std::memory_order_acquire)) enforce("sha_tamper");
    if (data == nullptr) return nullptr;
    jsize len = env->GetArrayLength(data);
    jbyte* elems = env->GetByteArrayElements(data, nullptr);
    if (elems == nullptr) return nullptr;
    uint8_t digest[32];
    sha256(reinterpret_cast<const uint8_t*>(elems), static_cast<size_t>(len), digest);
    env->ReleaseByteArrayElements(data, elems, JNI_ABORT);
    jbyteArray result = env->NewByteArray(32);
    if (result == nullptr) { secureZero(digest, sizeof(digest)); return nullptr; }
    env->SetByteArrayRegion(result, 0, 32, reinterpret_cast<const jbyte*>(digest));
    secureZero(digest, sizeof(digest));
    return result;
}

static jlong JNICALL n_hinit(JNIEnv*, jobject) {
    ensure_watchdog();
    auto* ctx = new (std::nothrow) Sha256();
    if (!ctx) return 0;
    ctx->init();
    return reinterpret_cast<jlong>(ctx);
}

static void JNICALL n_hupdate(JNIEnv* env, jobject, jlong handle, jbyteArray chunk, jint len) {
    if (g_tampered.load(std::memory_order_acquire)) return;
    if (handle == 0 || chunk == nullptr || len <= 0) return;
    auto* ctx = reinterpret_cast<Sha256*>(handle);
    const jsize actual = env->GetArrayLength(chunk);
    if (len > actual) return;
    jbyte* elems = env->GetByteArrayElements(chunk, nullptr);
    if (!elems) return;
    ctx->update(reinterpret_cast<const uint8_t*>(elems), static_cast<size_t>(len));
    env->ReleaseByteArrayElements(chunk, elems, JNI_ABORT);
}

static jbyteArray JNICALL n_hfinal(JNIEnv* env, jobject, jlong handle) {
    if (handle == 0) return nullptr;
    auto* ctx = reinterpret_cast<Sha256*>(handle);
    uint8_t digest[32];
    ctx->final(digest);
    secureZero(ctx, sizeof(Sha256));
    delete ctx;
    jbyteArray result = env->NewByteArray(32);
    if (!result) { secureZero(digest, sizeof(digest)); return nullptr; }
    env->SetByteArrayRegion(result, 0, 32, reinterpret_cast<const jbyte*>(digest));
    secureZero(digest, sizeof(digest));
    return result;
}

static jstring JNICALL n_signal(JNIEnv* env, jobject, jbyteArray certHash, jbyteArray apkHash, jstring deviceId, jstring nonce) {
    ensure_watchdog();
    if (g_tampered.load(std::memory_order_acquire)) enforce("sig_tamper");
    static const char* encodedSecretHex = GUSTAXY_INTEGRITY_SECRET_XOR_HEX;
    const size_t encodedSecretLen = std::strlen(encodedSecretHex);
    if (encodedSecretLen == 0 || certHash == nullptr || apkHash == nullptr || deviceId == nullptr || nonce == nullptr) {
        return env->NewStringUTF("");
    }
    uint8_t secretBytes[128];
    const size_t secretLen = hexDecode(encodedSecretHex, encodedSecretLen, secretBytes, sizeof(secretBytes));
    if (secretLen == 0) { secureZero(secretBytes, sizeof(secretBytes)); return env->NewStringUTF(""); }
    decodeSecretInPlace(secretBytes, secretLen);

    jsize certLen = env->GetArrayLength(certHash);
    jbyte* certElems = env->GetByteArrayElements(certHash, nullptr);
    jsize apkLen = env->GetArrayLength(apkHash);
    jbyte* apkElems = env->GetByteArrayElements(apkHash, nullptr);
    const char* deviceChars = env->GetStringUTFChars(deviceId, nullptr);
    const char* nonceChars = env->GetStringUTFChars(nonce, nullptr);

    std::string payload;
    payload.reserve(static_cast<size_t>(certLen + apkLen) * 2 + 256);
    if (certElems) payload += hexEncodeUpper(reinterpret_cast<const uint8_t*>(certElems), static_cast<size_t>(certLen));
    payload += "|";
    if (apkElems) payload += hexEncodeUpper(reinterpret_cast<const uint8_t*>(apkElems), static_cast<size_t>(apkLen));
    payload += "|";
    if (deviceChars) payload += deviceChars;
    payload += "|";
    if (nonceChars) payload += nonceChars;
    // Atrela o sinal à compilação exata (rebuild = sinal diferente).
    payload += "|";
    payload += GUSTAXY_BUILD_FINGERPRINT;

    uint8_t signature[32];
    hmac_sha256(secretBytes, secretLen, reinterpret_cast<const uint8_t*>(payload.data()), payload.size(), signature);
    const std::string signalHex = hexEncodeLower(signature, sizeof(signature));

    secureZero(secretBytes, sizeof(secretBytes));
    secureZero(signature, sizeof(signature));
    if (certElems) env->ReleaseByteArrayElements(certHash, certElems, JNI_ABORT);
    if (apkElems) env->ReleaseByteArrayElements(apkHash, apkElems, JNI_ABORT);
    if (deviceChars) env->ReleaseStringUTFChars(deviceId, deviceChars);
    if (nonceChars) env->ReleaseStringUTFChars(nonce, nonceChars);
    return env->NewStringUTF(signalHex.c_str());
}

static jboolean JNICALL n_seq(JNIEnv* env, jobject, jstring a, jstring b) {
    if (!a || !b) return JNI_FALSE;
    const char* ca = env->GetStringUTFChars(a, nullptr);
    const char* cb = env->GetStringUTFChars(b, nullptr);
    jboolean result = JNI_FALSE;
    if (ca && cb) {
        const size_t la = std::strlen(ca), lb = std::strlen(cb);
        if (la == lb) {
            unsigned char diff = 0;
            for (size_t i = 0; i < la; ++i) diff = static_cast<unsigned char>(diff | (static_cast<unsigned char>(ca[i]) ^ static_cast<unsigned char>(cb[i])));
            result = (diff == 0) ? JNI_TRUE : JNI_FALSE;
        }
    }
    if (ca) env->ReleaseStringUTFChars(a, ca);
    if (cb) env->ReleaseStringUTFChars(b, cb);
    return result;
}

static jboolean JNICALL n_dbg(JNIEnv*, jobject) {
    ensure_watchdog();
    const bool a = check_debug_a();
    const bool b = check_debug_b();
    if (a != b) { g_violations.fetch_add(1, std::memory_order_relaxed); }
    return (a || b) ? JNI_TRUE : JNI_FALSE;
}

static jboolean JNICALL n_frida(JNIEnv*, jobject) {
    ensure_watchdog();
    const bool f = frida_detected();
    const bool i = injection_detected();
    return (f || i) ? JNI_TRUE : JNI_FALSE;
}

static jboolean JNICALL n_emu(JNIEnv*, jobject) {
    return emulator_detected() ? JNI_TRUE : JNI_FALSE;
}

static jstring JNICALL n_host(JNIEnv* env, jobject) {
    ensure_watchdog();
    if (g_tampered.load(std::memory_order_acquire)) enforce("host_tamper");
    char host[64];
    build_fallback_host(host, sizeof(host));
    jstring out = env->NewStringUTF(host);
    secureZero(host, sizeof(host));
    return out;
}

static jstring JNICALL n_primary(JNIEnv* env, jobject) {
    ensure_watchdog();
    if (g_tampered.load(std::memory_order_acquire)) enforce("primary_tamper");
    if (!watchdog_alive()) enforce("watchdog");
    char url[80];
    build_primary_host(url, sizeof(url));
    jstring out = env->NewStringUTF(url);
    secureZero(url, sizeof(url));
    return out;
}

static jint JNICALL n_checkpoint(JNIEnv*, jobject) {
    ensure_watchdog();
    jint flags = 0;
    if (check_debug_a() || check_debug_b()) flags |= 1;
    if (frida_detected()) flags |= 2;
    if (injection_detected()) flags |= 4;
    if (emulator_detected()) flags |= 8;
    if (!elf_header_sane()) flags |= 16;
    if (!watchdog_alive()) flags |= 32;
    if (g_tampered.load(std::memory_order_acquire)) flags |= 64;
    return flags;
}

static void JNICALL n_arm(JNIEnv*, jobject) {
    ensure_watchdog();
}

// ---------------------------------------------------------------------------
// Registro dinâmico.
// ---------------------------------------------------------------------------
static const JNINativeMethod kMethods[] = {
    {const_cast<char*>("nativeSha256"),            const_cast<char*>("([B)[B"),                                  reinterpret_cast<void*>(n_sha)},
    {const_cast<char*>("nativeHashInit"),          const_cast<char*>("()J"),                                     reinterpret_cast<void*>(n_hinit)},
    {const_cast<char*>("nativeHashUpdate"),        const_cast<char*>("(J[BI)V"),                                 reinterpret_cast<void*>(n_hupdate)},
    {const_cast<char*>("nativeHashFinal"),         const_cast<char*>("(J)[B"),                                   reinterpret_cast<void*>(n_hfinal)},
    {const_cast<char*>("nativeIntegritySignal"),   const_cast<char*>("([B[BLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;"), reinterpret_cast<void*>(n_signal)},
    {const_cast<char*>("nativeSecureEquals"),      const_cast<char*>("(Ljava/lang/String;Ljava/lang/String;)Z"), reinterpret_cast<void*>(n_seq)},
    {const_cast<char*>("nativeDebuggerAttached"),  const_cast<char*>("()Z"),                                     reinterpret_cast<void*>(n_dbg)},
    {const_cast<char*>("nativeFridaDetected"),     const_cast<char*>("()Z"),                                     reinterpret_cast<void*>(n_frida)},
    {const_cast<char*>("nativeEmulatorDetected"),  const_cast<char*>("()Z"),                                     reinterpret_cast<void*>(n_emu)},
    {const_cast<char*>("nativeFallbackHost"),      const_cast<char*>("()Ljava/lang/String;"),                    reinterpret_cast<void*>(n_host)},
    {const_cast<char*>("nativePrimaryUrl"),        const_cast<char*>("()Ljava/lang/String;"),                    reinterpret_cast<void*>(n_primary)},
    {const_cast<char*>("nativeCheckpoint"),        const_cast<char*>("()I"),                                     reinterpret_cast<void*>(n_checkpoint)},
    {const_cast<char*>("nativeArm"),               const_cast<char*>("()V"),                                     reinterpret_cast<void*>(n_arm)},
};

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) return JNI_ERR;

    // Classe alvo (mantida estável; o R8 a preserva via regra). O nome é
    // ofuscado para não constar em cleartext no .rodata da lib.
    GUSTA_STR(className, "com/gustaxy/android/security/NativeSecurity");
    jclass cls = env->FindClass(className);
    secureZero(className, sizeof(className));
    if (cls == nullptr) return JNI_ERR;

    if (env->RegisterNatives(cls, kMethods, sizeof(kMethods) / sizeof(kMethods[0])) != JNI_OK) {
        return JNI_ERR;
    }

    n_arm(env, nullptr);
    return JNI_VERSION_1_6;
}
