# ============================================================================
# ProGuard / R8 — perfil de blindagem máxima (release)
# ============================================================================

# --- JNI: métodos nativos são ligados via RegisterNatives, mas mantemos as
# declarações Kotlin estáveis para o registro dinâmico funcionar.
-keepclasseswithmembers,includedescriptorclasses class * {
    native <methods>;
}
-keep class com.gustaxy.android.security.NativeSecurity { *; }

-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*

-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}

# --- Ofuscação agressiva ---------------------------------------------------
# Empacota tudo num único pacote e permite alterar modificadores de acesso,
# quebrando a estrutura de pacotes original (dificulta navegação no JADX).
-repackageclasses ''
-allowaccessmodification
-flattenpackagehierarchy ''

# Renomeia com dicionário de caracteres confusos (iI1l0O) — dificulta leitura.
-obfuscationdictionary proguard-dict.txt
-classobfuscationdictionary proguard-dict.txt
-packageobfuscationdictionary proguard-dict.txt

# Renomeia arquivo-fonte e mantém números de linha (stack traces decifráveis
# só com o mapping.txt, que fica com você).
-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable

# Otimizações adicionais do R8.
-optimizationpasses 5
-mergeinterfacesaggressively

# --- Remoção TOTAL de logs em release (não só d/v/i) -----------------------
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
    public static *** wtf(...);
}

# Remove o LogManager próprio do app em release (chamadas viram no-op).
-assumenosideeffects class com.gustaxy.android.LogManager {
    public *** d(...);
    public *** i(...);
    public *** w(...);
    public *** e(...);
    public *** ok(...);
}

# --- Proteção das classes de segurança --------------------------------------
-keep class com.gustaxy.android.security.DeviceInfo { public *; }
-keep class com.gustaxy.android.security.SecureSessionStore { public *; }

# --- UserService do Shizuku -------------------------------------------------
-keep class com.gustaxy.android.security.ShellService { *; }
-keep class com.gustaxy.android.security.IShellService$* { *; }

# --- OkHttp / Okio -----------------------------------------------------------
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# --- Kotlin ------------------------------------------------------------------
-dontwarn kotlin.**
-dontwarn kotlinx.**

# Shizuku.
-dontwarn rikka.shizuku.**
