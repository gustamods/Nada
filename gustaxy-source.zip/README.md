# Gustaxy Android

Aplicativo Android em Jetpack Compose com `ReferenceSplashActivity` como launcher, seguido pelo fluxo existente de `LarkPlayerActivity` → `InicialActivity` → `LoginActivity`/`DashboardActivity`. **Esse fluxo de inicialização foi preservado deliberadamente.**

## Alterações desta revisão

- Splash da `InicialActivity` totalmente responsiva em telas estreitas, sem alterar a ordem de inicialização.
- Removido o texto visual `INICIALIZANDO SISTEMA`.
- `FloatingOverlayService` agora fornece `LifecycleOwner`/`SavedStateRegistryOwner` corretamente para o `ComposeView`, corrigindo o crash ao abrir o overlay.
- `LocalTrack` agora é `Parcelable`, corrigindo o uso de `rememberSaveable` no player.
- Overlay redesenhado com abas `Combate`, `Visual`, `Místico` e `Info`, mantendo as opções como estado local de interface e os atalhos para player/dashboard.
- Device binding reforçado com chave EC no Android Keystore + MediaDrm + ANDROID_ID, combinados por SHA-256. Nenhum desses identificadores é exposto nas abas do Dashboard.
- Detecção adicional de debugger, Frida, porta 27042, emulador e root no `NativeSecurity`.
- Segredo de integridade nativo passa a ser enviado ao C++ em forma XOR-encoded em build time e decodificado somente durante o uso.
- URL de fallback fica montada a partir do C++ nativo, não como host literal no DEX.
- `ApiClient` usa OkHttp e aceita certificate pinning configurado por build, sem colocar pins reais no repositório.
- `FLAG_SECURE` no Dashboard e `excludeFromRecents` para Login/Dashboard.
- Regras ProGuard passam a eliminar logs `d/v/i` em release.
- Shizuku 13.1.5 configurado com provider e solicitação de permissão na aba Início; **nenhum comando Shizuku é executado** nesta revisão. A API 13.1.5 é publicada no Maven Central e o guia oficial recomenda `ShizukuProvider` no Manifest para entregar o binder à aplicação.

## Configuração de build

O workflow/build pode fornecer:

- `GUSTAXY_API_BASE_URL`
- `GUSTAXY_CERT_SHA256`
- `GUSTAXY_APK_SHA256`
- `GUSTAXY_INTEGRITY_SECRET`
- `GUSTAXY_TLS_PINS`
- `GUSTAXY_KEYSTORE_PATH`
- `GUSTAXY_KEYSTORE_PASSWORD`
- `GUSTAXY_KEY_ALIAS`
- `GUSTAXY_KEY_PASSWORD`

### TLS pins

`GUSTAXY_TLS_PINS` usa o formato:

```text
host=sha256/BASE64PIN|sha256/SEGUNDOPIN,outro-host=sha256/BASE64PIN
```

Os pins devem corresponder às chaves públicas realmente utilizadas pelos hosts de produção. Esta revisão **não inventa hash de certificado** e, portanto, não embute um pin fictício que poderia quebrar o release.

### Segredo de integridade

`GUSTAXY_INTEGRITY_SECRET` continua sendo um secret do CI. O Gradle aplica a máscara de ofuscação antes de repassar os bytes ao CMake; a `libgusta.so` faz o XOR reverso em runtime. Isso reduz a exposição por busca direta de strings, mas não deve ser tratado como proteção criptográfica absoluta contra engenharia reversa nativa.

### Observação sobre Play Integrity / attestation server-side

Play Integrity e validação completa de Android Keystore Attestation exigem mudanças coordenadas no backend. O backend não está presente neste ZIP, portanto esta revisão não finge implementar uma validação server-side que não pode ser verificada aqui.
