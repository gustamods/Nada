# Gustaxy — Blindagem Total (Android + Servidor)

Data: 2026-09-13

Este pacote contém o projeto Android e o site servidor com o sistema de segurança completamente reescrito. Resumo do que mudou e o que você precisa fazer para colocar em produção.

---

## 1. O que foi implementado (10 frentes)

### Núcleo nativo (C++)
1. **Ofuscação de strings em compile-time** (`gusta_obf.hpp`): cada literal sensível (URL do servidor, assinaturas de Frida/Xposed, paths de emulador, nome da classe JNI) é transformada em array ofuscado com XOR multi-byte + rotação por posição. Nenhuma string aparece no `.rodata` — verificado com `strings` no binário compilado.
2. **Anti-debug ativo + redundante**: `ptrace(PTRACE_TRACEME)` defensivo (impede anexação posterior) + leitura de `TracerPid` por **syscall direta** (imune a hooks em libc) por **duas vias independentes**. O pai legítimo (zygote) é tratado como tracer permitido — sem falsos positivos.
3. **Anti-Frida/anti-injeção**: varredura de `/proc/self/maps` por 14 assinaturas ofuscadas (frida-agent, gadget, gum-js-loop, xposed, lsposed, zygisk, riru, substrate, magisk...), com leitura via `openat/read` por syscall.
4. **Anti-emulador**: 7 paths ofuscados + análise de `/proc/tty/drivers` com keywords ofuscadas.
5. **Anti-tamper da .so**: validação do ELF header em memória (detecta patch/sobrescrita) + sinal de integridade atrelado ao fingerprint da compilação (`GUSTAXY_BUILD_FINGERPRINT` — rebuild = sinal diferente).
6. **Watchdog nativo paranoico**: thread própria, intervalo aleatório 15–45s, ordem de checagens aleatória, heartbeat por **timestamp** — se a thread for congelada/suspensa, o silêncio é detectado em qualquer checkpoint.
7. **URL do servidor dinâmica**: host primário e fallback montados em runtime a partir de **6 shards ofuscados cada**, com seeds distintos por shard. A URL completa nunca existe no binário e vive na memória por microssegundos (buffers zerados com `secureZero`).
8. **JNI hardening**: registro via `RegisterNatives` com nome de classe ofuscado; apenas `JNI_OnLoad` exportado (`-fvisibility=hidden` + `--exclude-libs,ALL`).

### Camada Kotlin
9. **Quórum anti-bypass**: nenhum ponto único de decisão. `inspect()` (splash), `quickCheckpoint()` (antes de cada request HTTP, no dashboard, no login) e o watchdog do Dashboard (intervalo aleatório 18–42s) são três camadas independentes que se cobrem.
10. **Enforcement híbrido** (como você pediu): 1ª detecção → app **fecha silenciosamente** (sem toast/log/crash óbvio); persistência → o próximo login entrega `integrity_flags` ao servidor, que **bane o device_id** permanentemente.

### Servidor (PHP)
- **`DeviceBan`**: tabela `device_bans` + avaliação automática no login (`integrity_flags != 0` → ban). Painel em **Admin → Segurança** lista bans ativos com motivo/flags e permite desbanir.
- **Tokens de devices banidos** são recusados mesmo antes de expirar.

### Bugs corrigidos
- **Ícone de manutenção**: o serviço de overlay agora baixa o ícone escolhido no admin (validação de host allowlist + cache em disco por hash da URL), usa como `LargeIcon` da notificação e como selo no painel flutuante. Um broadcast (`ACTION_REFRESH_ICON`) atualiza o serviço em execução sem reiniciar — disparado automaticamente ao ativar o overlay.
- **"Key já foi usada" após reinstalar**: o `deviceId` agora prioriza **MediaDrm/Widevine** (estável entre reinstalações, só muda na formatação) + ANDROID_ID + fingerprint persistido; o Keystore EC deixou de ser âncora (ele morre na desinstalação). No servidor, se o hash mudou mas é o **mesmo aparelho na mesma key** (`stable_name_hash`), o slot do device é **readotado** (tokens antigos revogados) em vez de cobrar um novo dispositivo.

---

## 2. Deploy — passos obrigatórios

### Servidor (faça primeiro)
1. Suba os arquivos do site por cima dos atuais.
2. Rode a migration no banco de produção:
   - MySQL: `mysql -u USER -p BANCO < database/migration_device_bans.sql`
   - SQLite: o `sqlite.sql` já contém as tabelas novas para instalações novas; para banco existente, execute os comandos SQLite comentados no final de `migration_device_bans.sql`.
3. Confirme que `EXPECTED_CERT_SHA256` no `config/env.php` continua com o hash do seu certificado de release (recomendado — rejeita APK repackado no servidor).

### Android
1. Abra o projeto no Android Studio (ou Gradle) e gere o **release assinado** com as mesmas variáveis de ambiente de antes:
   - `GUSTAXY_INTEGRITY_SECRET`, `GUSTAXY_CERT_SHA256`, `GUSTAXY_APK_SHA256`, `GUSTAXY_TLS_PINS`, keystore (`GUSTAXY_KEYSTORE_PATH` etc.).
   - `GUSTAXY_API_BASE_URL` não é mais necessária em release (a URL vem do nativo); só use em debug local.
2. **Importante**: o `GUSTAXY_APK_SHA256` muda a cada build — atualize a env e, se usar no servidor, o `EXPECTED_CERT_SHA256` é o que vale (o certificado não muda entre builds assinados pela mesma chave).
3. Guarde o `app/build/outputs/mapping/release/mapping.txt` — só ele decifra os stack traces ofuscados.

### Verificação rápida pós-deploy
- Login normal em aparelho limpo: deve funcionar.
- Desinstalar → reinstalar → mesma key: deve entrar (device readotado, sem "limite atingido").
- Ativar manutenção no admin com imagem → abrir overlay: ícone aparece na notificação e no selo do painel.
- (Teste controlado) Rodar o app com Frida anexado: o app fecha silenciosamente; na tentativa seguinte de login o servidor registra o ban em Admin → Segurança.

---

## 3. Limites honestos
Nenhuma proteção client-side é "100% inquebrável" contra um atacante com root + tempo infinito; o que este sistema faz é elevar o custo ao ponto de exigir engenharia reversa profunda e persistente — e, mesmo assim, o banimento server-side fecha a porta. A autoridade final continua sendo o servidor: o app nunca confia em si mesmo para decisões de acesso.
