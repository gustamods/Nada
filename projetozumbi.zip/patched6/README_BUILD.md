# GSTX libloadgame.so - revisão de carregamento

Esta revisão foca o caminho de inicialização e integração nativa. Preservou-se o layout do menu, controles e nomes de função visíveis. Alterações principais:

- Hook de EGL ganha contexto ImGui próprio e thread fixa; o antigo compartilhamento com outro overlay poderia ser causa de SIGSEGV na primeira apresentação do jogo.
- Trampolines são páginas RWX obtidas por mmap sob demanda; o pool global de 256 slots marcado executável no construtor foi removido para eliminar essa fonte de +X na mprotect inicial.
- A64HookFunction só patcha se existir um relay a menos de 128 MiB do destino; sem relay próximo, o detour é recusado em vez de corromper os primeiros 20 bytes do método original.
- Gameplay deixou de ler layouts de List<T>/arrays; o novo bridge usa `il2cpp_runtime_invoke` para `get_Count`/`get_Item` e GCHandles para prolongar vida de referências entre chamadas.
- Input e todas as chamadas IL2CPP acontecem apenas na thread principal da Unity (hook em `EventSystem.Update` com fallback para `GameStateComponent.Update`); a thread de EGL só lê um snapshot já capturado.
- Build-script tem apenas as fontes efetivamente usadas: ImGui + backend OpenGL3 + ZygModule. Fontes Vulkan/KittyMemory/xDL do pacote antigo foram removidos do delivery para evitar confusão.

## Compilar

Requer NDK r23c:

```bash
cd build
$NDK/ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk APP_ABI=arm64-v8a
```

O artefato fica em `build/libs/arm64-v8a/libloadgame.so`. Mesmo nome do carregamento atual, para não quebrar o seu loader.

## O que NÃO foi feito

- Não houve execução no aparelho/jogo nesta rodada.
- Sem tombstone/logcat do crash original, não dá para afirmar qual das causas descartadas acima era a específica — a correção aborda as mais prováveis em conjunto.
- Nenhum APK/APKS foi assinado ou reempacotado.
- Nenhuma proteção anti-cheat é contornada aqui.
