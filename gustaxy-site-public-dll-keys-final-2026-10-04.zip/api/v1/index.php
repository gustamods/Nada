<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/config/bootstrap.php';
require dirname(__DIR__, 2) . '/app/Settings.php';
require dirname(__DIR__, 2) . '/app/KeyService.php';
require dirname(__DIR__, 2) . '/app/Blacklist.php';
require dirname(__DIR__, 2) . '/app/Api.php';
require dirname(__DIR__, 2) . '/app/UpdateService.php';
require dirname(__DIR__, 2) . '/app/ResourceVaultService.php';
require dirname(__DIR__, 2) . '/app/IntegrationTokenService.php';

// CORS é opt-in: só responde com Access-Control-Allow-Origin quando CORS_ORIGIN
// está configurado e bate exatamente com a Origin da requisição. Nunca usa '*'.
// O app Android não passa por CORS (isso só afeta chamadas feitas do navegador).
$allowedOrigin = trim((string) cfg('CORS_ORIGIN', ''));
$requestOrigin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
if ($allowedOrigin !== '' && $requestOrigin !== '' && $allowedOrigin === $requestOrigin) {
    header('Access-Control-Allow-Origin: ' . $requestOrigin);
    header('Vary: Origin');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Authorization, Content-Type');
    header('Access-Control-Max-Age: 600');
}
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/', '/');
$input = json_input();
if ($path === 'api/v1/update') {
    method('GET');
    Api::update($_GET);
}
if ($path === 'api/v1/config') {
    method('GET');
    Api::config();
}
if ($path === 'api/v1/auth/login') {
    method('POST');
    Api::login($input);
}
if ($path === 'api/v1/integrity/report') {
    method('POST');
    Api::integrityReport($input);
}
if ($path === 'api/v1/auth/me') {
    method('GET');
    Api::current();
}
if ($path === 'api/v1/auth/logout') {
    method('POST');
    Api::logout();
}
if ($path === 'api/v1/resources/manifest') {
    method('GET');
    Api::resourceManifest();
}
if ($path === 'api/v1/resources/download') {
    method('GET');
    Api::resourceDownload($_GET);
}
if ($path === 'api/v1/integration/status') {
    method('GET');
    Api::integrationStatus();
}
if ($path === 'api/v1/integration/keys/generate') {
    method('POST');
    Api::integrationKeysGenerate($input);
}
if ($path === 'api/v1/integration/keys/list') {
    method('GET');
    Api::integrationKeysList();
}
if ($path === 'api/v1/integration/keys/pause') {
    method('POST');
    Api::integrationKeyAction($input, 'pause', 'keys.manage');
}
if ($path === 'api/v1/integration/keys/resume') {
    method('POST');
    Api::integrationKeyAction($input, 'resume', 'keys.manage');
}
if ($path === 'api/v1/integration/keys/revoke') {
    method('POST');
    Api::integrationKeyAction($input, 'revoke', 'keys.manage');
}
if ($path === 'api/v1/integration/keys/reset-device') {
    method('POST');
    Api::integrationKeyAction($input, 'reset_device', 'keys.manage');
}
if ($path === 'api/v1/integration/keys/reset') {
    method('POST');
    Api::integrationKeyAction($input, 'reset_key', 'keys.manage');
}
if ($path === 'api/v1/integration/keys/delete') {
    method('POST');
    Api::integrationKeyAction($input, 'delete_key', 'keys.manage');
}
if ($path === 'api/v1/integration/keys/global-pause') {
    method('POST');
    Api::integrationGlobalKeys($input, true);
}
if ($path === 'api/v1/integration/keys/global-resume') {
    method('POST');
    Api::integrationGlobalKeys($input, false);
}
if ($path === 'api/v1/update/publish') {
    method('POST');
    Api::integrationUpdatePublish($input);
}
if ($path === 'api/v1/resources/publish') {
    method('POST');
    Api::integrationResourcePublish($input);
}
json_response(['error' => 'Endpoint não encontrado.'], 404);
