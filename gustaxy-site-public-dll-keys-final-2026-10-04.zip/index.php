<?php
declare(strict_types=1);
require __DIR__ . '/config/bootstrap.php';
require __DIR__ . '/app/PublicProductService.php';
require __DIR__ . '/app/PublicLayout.php';

$products = PublicProductService::listActive(4);
public_header('Início', 'inicio');
?>
<?php if ($products): ?>
<section class="product-grid" aria-label="Produtos">
<?php foreach ($products as $product): public_render_card($product); endforeach; ?>
</section>
<?php endif; ?>
<?php public_footer(); ?>
