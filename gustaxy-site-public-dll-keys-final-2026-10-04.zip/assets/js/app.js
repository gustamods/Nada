(function () {
  try {
    if (localStorage.getItem('gustaxy-theme') === 'light') {
      document.documentElement.setAttribute('data-theme', 'light');
    }
    var accent = localStorage.getItem('gustaxy-accent');
    if (accent) {
      document.documentElement.style.setProperty('--accent', accent);
    }
  } catch (e) {}
})();

var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

var confirmBypass = null;

document.addEventListener('click', function (event) {
  var confirmTarget = event.target.closest('[data-confirm]');
  if (confirmTarget) {
    if (confirmBypass === confirmTarget) {
      confirmBypass = null;
    } else {
      event.preventDefault();
      openConfirm(confirmTarget);
      return;
    }
  }

  var copyTarget = event.target.closest('[data-copy]');
  if (copyTarget) {
    var value = copyTarget.getAttribute('data-copy') || '';
    if (value === '') {
      showToast('Nada para copiar', 'error');
    } else {
      copyToClipboard(value).then(function (ok) {
        showToast(ok ? 'Copiado' : 'Não foi possível copiar', ok ? '' : 'error');
      });
    }
  }

  var toggle = event.target.closest('[data-nav-toggle]');
  var overlay = event.target.closest('[data-nav-overlay]');
  var navLink = event.target.closest('[data-sidebar] a');
  if (toggle) {
    setNavOpen(!document.body.classList.contains('nav-open'));
  } else if (overlay) {
    setNavOpen(false);
  } else if (navLink && window.matchMedia('(max-width: 959px)').matches) {
    setNavOpen(false);
  }
});

document.addEventListener('keydown', function (event) {
  if (event.key === 'Escape') {
    setNavOpen(false);
  }
});

function setNavOpen(open) {
  document.body.classList.toggle('nav-open', open);
  var toggle = document.querySelector('[data-nav-toggle]');
  if (toggle) {
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
}

function copyToClipboard(value) {
  var fallback = function () {
    var ok = false;
    var previous = document.activeElement;
    var area = document.createElement('textarea');
    area.value = value;
    area.setAttribute('readonly', '');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.focus();
    area.select();
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    area.remove();
    if (previous && typeof previous.focus === 'function') { previous.focus(); }
    return ok;
  };
  if (navigator.clipboard && window.isSecureContext) {
    return navigator.clipboard.writeText(value).then(
      function () { return true; },
      function () { return fallback(); }
    );
  }
  return Promise.resolve(fallback());
}

function openConfirm(trigger) {
  var message = trigger.getAttribute('data-confirm') || '';
  var title = trigger.getAttribute('data-confirm-title') || 'Confirmar ação';
  var subject = trigger.getAttribute('data-confirm-target') || '';
  var okLabel = trigger.getAttribute('data-confirm-ok') || 'Confirmar';
  var danger = trigger.classList.contains('danger');
  var previousFocus = document.activeElement;

  var backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';

  var dialog = document.createElement('div');
  dialog.className = 'modal';
  dialog.setAttribute('role', 'alertdialog');
  dialog.setAttribute('aria-modal', 'true');
  dialog.setAttribute('aria-labelledby', 'modal-title');
  dialog.setAttribute('aria-describedby', 'modal-message');

  var heading = document.createElement('h2');
  heading.id = 'modal-title';
  heading.textContent = title;
  dialog.appendChild(heading);

  var text = document.createElement('p');
  text.id = 'modal-message';
  text.textContent = message;
  dialog.appendChild(text);

  if (subject) {
    var code = document.createElement('code');
    code.className = 'modal-subject break-all';
    code.textContent = subject;
    dialog.appendChild(code);
  }

  var actions = document.createElement('div');
  actions.className = 'modal-actions';
  var cancel = document.createElement('button');
  cancel.type = 'button';
  cancel.className = 'btn';
  cancel.textContent = 'Cancelar';
  var ok = document.createElement('button');
  ok.type = 'button';
  ok.className = 'btn ' + (danger ? 'danger-solid' : 'primary');
  ok.textContent = okLabel;
  actions.appendChild(cancel);
  actions.appendChild(ok);
  dialog.appendChild(actions);
  backdrop.appendChild(dialog);

  function close(confirmed) {
    document.removeEventListener('keydown', onKey, true);
    backdrop.remove();
    document.body.classList.remove('modal-open');
    if (confirmed) {
      confirmBypass = trigger;
      trigger.click();
      return;
    }
    if (previousFocus && typeof previousFocus.focus === 'function') { previousFocus.focus(); }
  }

  function onKey(event) {
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      close(false);
    } else if (event.key === 'Tab') {
      var first = cancel;
      var last = ok;
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      } else if (document.activeElement !== first && document.activeElement !== last) {
        event.preventDefault();
        first.focus();
      }
    }
  }

  cancel.addEventListener('click', function () { close(false); });
  ok.addEventListener('click', function () { close(true); });
  backdrop.addEventListener('mousedown', function (event) {
    if (event.target === backdrop) { close(false); }
  });
  document.addEventListener('keydown', onKey, true);
  document.body.appendChild(backdrop);
  document.body.classList.add('modal-open');
  cancel.focus();
}

(function () {
  var proof = document.getElementById('js_proof');
  if (proof) {
    proof.value = navigator.webdriver === true ? 'webdriver' : '1';
  }
})();

(function () {
  var root = document.documentElement;

  var themeBtn = document.getElementById('theme-toggle');
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var isLight = root.getAttribute('data-theme') === 'light';
      if (isLight) {
        root.removeAttribute('data-theme');
        try { localStorage.setItem('gustaxy-theme', 'dark'); } catch (e) {}
      } else {
        root.setAttribute('data-theme', 'light');
        try { localStorage.setItem('gustaxy-theme', 'light'); } catch (e) {}
      }
    });
  }

  var accentBtn = document.getElementById('accent-picker');
  if (accentBtn && window.Pickr) {
    var current = getComputedStyle(root).getPropertyValue('--accent').trim() || '#d21334';
    var pickr = window.Pickr.create({
      el: accentBtn,
      theme: 'nano',
      useAsButton: true,
      default: current,
      position: 'bottom-end',
      components: {
        preview: true,
        opacity: false,
        hue: true,
        interaction: { hex: true, input: true, save: true, clear: false, cancel: false }
      }
    });
    pickr.on('save', function (color) {
      var hex = color.toHEXA().toString();
      root.style.setProperty('--accent', hex);
      try { localStorage.setItem('gustaxy-accent', hex); } catch (e) {}
      pickr.hide();
    });
  }
})();

function showToast(message, kind) {
  var stack = document.querySelector('.toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    stack.setAttribute('role', 'status');
    stack.setAttribute('aria-live', 'polite');
    document.body.appendChild(stack);
  }
  var toast = document.createElement('div');
  toast.className = 'toast' + (kind === 'error' ? ' error' : '');
  toast.textContent = message;
  stack.appendChild(toast);
  window.setTimeout(function () {
    toast.classList.add('leaving');
    window.setTimeout(function () { toast.remove(); }, 200);
  }, 1800);
}
window.showToast = showToast;

(function () {
  if (!('Intl' in window)) { return; }
  var fmt = new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  document.querySelectorAll('time.dt[data-ts]').forEach(function (el) {
    var ts = parseInt(el.getAttribute('data-ts'), 10);
    if (isNaN(ts)) { return; }
    var d = new Date(ts * 1000);
    if (isNaN(d.getTime())) { return; }
    el.textContent = fmt.format(d);
    el.setAttribute('title', el.textContent + ' (horário de Brasília)');
  });
})();

(function () {
  document.querySelectorAll('.metric').forEach(function (el) {
    var raw = el.textContent.trim();
    var target = parseInt(raw.replace(/[^\d-]/g, ''), 10);
    if (isNaN(target) || raw.indexOf('∞') !== -1 || String(target) !== raw.replace(/^0+(?=\d)/, '')) {
      return;
    }
    if (prefersReducedMotion) { return; }
    var duration = 700;
    var start = null;
    el.textContent = '0';
    function step(ts) {
      if (start === null) { start = ts; }
      var progress = Math.min((ts - start) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.round(eased * target).toString();
      if (progress < 1) {
        window.requestAnimationFrame(step);
      } else {
        el.textContent = String(target);
      }
    }
    window.requestAnimationFrame(step);
  });
})();

(function () {
  document.querySelectorAll('.reveal').forEach(function (el, i) {
    el.style.setProperty('--reveal-i', Math.min(i, 12));
  });
})();

(function () {
  if (prefersReducedMotion) { return; }
  document.querySelectorAll('details').forEach(function (details) {
    var summary = details.querySelector(':scope > summary');
    var panel = details.querySelector(':scope > .details-panel');
    if (!summary || !panel) { return; }
    var animating = false;

    summary.addEventListener('click', function (event) {
      if (animating) { event.preventDefault(); return; }
      event.preventDefault();
      animating = true;

      if (details.open) {
        var startHeight = panel.getBoundingClientRect().height;
        panel.style.height = startHeight + 'px';
        panel.offsetHeight;
        panel.style.height = '0px';
        panel.addEventListener('transitionend', function onEnd() {
          panel.removeEventListener('transitionend', onEnd);
          details.open = false;
          panel.style.height = '';
          animating = false;
        }, { once: true });
      } else {
        details.open = true;
        var endHeight = panel.getBoundingClientRect().height;
        panel.style.height = '0px';
        panel.offsetHeight;
        panel.style.height = endHeight + 'px';
        panel.addEventListener('transitionend', function onEnd() {
          panel.removeEventListener('transitionend', onEnd);
          panel.style.height = '';
          animating = false;
        }, { once: true });
      }
    });
  });
})();


(function () {
  var search = document.getElementById('keys-search');
  if (!search) { return; }
  var rows = Array.prototype.slice.call(document.querySelectorAll('[data-key-search]'));
  var chips = Array.prototype.slice.call(document.querySelectorAll('[data-key-filter]'));
  var empty = document.getElementById('keys-no-results');
  var status = 'all';
  var run = function () {
    var q = (search.value || '').trim().toLowerCase();
    var visible = 0;
    rows.forEach(function (row) {
      var textOk = !q || (row.getAttribute('data-key-search') || '').indexOf(q) !== -1;
      var statusOk = status === 'all' || row.getAttribute('data-key-status') === status;
      var match = textOk && statusOk;
      row.hidden = !match;
      if (match) { visible++; }
    });
    if (empty) { empty.hidden = visible !== 0; }
  };
  search.addEventListener('input', run);
  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      status = chip.getAttribute('data-key-filter') || 'all';
      chips.forEach(function (other) {
        other.setAttribute('aria-pressed', other === chip ? 'true' : 'false');
      });
      run();
    });
  });
})();

(function () {
  var form = document.getElementById('keys-bulk-form');
  if (!form) { return; }
  var master = document.getElementById('keys-select-all');
  var boxes = function () { return Array.prototype.slice.call(document.querySelectorAll('.key-select')); };
  var count = form.querySelector('[data-selected-count]');
  var buttons = Array.prototype.slice.call(form.querySelectorAll('[data-bulk-require], [data-bulk-confirm]'));
  function syncHidden(selected) {
    form.querySelectorAll('input[data-bulk-id]').forEach(function (node) { node.remove(); });
    selected.forEach(function (box) {
      var input = document.createElement('input');
      input.type = 'hidden';
      input.name = 'ids[]';
      input.value = box.value;
      input.setAttribute('data-bulk-id', '1');
      form.appendChild(input);
    });
  }
  function update() {
    var all = boxes();
    var selected = all.filter(function (box) { return box.checked; });
    if (count) { count.textContent = selected.length + (selected.length === 1 ? ' selecionada' : ' selecionadas'); }
    if (master) {
      master.checked = all.length > 0 && selected.length === all.length;
      master.indeterminate = selected.length > 0 && selected.length < all.length;
    }
    syncHidden(selected);
    buttons.forEach(function (button) {
      button.disabled = selected.length === 0;
    });
  }
  if (master) {
    master.addEventListener('change', function () {
      boxes().forEach(function (box) { box.checked = master.checked; });
      update();
    });
  }
  document.addEventListener('change', function (event) {
    if (event.target && event.target.classList && event.target.classList.contains('key-select')) { update(); }
  });
  form.addEventListener('submit', function (event) {
    var selected = boxes().filter(function (box) { return box.checked; });
    if (!selected.length) { event.preventDefault(); return; }
    var submitter = event.submitter;
    var message = submitter ? submitter.getAttribute('data-bulk-confirm') : '';
    if (message && !window.confirm(message)) { event.preventDefault(); }
  });
  update();
})();

(function () {
  var center = document.querySelector('[data-notification-center]');
  if (!center) return;
  var toggle = center.querySelector('[data-notification-toggle]');
  var panel = center.querySelector('[data-notification-panel]');
  var dot = center.querySelector('[data-notification-dot]');
  if (!toggle || !panel) return;

  var key = 'gustaxy-api-notifications-seen';
  var newest = '';
  var items = center.querySelectorAll('[data-notification-ts]');
  items.forEach(function (item) {
    var ts = item.getAttribute('data-notification-ts') || '';
    if (ts > newest) newest = ts;
  });
  var seen = '';
  try { seen = localStorage.getItem(key) || ''; } catch (e) {}
  if (dot && (!seen || newest > seen)) dot.hidden = false;
  else if (dot) dot.hidden = true;

  toggle.addEventListener('click', function (event) {
    event.stopPropagation();
    var open = !panel.hidden;
    panel.hidden = open;
    toggle.setAttribute('aria-expanded', open ? 'false' : 'true');
    if (!open && newest) {
      try { localStorage.setItem(key, newest); } catch (e) {}
      if (dot) dot.hidden = true;
    }
  });

  document.addEventListener('click', function (event) {
    if (!center.contains(event.target)) {
      panel.hidden = true;
      toggle.setAttribute('aria-expanded', 'false');
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && !panel.hidden) {
      panel.hidden = true;
      toggle.setAttribute('aria-expanded', 'false');
      toggle.focus();
    }
  });
})();

// Proteção contra clique/envio duplo: depois do envio, desabilita os botões do
// formulário e mostra um spinner no botão usado (o valor do botão já foi lido).
(function () {
  var timers = new WeakMap();

  function unlock(form) {
    form.removeAttribute('data-submitting');
    form.querySelectorAll('button, input[type="submit"]').forEach(function (btn) {
      btn.disabled = false;
      btn.classList.remove('is-loading');
    });
  }

  document.addEventListener('submit', function (event) {
    var form = event.target;
    if (!(form instanceof HTMLFormElement) || form.hasAttribute('data-no-lock')) { return; }
    if (form.getAttribute('data-submitting') === '1') {
      event.preventDefault();
      return;
    }
    if (event.defaultPrevented) { return; }
    var submitter = event.submitter || null;
    form.setAttribute('data-submitting', '1');
    window.setTimeout(function () {
      form.querySelectorAll('button, input[type="submit"]').forEach(function (btn) { btn.disabled = true; });
      if (submitter && submitter.classList) { submitter.classList.add('is-loading'); }
    }, 0);
    // Se a resposta for um download (a página não troca), libera de novo.
    timers.set(form, window.setTimeout(function () { unlock(form); }, 20000));
  });

  window.addEventListener('pageshow', function (event) {
    if (!event.persisted) { return; }
    document.querySelectorAll('form[data-submitting]').forEach(unlock);
  });
})();

// Campos de senha: botão mostrar/ocultar e aviso de Caps Lock.
(function () {
  var eyeOn = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>';
  var eyeOff = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.6 5.1A9.9 9.9 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4.1"/><path d="M6.6 6.6A17 17 0 0 0 2 12s3.6 7 10 7a9.7 9.7 0 0 0 4.4-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';

  document.querySelectorAll('input[type="password"]').forEach(function (input) {
    if (input.closest('.inline-form') || input.hasAttribute('data-no-toggle')) { return; }
    var wrap = document.createElement('span');
    wrap.className = 'pw-field';
    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);

    var toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'pw-toggle';
    toggle.setAttribute('aria-label', 'Mostrar senha');
    toggle.setAttribute('aria-pressed', 'false');
    toggle.innerHTML = eyeOn;
    wrap.appendChild(toggle);

    var hint = document.createElement('small');
    hint.className = 'caps-hint';
    hint.setAttribute('role', 'status');
    hint.hidden = true;
    hint.textContent = 'Caps Lock está ativado';
    wrap.parentNode.insertBefore(hint, wrap.nextSibling);

    toggle.addEventListener('click', function () {
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      toggle.setAttribute('aria-pressed', show ? 'true' : 'false');
      toggle.setAttribute('aria-label', show ? 'Ocultar senha' : 'Mostrar senha');
      toggle.innerHTML = show ? eyeOff : eyeOn;
      input.focus();
    });

    var caps = function (event) {
      if (typeof event.getModifierState === 'function') {
        hint.hidden = !event.getModifierState('CapsLock');
      }
    };
    input.addEventListener('keydown', caps);
    input.addEventListener('keyup', caps);
    input.addEventListener('blur', function () { hint.hidden = true; });
  });
})();

// 2FA: envia sozinho ao completar o 6º dígito.
(function () {
  document.querySelectorAll('form[data-autosubmit-code]').forEach(function (form) {
    var input = form.querySelector('input[name="code"]');
    if (!input) { return; }
    input.addEventListener('input', function () {
      var digits = input.value.replace(/\D/g, '').slice(0, 6);
      if (input.value !== digits) { input.value = digits; }
      if (digits.length === 6 && form.getAttribute('data-submitting') !== '1') {
        if (typeof form.requestSubmit === 'function') { form.requestSubmit(); } else { form.submit(); }
      }
    });
  });
})();

// Aviso de sessão: faltando 2 min para expirar, oferece renovar sem perder a página.
(function () {
  var body = document.body;
  var url = body.getAttribute('data-keepalive-url');
  var idle = parseInt(body.getAttribute('data-session-idle') || '', 10);
  if (!url || !idle) { return; }
  var abs = parseInt(body.getAttribute('data-session-abs') || '', 10);
  var meta = document.querySelector('meta[name="csrf-token"]');
  var csrf = meta ? (meta.getAttribute('content') || '') : '';
  var WARN_AT = 120;
  var idleEnd = Date.now() + idle * 1000;
  var absEnd = isNaN(abs) ? Infinity : Date.now() + abs * 1000;
  var banner = null;
  var textEl = null;
  var actionEl = null;
  var timer = null;
  var checking = false;
  var announced = false;
  var nextCheck = 0;

  function format(seconds) {
    var m = Math.floor(seconds / 60);
    var r = seconds % 60;
    return m + ':' + (r < 10 ? '0' : '') + r;
  }

  function build() {
    if (banner) { return; }
    banner = document.createElement('div');
    banner.className = 'session-banner';
    banner.setAttribute('role', 'group');
    banner.setAttribute('aria-label', 'Aviso de sessão');
    textEl = document.createElement('span');
    banner.appendChild(textEl);
    document.body.appendChild(banner);
  }

  function setAction(kind) {
    if (actionEl) { actionEl.remove(); actionEl = null; }
    if (kind === 'extend') {
      actionEl = document.createElement('button');
      actionEl.type = 'button';
      actionEl.className = 'btn compact primary';
      actionEl.textContent = 'Continuar logado';
      actionEl.addEventListener('click', function () { ping(false); });
    } else if (kind === 'login') {
      actionEl = document.createElement('a');
      actionEl.className = 'btn compact primary';
      actionEl.href = '/admin/login.php';
      actionEl.textContent = 'Entrar novamente';
    }
    if (actionEl) { banner.appendChild(actionEl); }
  }

  function hide() {
    if (banner) { banner.remove(); banner = null; textEl = null; actionEl = null; }
    announced = false;
  }

  function expired() {
    if (timer) { window.clearInterval(timer); timer = null; }
    build();
    textEl.textContent = 'Sua sessão expirou.';
    setAction('login');
  }

  function ping(silent) {
    if (actionEl && actionEl.tagName === 'BUTTON') { actionEl.disabled = true; }
    fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'X-CSRF-Token': csrf, 'Accept': 'application/json' }
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (data) {
        return { status: response.status, data: data };
      });
    }).then(function (result) {
      checking = false;
      if (result.status === 200 && result.data && result.data.ok) {
        idleEnd = Date.now() + (parseInt(result.data.idle, 10) || idle) * 1000;
        if (typeof result.data.abs_remaining === 'number') { absEnd = Date.now() + result.data.abs_remaining * 1000; }
        hide();
        if (!silent) { showToast('Sessão renovada'); }
      } else if (result.status === 401) {
        expired();
      } else {
        nextCheck = Date.now() + 10000;
        if (actionEl && actionEl.tagName === 'BUTTON') { actionEl.disabled = false; }
        if (!silent) { showToast('Não foi possível renovar a sessão', 'error'); }
      }
    }).catch(function () {
      checking = false;
      nextCheck = Date.now() + 10000;
      if (actionEl && actionEl.tagName === 'BUTTON') { actionEl.disabled = false; }
      if (!silent) { showToast('Sem conexão. Tente novamente.', 'error'); }
    });
  }

  function tick() {
    var left = Math.floor((Math.min(idleEnd, absEnd) - Date.now()) / 1000);
    if (left > WARN_AT) {
      if (banner) { hide(); }
      return;
    }
    if (left <= 0) {
      // Outra aba pode ter renovado: confere no servidor antes de dar como expirada.
      if (!checking && Date.now() >= nextCheck) { checking = true; ping(true); }
      return;
    }
    build();
    if (!announced) {
      announced = true;
      showToast('Sua sessão expira em 2 minutos');
    }
    var canExtend = idleEnd <= absEnd;
    textEl.textContent = canExtend
      ? 'Sua sessão expira em ' + format(left)
      : 'Sua sessão expira em ' + format(left) + '. Termine o que estiver fazendo.';
    if (canExtend && !actionEl) { setAction('extend'); }
  }

  timer = window.setInterval(tick, 1000);
})();
