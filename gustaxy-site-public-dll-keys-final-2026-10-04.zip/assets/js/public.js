(function(){
  var body=document.body;
  var menu=document.querySelector('[data-public-menu]');
  var close=document.querySelector('[data-public-close]');
  var backdrop=document.querySelector('[data-public-backdrop]');
  function setMenu(open){
    body.classList.toggle('public-menu-open',open);
    if(menu) menu.setAttribute('aria-expanded',open?'true':'false');
  }
  if(menu) menu.addEventListener('click',function(){setMenu(!body.classList.contains('public-menu-open'));});
  if(close) close.addEventListener('click',function(){setMenu(false);});
  if(backdrop) backdrop.addEventListener('click',function(){setMenu(false);});
  document.querySelectorAll('.public-nav a').forEach(function(a){a.addEventListener('click',function(){setMenu(false);});});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'){setMenu(false);}});

  var dialog=document.querySelector('[data-short-dialog]');
  var cancel=dialog?dialog.querySelector('[data-short-cancel]'):null;
  var proceed=dialog?dialog.querySelector('[data-short-continue]'):null;
  var pending='';
  function openDialog(url){
    pending=url||'';
    if(!dialog||!pending)return;
    dialog.hidden=false;
    document.documentElement.style.overflow='hidden';
    if(cancel)cancel.focus();
  }
  function closeDialog(){
    if(!dialog)return;
    dialog.hidden=true;
    document.documentElement.style.overflow='';
    pending='';
  }
  document.querySelectorAll('.product-download-short').forEach(function(btn){
    btn.addEventListener('click',function(){openDialog(btn.getAttribute('data-short-link')||'');});
  });
  if(cancel)cancel.addEventListener('click',closeDialog);
  if(proceed)proceed.addEventListener('click',function(){
    var url=pending;
    closeDialog();
    if(url)window.location.assign(url);
  });
  if(dialog)dialog.addEventListener('mousedown',function(e){if(e.target===dialog)closeDialog();});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&dialog&&!dialog.hidden)closeDialog();});
})();
