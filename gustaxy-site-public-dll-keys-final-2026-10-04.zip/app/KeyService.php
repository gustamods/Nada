<?php
declare(strict_types=1);

final class KeyService
{
    public static function fingerprint(string $rawKey): string
    {
        return hash_hmac('sha256', trim($rawKey), app_key());
    }

    public static function deviceHash(string $deviceId): string
    {
        return hash_hmac('sha256', trim($deviceId), app_key());
    }

    private static function cryptoKey(): string
    {
        return hash('sha256', app_key(), true);
    }

    public static function encryptKey(string $rawKey): string
    {
        $iv = random_bytes(12);
        $tag = '';
        $ciphertext = openssl_encrypt($rawKey, 'aes-256-gcm', self::cryptoKey(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($ciphertext === false || strlen($tag) !== 16) {
            throw new RuntimeException('Não foi possível proteger a key.');
        }
        return base64_encode($iv . $tag . $ciphertext);
    }

    public static function decryptKey(string $encoded): string
    {
        $payload = base64_decode($encoded, true);
        if ($payload === false || strlen($payload) < 29) {
            return '';
        }
        $iv = substr($payload, 0, 12);
        $tag = substr($payload, 12, 16);
        $ciphertext = substr($payload, 28);
        $plain = openssl_decrypt($ciphertext, 'aes-256-gcm', self::cryptoKey(), OPENSSL_RAW_DATA, $iv, $tag);
        return is_string($plain) ? $plain : '';
    }

    public static function expiresAt(int $amount, string $unit): string
    {
        $amount = max(1, min($amount, 8760));
        $allowed = ['hour' => 'hour', 'hours' => 'hour', 'day' => 'day', 'days' => 'day', 'week' => 'week', 'weeks' => 'week', 'month' => 'month', 'months' => 'month', 'year' => 'year', 'years' => 'year'];
        if (!isset($allowed[$unit])) {
            throw new InvalidArgumentException('Período inválido.');
        }
        $dt = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        return $dt->modify('+' . $amount . ' ' . $allowed[$unit])->format('Y-m-d H:i:s');
    }

    public static function normalizePrefix(string $prefix): string
    {
        $prefix = strtoupper(trim($prefix));
        $prefix = preg_replace('/[^A-Z0-9_-]+/', '-', $prefix) ?? '';
        $prefix = trim(substr($prefix, 0, 20), '-_');
        return $prefix !== '' ? $prefix : 'GUS';
    }

    public static function generate(int $quantity, int $maxDevices, int $amount, string $unit, int $actorId, string $prefix = ''): array
    {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $result = self::generateInTransaction($quantity, $maxDevices, $amount, $unit, $actorId, $prefix, null);
            $pdo->commit();
            audit('keys_generated', $actorId, 'api_key', null, ['quantity' => count($result['keys']), 'prefix' => $result['prefix'], 'max_devices' => $result['max_devices'], 'expires_at' => $result['expires_at'], 'started_paused' => $result['started_paused']]);
            return $result;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    public static function generateInTransaction(int $quantity, int $maxDevices, int $amount, string $unit, int $actorId, string $prefix = '', ?int $resellerId = null): array
    {
        $quantity = max(1, min($quantity, 500));
        $maxDevices = max(1, min($maxDevices, 50));
        $expires = self::expiresAt($amount, $unit);
        $prefix = self::normalizePrefix($prefix);
        $paused = class_exists('Settings') && Settings::keysPaused();
        $pdo = db();
        $stmt = $pdo->prepare('INSERT INTO api_keys (key_prefix, key_hash, key_ciphertext, max_devices, expires_at, status, created_by, reseller_id, created_at, pause_started_at) VALUES (?, ?, ?, ?, ?, \'active\', ?, ?, CURRENT_TIMESTAMP, ?)');
        $plain = [];
        $ids = [];
        for ($i = 0; $i < $quantity; $i++) {
            $raw = $prefix . '-' . strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(substr(b64url_encode(random_bytes(8)), 0, 10));
            $stmt->execute([
                substr($raw, 0, 24),
                self::fingerprint($raw),
                self::encryptKey($raw),
                $maxDevices,
                $expires,
                $actorId,
                $resellerId,
                $paused ? gmdate('Y-m-d H:i:s') : null,
            ]);
            $plain[] = $raw;
            $ids[] = (int) $pdo->lastInsertId();
        }
        return ['keys' => $plain, 'ids' => $ids, 'expires_at' => $expires, 'max_devices' => $maxDevices, 'prefix' => $prefix, 'started_paused' => $paused];
    }

    public static function pause(int $id, int $actorId): void
    {
        $stmt = db()->prepare("UPDATE api_keys SET status = 'paused', paused_at = COALESCE(paused_at, CURRENT_TIMESTAMP) WHERE id = ? AND status = 'active'");
        $stmt->execute([$id]);
        audit('key_paused', $actorId, 'api_key', (string) $id);
    }

    public static function resume(int $id, int $actorId): void
    {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT expires_at, paused_at FROM api_keys WHERE id = ? AND status = 'paused' LIMIT 1");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row) {
            return;
        }
        $expires = new DateTimeImmutable((string) $row['expires_at'], new DateTimeZone('UTC'));
        $pausedAt = !empty($row['paused_at']) ? new DateTimeImmutable((string) $row['paused_at'], new DateTimeZone('UTC')) : new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $seconds = max(0, time() - $pausedAt->getTimestamp());
        $newExpires = $expires->modify('+' . $seconds . ' seconds')->format('Y-m-d H:i:s');
        $pdo->prepare("UPDATE api_keys SET expires_at = ?, status = 'active', paused_at = NULL WHERE id = ?")->execute([$newExpires, $id]);
        audit('key_resumed', $actorId, 'api_key', (string) $id, ['paused_seconds' => $seconds]);
    }

    public static function revoke(int $id, int $actorId): void
    {
        $stmt = db()->prepare("UPDATE api_keys SET status = 'revoked', revoked_at = CURRENT_TIMESTAMP, paused_at = NULL, pause_started_at = NULL WHERE id = ? AND status <> 'revoked'");
        $stmt->execute([$id]);
        db()->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE api_key_id = ?')->execute([$id]);
        audit('key_revoked', $actorId, 'api_key', (string) $id);
    }

    public static function resetDevice(int $id, int $actorId): void
    {
        $deviceStmt = db()->prepare('SELECT api_key_id, device_id_hash FROM devices WHERE id = ? LIMIT 1');
        $deviceStmt->execute([$id]);
        $device = $deviceStmt->fetch();
        if (!$device) {
            throw new RuntimeException('Dispositivo não encontrado.');
        }
        db()->prepare('UPDATE devices SET revoked_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([$id]);
        db()->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE api_key_id = ? AND device_id_hash = ?')->execute([(int) $device['api_key_id'], (string) $device['device_id_hash']]);
        audit('device_reset', $actorId, 'device', (string) $id, ['api_key_id' => (int) $device['api_key_id']]);
    }

    public static function resetKey(int $id, int $actorId): void
    {
        db()->prepare('UPDATE devices SET revoked_at = CURRENT_TIMESTAMP WHERE api_key_id = ? AND revoked_at IS NULL')->execute([$id]);
        db()->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE api_key_id = ?')->execute([$id]);
        audit('key_devices_reset', $actorId, 'api_key', (string) $id);
    }

    public static function delete(int $id, int $actorId): void
    {
        if ($id < 1) {
            throw new InvalidArgumentException('Key inválida.');
        }
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT key_prefix FROM api_keys WHERE id = ? LIMIT 1');
            $stmt->execute([$id]);
            $key = $stmt->fetch();
            if (!$key) {
                throw new RuntimeException('Key não encontrada.');
            }
            $auditPrefix = (string) $key['key_prefix'];
            $pdo->prepare('DELETE FROM api_tokens WHERE api_key_id = ?')->execute([$id]);
            $pdo->prepare('DELETE FROM devices WHERE api_key_id = ?')->execute([$id]);
            $pdo->prepare('UPDATE login_logs SET api_key_id = NULL WHERE api_key_id = ?')->execute([$id]);
            $pdo->prepare('UPDATE device_security_events SET api_key_id = NULL WHERE api_key_id = ?')->execute([$id]);
            $delete = $pdo->prepare('DELETE FROM api_keys WHERE id = ?');
            $delete->execute([$id]);
            if ($delete->rowCount() !== 1) {
                throw new RuntimeException('A key não foi removida.');
            }
            audit('key_deleted', $actorId, 'api_key', (string) $id, ['key_prefix' => $auditPrefix]);
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }
}
