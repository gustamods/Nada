<?php
declare(strict_types=1);

final class UpdateService
{
    public static function active(): ?array
    {
        $stmt = db()->query("SELECT id, name, version, version_code, download_url, sha256, size_bytes, released_at, created_at FROM apk_releases WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function publish(
        string $name,
        string $version,
        int $versionCode,
        string $downloadUrl,
        string $sha256,
        ?int $sizeBytes,
        int $actorId
    ): int {
        $name = mb_substr(trim($name), 0, 120);
        $version = mb_substr(trim($version), 0, 32);
        $downloadUrl = trim($downloadUrl);
        $sha256 = strtoupper(trim($sha256));
        if ($name === '' || $version === '' || $versionCode < 1 || $versionCode > 2000000000) {
            throw new InvalidArgumentException('Nome, versão e código de versão são obrigatórios e devem ser válidos.');
        }
        if (!self::isSafeDownloadUrl($downloadUrl)) {
            throw new InvalidArgumentException('O link de download deve ser HTTPS e usar um host autorizado.');
        }
        if (!preg_match('/^[A-F0-9]{64}$/', $sha256)) {
            throw new InvalidArgumentException('Informe o SHA-256 do APK (64 caracteres hexadecimais).');
        }
        if ($sizeBytes !== null && ($sizeBytes < 1 || $sizeBytes > 500 * 1024 * 1024)) {
            throw new InvalidArgumentException('Tamanho do APK inválido.');
        }

        $pdo = db();
        $lockHeld = false;
        try {
            // Publicação é uma operação singleton: evita duas versões ativas
            // durante concorrência entre sessões administrativas.
            if ((string) cfg('DB_DRIVER', 'mysql') !== 'sqlite') {
                $lock = $pdo->query("SELECT GET_LOCK('gustaxy_apk_release_publish', 5)")->fetchColumn();
                if ((int) $lock !== 1) {
                    throw new RuntimeException('Não foi possível obter o bloqueio de publicação.');
                }
                $lockHeld = true;
            }

            $active = self::active();
            if ($active && $versionCode <= (int) $active['version_code']) {
                throw new InvalidArgumentException('A nova versão deve possuir versionCode maior que a versão ativa.');
            }

            $pdo->beginTransaction();
            $pdo->exec('UPDATE apk_releases SET is_active = 0 WHERE is_active = 1');
            $stmt = $pdo->prepare('INSERT INTO apk_releases (name, version, version_code, download_url, sha256, size_bytes, released_at, is_active, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 1, ?, CURRENT_TIMESTAMP)');
            $stmt->execute([$name, $version, $versionCode, $downloadUrl, $sha256, $sizeBytes, $actorId]);
            $id = (int) $pdo->lastInsertId();
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        } finally {
            if ($lockHeld) {
                try { $pdo->query("SELECT RELEASE_LOCK('gustaxy_apk_release_publish')"); } catch (Throwable) {}
            }
        }
        audit('apk_release_published', $actorId, 'apk_release', (string) $id, [
            'version' => $version,
            'version_code' => $versionCode,
            'sha256_prefix' => substr($sha256, 0, 16),
        ]);
        return $id;
    }

    public static function history(): array
    {
        return db()->query("SELECT r.id, r.name, r.version, r.version_code, r.download_url, r.sha256, r.size_bytes, r.released_at, r.is_active, r.created_at, COALESCE(u.username, 'Sistema') AS created_by_name FROM apk_releases r LEFT JOIN admin_users u ON u.id = r.created_by ORDER BY r.id DESC LIMIT 50")->fetchAll();
    }

    public static function isSafeDownloadUrl(string $url): bool
    {
        $parts = parse_url($url);
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https') {
            return false;
        }
        if (!empty($parts['user']) || !empty($parts['pass']) || !empty($parts['fragment'])) {
            return false;
        }
        $host = strtolower(trim((string) ($parts['host'] ?? '')));
        if ($host === '' || !preg_match('/^[a-z0-9.-]+$/', $host)) {
            return false;
        }
        $allowed = cfg('UPDATE_ALLOWED_HOSTS', []);
        if (is_string($allowed)) {
            $allowed = array_filter(array_map('trim', explode(',', $allowed)));
        }
        $allowed = array_map('strtolower', array_filter((array) $allowed, static fn($v) => is_string($v) && trim($v) !== ''));
        if ($allowed) {
            return in_array($host, $allowed, true);
        }
        $appHost = strtolower((string) parse_url((string) cfg('APP_URL', ''), PHP_URL_HOST));
        return $appHost !== '' && hash_equals($appHost, $host);
    }

    public static function publicPayload(?int $clientVersionCode = null): array
    {
        $release = self::active();
        if (!$release) {
            return ['available' => false, 'release' => null, 'minimum_required_version_code' => 0];
        }
        $versionCode = (int) $release['version_code'];
        $available = $clientVersionCode === null || $versionCode > $clientVersionCode;
        return [
            'available' => $available,
            'release' => [
                'name' => (string) $release['name'],
                'version' => (string) $release['version'],
                'version_code' => $versionCode,
                'download_url' => (string) $release['download_url'],
                'sha256' => (string) $release['sha256'],
                'size_bytes' => $release['size_bytes'] !== null ? (int) $release['size_bytes'] : null,
                'released_at' => (string) $release['released_at'],
            ],
            'minimum_required_version_code' => $versionCode,
        ];
    }
}
