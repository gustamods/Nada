<?php
declare(strict_types=1);

date_default_timezone_set('America/Sao_Paulo');

function public_e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function public_icon(string $name, string $class = 'public-icon'): string
{
    $stroke = 'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
    $icons = [
        'grid' => '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
        'home' => '<polyline points="4 11 12 4 20 11"/><rect x="6" y="11" width="12" height="9" rx="1"/><line x1="10" y1="20" x2="10" y2="15"/><line x1="14" y1="20" x2="14" y2="15"/>',
        'box' => '<path d="M4 7.5 12 3l8 4.5v9L12 21l-8-4.5z"/><path d="M4 7.5 12 12l8-4.5M12 12v9"/>',
        'key' => '<circle cx="8" cy="15" r="4"/><line x1="11" y1="12" x2="20" y2="3"/><line x1="16" y1="7" x2="19" y2="10"/><line x1="13" y1="10" x2="16" y2="13"/>',
        'book' => '<path d="M5 4h11a3 3 0 0 1 3 3v12H8a3 3 0 0 1-3-3z"/><path d="M8 4v15"/><path d="M5 16h14"/>',
        'download' => '<path d="M12 3v11"/><polyline points="8 10 12 14 16 10"/><path d="M5 19h14"/>',
        'arrow' => '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/>',
        'menu' => '<line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/>',
        'x' => '<line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/>',
    ];
    return '<svg class="' . public_e($class) . '" viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true">' . ($icons[$name] ?? '') . '</svg>';
}

function public_asset_version(string $relative): string
{
    $path = GUSTAXY_ROOT . $relative;
    $hash = is_file($path) ? substr((string) md5_file($path), 0, 10) : '';
    return $hash !== '' ? $hash : '1';
}

function public_platform_label(string $platform): string
{
    return match ($platform) {
        'iphone' => 'iPhone',
        'pc' => 'PC',
        default => 'Android',
    };
}

function public_render_card(array $item): void
{
    $type = (string) ($item['download_type'] ?? 'direct');
    $url = (string) ($item['download_url'] ?? '');
    $platform = (string) ($item['platform'] ?? 'android');
    ?>
<article class="product-card">
    <div class="product-thumb-wrap">
        <img class="product-thumb" src="<?= public_e((string) $item['thumb_url']) ?>" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer">
    </div>
    <div class="product-body">
        <div class="product-meta">
            <span><?= public_e(public_platform_label($platform)) ?></span>
            <?php if (trim((string) ($item['apk_version'] ?? '')) !== ''): ?><span>v<?= public_e((string) $item['apk_version']) ?></span><?php endif; ?>
        </div>
        <h2><?= public_e((string) $item['title']) ?></h2>
        <?php if (trim((string) ($item['description'] ?? '')) !== ''): ?><p><?= nl2br(public_e((string) $item['description'])) ?></p><?php endif; ?>
        <?php if ($type === 'shortened'): ?>
            <button type="button" class="product-download product-download-short" data-short-link="<?= public_e($url) ?>"><?= public_icon('download') ?> Download</button>
        <?php else: ?>
            <a class="product-download" href="<?= public_e($url) ?>" rel="noopener noreferrer" referrerpolicy="no-referrer"><?= public_icon('download') ?> Download</a>
        <?php endif; ?>
    </div>
</article>
<?php
}

function public_header(string $active, string $title): void
{
    $brand = '/assets/img/logo_gstx_proxy.png';
    ?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#050505">
<meta name="robots" content="index,follow">
<title><?= public_e($title) ?> · GSTX PROXY</title>
<link rel="stylesheet" href="/assets/css/public.css?v=<?= public_asset_version('/assets/css/public.css') ?>">
<script src="/assets/js/public.js?v=<?= public_asset_version('/assets/js/public.js') ?>" defer></script>
</head>
<body class="public-page">
<header class="public-topbar">
    <button class="public-menu" type="button" data-public-menu aria-expanded="false" aria-controls="public-sidebar" aria-label="Menu">
        <?= public_icon('grid') ?>
    </button>
    <a class="public-logo" href="/">
        <img src="<?= public_e($brand) ?>" alt="GSTX PROXY">
    </a>
</header>
<div class="public-backdrop" data-public-backdrop></div>
<aside class="public-sidebar" id="public-sidebar" data-public-sidebar>
    <div class="public-side-head">
        <img src="<?= public_e($brand) ?>" alt="GSTX PROXY">
        <button type="button" class="public-close" data-public-close aria-label="Fechar menu"><?= public_icon('x') ?></button>
    </div>
    <nav class="public-nav">
        <a class="<?= $active === 'inicio' ? 'active' : '' ?>" href="/"><?= public_icon('home') ?><span>Início</span></a>
        <a class="<?= $active === 'produtos' ? 'active' : '' ?>" href="/produtos.php"><?= public_icon('box') ?><span>Produtos</span></a>
        <a class="<?= $active === 'keys' ? 'active' : '' ?>" href="/keys-gratis.php"><?= public_icon('key') ?><span>Keys Grátis</span></a>
        <a class="<?= $active === 'docs' ? 'active' : '' ?>" href="/documentacao.php"><?= public_icon('book') ?><span>Documentação</span></a>
    </nav>
</aside>
<main class="public-main">
<?php }

function public_footer(): void
{
    ?>
</main>
<div class="short-dialog-backdrop" data-short-dialog hidden>
    <div class="short-dialog" role="dialog" aria-modal="true" aria-labelledby="short-dialog-title" aria-describedby="short-dialog-message">
        <div class="short-dialog-icon">🔗</div>
        <h2 id="short-dialog-title">LINK COM ENCURTADOR 🔗</h2>
        <p id="short-dialog-message">Negócio aqui é pago e estou liberando de graça pae, ajudar o criador com pelo menos os encurtadores, tudo fácil de passar.</p>
        <div class="short-dialog-actions">
            <button type="button" class="short-btn secondary" data-short-cancel>Voltar</button>
            <button type="button" class="short-btn primary" data-short-continue>Continuar</button>
        </div>
    </div>
</div>
</body>
</html>
<?php }
