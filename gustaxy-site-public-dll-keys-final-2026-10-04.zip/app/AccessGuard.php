<?php
declare(strict_types=1);

final class AccessGuard
{
    private const AUTOMATION_UA_NEEDLES = [
        'curl/', 'wget/', 'python-requests', 'python-urllib', 'go-http-client',
        'okhttp', 'apache-httpclient', 'libwww-perl', 'scrapy', 'headlesschrome',
        'phantomjs', 'selenium', 'puppeteer', 'playwright', 'node-fetch',
        'postmanruntime', 'axios/', 'httpie/', 'java/', 'nikto', 'sqlmap',
        'nmap', 'masscan', 'hydra', 'dirbuster', 'gobuster', 'wfuzz',
    ];

    public static function enabled(): bool
    {
        return (bool) cfg('ACCESS_GUARD_ENABLED', true);
    }

    public static function enforce(): void
    {
        if (!self::enabled()) {
            return;
        }

        $ip = client_ip();

        if ((bool) cfg('ACCESS_GUARD_BLOCK_TOR', true) && self::isTorExit($ip)) {
            self::deny('tor_exit_node', ['ip' => $ip]);
        }

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            $check = self::automationScore();
            $threshold = (int) cfg('ACCESS_GUARD_SCORE_THRESHOLD', 5);
            if ($check['score'] >= $threshold) {
                self::deny('automation_suspected', ['score' => $check['score'], 'reasons' => $check['reasons']]);
            }
        }
    }

    public static function blockTor(): void
    {
        if (!self::enabled() || !(bool) cfg('ACCESS_GUARD_BLOCK_TOR', true)) {
            return;
        }
        $ip = client_ip();
        if (self::isTorExit($ip)) {
            self::deny('tor_exit_node', ['ip' => $ip]);
        }
    }

    public static function isTorExit(string $ip): bool
    {
        if ($ip === '' || $ip === '0.0.0.0') {
            return false;
        }
        if (self::matchesLocalList($ip)) {
            return true;
        }
        return self::matchesDnsel($ip);
    }

    public static function automationScore(): array
    {
        $score = 0;
        $reasons = [];

        $ua = strtolower(user_agent());
        if ($ua === '' || $ua === 'unknown') {
            $score += 3;
            $reasons[] = 'user_agent_missing';
        } else {
            foreach (self::AUTOMATION_UA_NEEDLES as $needle) {
                if (str_contains($ua, $needle)) {
                    $score += 4;
                    $reasons[] = 'user_agent_tool';
                    break;
                }
            }
        }

        if (empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $score += 2;
            $reasons[] = 'no_accept_language';
        }
        if (empty($_SERVER['HTTP_ACCEPT'])) {
            $score += 2;
            $reasons[] = 'no_accept';
        }
        if (empty($_SERVER['HTTP_SEC_FETCH_MODE'])) {
            $score += 2;
            $reasons[] = 'no_sec_fetch';
        }

        $jsProof = (string) ($_POST['js_proof'] ?? '');
        if ($jsProof === '') {
            $score += 3;
            $reasons[] = 'no_js_proof';
        } elseif ($jsProof === 'webdriver') {
            $score += 4;
            $reasons[] = 'webdriver_flag';
        }

        $issued = (int) ($_POST['js_issued'] ?? 0);
        if ($issued > 0) {
            $elapsed = time() - $issued;
            if ($elapsed >= 0 && $elapsed < 1) {
                $score += 2;
                $reasons[] = 'submitted_too_fast';
            }
        }

        return ['score' => $score, 'reasons' => $reasons];
    }

    private static function matchesLocalList(string $ip): bool
    {
        static $set = null;
        if ($set === null) {
            $set = [];
            $path = self::torListPath();
            if (is_file($path) && is_readable($path)) {
                $fh = fopen($path, 'r');
                if ($fh) {
                    while (($line = fgets($fh)) !== false) {
                        $line = trim($line);
                        if ($line !== '' && $line[0] !== '#') {
                            $set[$line] = true;
                        }
                    }
                    fclose($fh);
                }
            }
        }
        return isset($set[$ip]);
    }

    private static function matchesDnsel(string $ip): bool
    {
        if (!(bool) cfg('ACCESS_GUARD_DNSEL', true) || !function_exists('checkdnsrr')) {
            return false;
        }
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return false;
        }
        $serverIp = (string) cfg('ACCESS_GUARD_SERVER_IP', '');
        if ($serverIp === '' || !filter_var($serverIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return false;
        }
        try {
            $port = (int) cfg('ACCESS_GUARD_SERVER_PORT', 443);
            $reversedIp = implode('.', array_reverse(explode('.', $ip)));
            $reversedServer = implode('.', array_reverse(explode('.', $serverIp)));
            $query = sprintf('%s.%d.%s.ip-port.exitlist.torproject.org', $reversedIp, $port, $reversedServer);
            return @checkdnsrr($query, 'A');
        } catch (Throwable) {
            return false;
        }
    }

    public static function torListPath(): string
    {
        return (string) cfg('ACCESS_GUARD_TOR_LIST_PATH', GUSTAXY_ROOT . '/storage/security/tor_exit_nodes.txt');
    }

    private static function deny(string $reason, array $metadata): never
    {
        audit('access_guard_blocked', null, 'request', null, $metadata + ['reason' => $reason]);
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: no-store');
        exit('Acesso negado.');
    }
}
