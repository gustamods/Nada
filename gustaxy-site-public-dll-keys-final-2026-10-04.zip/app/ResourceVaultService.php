<?php
declare(strict_types=1);

final class ResourceVaultService
{
    private const MAX_BYTES = 536870912;
    private const DOWNLOAD_TTL = 180;
    private const TICKET_GC_SECONDS = 900;

    private static function root(): string
    {
        return GUSTAXY_ROOT . '/storage/resources';
    }

    private static function vaultDir(): string
    {
        return self::root() . '/vault';
    }

    private static function ticketDir(): string
    {
        return self::root() . '/tickets';
    }

    private static function manifestFile(): string
    {
        return self::root() . '/vault-manifest.json';
    }

    public static function manifest(): array
    {
        $path = self::manifestFile();
        if (!is_file($path) || !is_readable($path)) {
            return ['version' => 0, 'file' => '', 'sha256' => '', 'size_bytes' => 0, 'filename' => ''];
        }
        $data = json_decode((string) file_get_contents($path), true);
        if (!is_array($data)) {
            return ['version' => 0, 'file' => '', 'sha256' => '', 'size_bytes' => 0, 'filename' => ''];
        }
        return $data;
    }

    public static function status(): array
    {
        $m = self::manifest();
        $file = self::vaultDir() . '/' . basename((string) ($m['file'] ?? ''));
        $valid = preg_match('/^[a-f0-9]{32}\.bin$/', basename($file))
            && is_file($file)
            && (int) ($m['size_bytes'] ?? 0) === (int) filesize($file)
            && hash_equals(strtolower((string) ($m['sha256'] ?? '')), strtolower((string) hash_file('sha256', $file)));
        return [
            'available' => $valid,
            'version' => (int) ($m['version'] ?? 0),
            'sha256' => strtoupper((string) ($m['sha256'] ?? '')),
            'size_bytes' => (int) ($m['size_bytes'] ?? 0),
            'filename' => (string) ($m['filename'] ?? ''),
            'updated_at' => (string) ($m['updated_at'] ?? ''),
            'file' => $file,
        ];
    }

    public static function manifestPayload(string $deviceHash, string $certificateSha256 = ''): array
    {
        self::gcTickets();
        $status = self::status();
        if (!$status['available']) {
            return ['available' => false, 'version' => 0, 'sha256' => '', 'size_bytes' => 0, 'download_url' => '', 'expires_at' => null];
        }
        $expires = time() + self::DOWNLOAD_TTL;
        $ticket = self::issueTicket((int) $status['version'], (string) $status['sha256'], $deviceHash, $certificateSha256, $expires);
        $base = rtrim((string) cfg('APP_URL', ''), '/');
        $downloadUrl = $base . '/api/v1/resources/download?ticket=' . rawurlencode($ticket);
        return [
            'available' => true,
            'version' => (int) $status['version'],
            'sha256' => (string) $status['sha256'],
            'size_bytes' => (int) $status['size_bytes'],
            'download_url' => $downloadUrl,
            'expires_at' => gmdate('Y-m-d H:i:s', $expires),
        ];
    }

    public static function verifyTicket(string $ticket, string $deviceHash, string $certificateSha256): ?array
    {
        if (!preg_match('/^[A-Za-z0-9._:-]{32,512}$/', $ticket)) {
            return null;
        }
        $parts = explode('.', $ticket, 2);
        if (count($parts) !== 2) {
            return null;
        }
        $payloadJson = base64_decode(strtr($parts[0], '-_', '+/'), true);
        $signature = $parts[1];
        if ($payloadJson === false || $signature === '') {
            return null;
        }
        $payload = json_decode($payloadJson, true);
        if (!is_array($payload)) {
            return null;
        }
        $version = (int) ($payload['v'] ?? 0);
        $expires = (int) ($payload['exp'] ?? 0);
        $sha = strtoupper((string) ($payload['sha'] ?? ''));
        $device = (string) ($payload['d'] ?? '');
        $cert = strtoupper((string) ($payload['c'] ?? ''));
        $nonce = (string) ($payload['n'] ?? '');
        if ($version < 1 || $expires < time() || $expires > time() + self::DOWNLOAD_TTL + 30 || !preg_match('/^[A-F0-9]{64}$/', $sha) || $device === '' || $nonce === '') {
            return null;
        }
        if (!hash_equals($device, $deviceHash)) {
            return null;
        }
        if ($cert !== '' && $certificateSha256 !== '' && !hash_equals($cert, strtoupper($certificateSha256))) {
            return null;
        }
        $data = $parts[0];
        $expected = hash_hmac('sha256', $data, app_key());
        if (!hash_equals($expected, $signature)) {
            return null;
        }
        $status = self::status();
        if (!$status['available'] || (int) $status['version'] !== $version || !hash_equals(strtoupper((string) $status['sha256']), $sha)) {
            return null;
        }
        $marker = self::ticketDir() . '/' . hash('sha256', $ticket) . '.used';
        if (!is_dir(dirname($marker))) {
            mkdir(dirname($marker), 0700, true);
        }
        $handle = @fopen($marker, 'x');
        if ($handle === false) {
            return null;
        }
        fclose($handle);
        @file_put_contents($marker, (string) time(), LOCK_EX);
        return $status;
    }

    public static function importFromUrl(string $url, int $actorId): array
    {
        self::ensureDirs();
        self::gcTickets();
        $url = trim($url);
        self::validateOriginUrl($url);
        $temp = self::vaultDir() . '/.' . bin2hex(random_bytes(16)) . '.part';
        $source = self::resolveLocalSource($url);
        $sourceDelete = null;
        try {
            if ($source !== null) {
                self::copyLocal($source, $temp);
                $sourceDelete = $source;
            } else {
                self::downloadRemote($url, $temp);
            }
            $meta = self::validateVaultFile($temp);
            $current = self::manifest();
            $version = max(0, (int) ($current['version'] ?? 0)) + 1;
            $finalName = bin2hex(random_bytes(16)) . '.bin';
            $final = self::vaultDir() . '/' . $finalName;
            if (!rename($temp, $final)) {
                if (!copy($temp, $final)) {
                    throw new RuntimeException('Não foi possível salvar o recurso.');
                }
                unlink($temp);
            }
            $manifest = [
                'version' => $version,
                'file' => $finalName,
                'sha256' => $meta['sha256'],
                'size_bytes' => $meta['size_bytes'],
                'filename' => 'gx_7c91e4a2.bin',
                'created_at' => gmdate('Y-m-d H:i:s'),
                'updated_at' => gmdate('Y-m-d H:i:s'),
            ];
            self::writeManifest($manifest);
            $old = (string) ($current['file'] ?? '');
            if (preg_match('/^[a-f0-9]{32}\.bin$/', $old) && $old !== $finalName) {
                @unlink(self::vaultDir() . '/' . $old);
            }
            if ($sourceDelete !== null && is_file($sourceDelete) && $sourceDelete !== $final) {
                @unlink($sourceDelete);
            }
            audit('resource_vault_published', $actorId, 'resource_vault', (string) $version, [
                'size_bytes' => $meta['size_bytes'],
                'sha256' => $meta['sha256'],
                'source_host' => (string) parse_url($url, PHP_URL_HOST),
            ]);
            return $manifest + ['source_removed' => $sourceDelete !== null];
        } catch (Throwable $e) {
            @unlink($temp);
            throw $e;
        }
    }

    private static function ensureDirs(): void
    {
        foreach ([self::root(), self::vaultDir(), self::ticketDir()] as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0700, true);
            }
        }
        $deny = "Require all denied\n";
        foreach ([self::root(), self::vaultDir(), self::ticketDir()] as $dir) {
            $ht = $dir . '/.htaccess';
            if (!is_file($ht)) {
                @file_put_contents($ht, $deny, LOCK_EX);
            }
        }
    }

    private static function validateOriginUrl(string $url): void
    {
        $parts = parse_url($url);
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https') {
            throw new InvalidArgumentException('O link precisa usar HTTPS.');
        }
        if (!empty($parts['user']) || !empty($parts['pass']) || !empty($parts['fragment'])) {
            throw new InvalidArgumentException('Link inválido.');
        }
        $host = strtolower(trim((string) ($parts['host'] ?? '')));
        if ($host === '' || !preg_match('/^[a-z0-9.-]+$/', $host)) {
            throw new InvalidArgumentException('Host do link inválido.');
        }
        $allowed = cfg('RESOURCE_ORIGIN_HOSTS', []);
        if (is_string($allowed)) {
            $allowed = array_filter(array_map('trim', explode(',', $allowed)));
        }
        $allowed = array_values(array_unique(array_map('strtolower', array_filter((array) $allowed, 'is_string'))));
        $appHost = strtolower((string) parse_url((string) cfg('APP_URL', ''), PHP_URL_HOST));
        if (!$appHost || (!hash_equals($appHost, $host) && !in_array($host, $allowed, true))) {
            throw new InvalidArgumentException('Host do recurso não está autorizado.');
        }
        $path = rawurldecode((string) ($parts['path'] ?? ''));
        if (!preg_match('/\.bin$/i', $path)) {
            throw new InvalidArgumentException('Informe o link direto de um arquivo .bin.');
        }
        if (preg_match('~/(?:api/v1|config|app|database|admin|storage)(?:/|$)~i', $path)) {
            throw new InvalidArgumentException('Origem do recurso não permitida.');
        }
    }

    private static function resolveLocalSource(string $url): ?string
    {
        $appHost = strtolower((string) parse_url((string) cfg('APP_URL', ''), PHP_URL_HOST));
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if ($host === '' || $appHost === '' || !hash_equals($host, $appHost)) {
            return null;
        }
        $path = rawurldecode((string) parse_url($url, PHP_URL_PATH));
        $candidate = realpath(GUSTAXY_ROOT . '/' . ltrim($path, '/'));
        if ($candidate === false || !is_file($candidate)) {
            return null;
        }
        $root = realpath(GUSTAXY_ROOT);
        if ($root === false || !str_starts_with($candidate, $root . DIRECTORY_SEPARATOR)) {
            throw new InvalidArgumentException('Origem do recurso inválida.');
        }
        $relative = ltrim(str_replace('\\', '/', substr($candidate, strlen($root))), '/');
        if (preg_match('~^(?:config|app|database|admin|storage|api)(?:/|$)~i', $relative)) {
            throw new InvalidArgumentException('Origem do recurso não permitida.');
        }
        if (strtolower((string) pathinfo($candidate, PATHINFO_EXTENSION)) !== 'bin') {
            throw new InvalidArgumentException('Origem do recurso não permitida.');
        }
        return $candidate;
    }

    private static function copyLocal(string $source, string $temp): void
    {
        $size = (int) filesize($source);
        if ($size <= 0 || $size > self::MAX_BYTES) {
            throw new InvalidArgumentException('O BIN excede o limite permitido.');
        }
        $in = fopen($source, 'rb');
        $out = fopen($temp, 'wb');
        if ($in === false || $out === false) {
            if (is_resource($in)) fclose($in);
            if (is_resource($out)) fclose($out);
            throw new RuntimeException('Não foi possível ler o arquivo de origem.');
        }
        try {
            while (!feof($in)) {
                $chunk = fread($in, 1048576);
                if ($chunk === false) throw new RuntimeException('Falha ao ler o BIN.');
                if ($chunk !== '') fwrite($out, $chunk);
            }
        } finally {
            fclose($in);
            fclose($out);
        }
    }

    private static function downloadRemote(string $url, string $temp): void
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('cURL é necessário para importar o BIN por URL.');
        }
        $out = fopen($temp, 'wb');
        if ($out === false) throw new RuntimeException('Não foi possível criar o arquivo temporário.');
        $received = 0;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_HEADER => false,
            CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_TIMEOUT => 1800,
            CURLOPT_USERAGENT => 'GustaxyResourceImporter/1.0',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_WRITEFUNCTION => static function ($curl, string $data) use (&$received, $out): int {
                $received += strlen($data);
                if ($received > self::MAX_BYTES) {
                    return 0;
                }
                return fwrite($out, $data);
            },
        ]);
        $ok = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        fclose($out);
        if ($ok === false || $status !== 200 || $error !== '') {
            @unlink($temp);
            throw new RuntimeException('Não foi possível importar o BIN pela URL.');
        }
        if ($received <= 0 || $received > self::MAX_BYTES) {
            @unlink($temp);
            throw new InvalidArgumentException('O BIN excede o limite permitido.');
        }
    }

    private static function validateVaultFile(string $file): array
    {
        $size = (int) filesize($file);
        if ($size < 33 || $size > self::MAX_BYTES) {
            throw new InvalidArgumentException('BIN inválido ou fora do limite.');
        }
        $handle = fopen($file, 'rb');
        if ($handle === false) throw new RuntimeException('Não foi possível validar o BIN.');
        $header = fread($handle, 17);
        fclose($handle);
        if ($header === false || strlen($header) !== 17 || substr($header, 0, 4) !== 'GXB1' || ord($header[4]) !== 1) {
            throw new InvalidArgumentException('O arquivo não possui o formato de vault esperado.');
        }
        $sha = strtoupper((string) hash_file('sha256', $file));
        return ['sha256' => $sha, 'size_bytes' => $size];
    }

    private static function writeManifest(array $manifest): void
    {
        $temp = self::manifestFile() . '.' . bin2hex(random_bytes(8)) . '.tmp';
        $json = json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($json === false || file_put_contents($temp, $json, LOCK_EX) === false || !rename($temp, self::manifestFile())) {
            @unlink($temp);
            throw new RuntimeException('Não foi possível atualizar o manifesto.');
        }
    }

    private static function issueTicket(int $version, string $sha, string $deviceHash, string $certificateSha256, int $expires): string
    {
        $payload = [
            'v' => $version,
            'exp' => $expires,
            'sha' => strtoupper($sha),
            'd' => $deviceHash,
            'c' => strtoupper($certificateSha256),
            'n' => bin2hex(random_bytes(18)),
        ];
        $encoded = rtrim(strtr(base64_encode((string) json_encode($payload, JSON_UNESCAPED_SLASHES)), '+/', '-_'), '=');
        return $encoded . '.' . hash_hmac('sha256', $encoded, app_key());
    }

    private static function gcTickets(): void
    {
        $dir = self::ticketDir();
        if (!is_dir($dir)) return;
        foreach (glob($dir . '/*.used') ?: [] as $file) {
            if (is_file($file) && filemtime($file) !== false && filemtime($file) < time() - self::TICKET_GC_SECONDS) {
                @unlink($file);
            }
        }
    }
}
