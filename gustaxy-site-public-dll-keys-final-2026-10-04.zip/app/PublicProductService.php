<?php
declare(strict_types=1);

final class PublicProductService
{
    private const TABLE = 'public_products';

    public static function ensureSchema(): void
    {
        static $ready = false;
        if ($ready) {
            return;
        }
        $pdo = db();
        if ((string) cfg('DB_DRIVER', 'mysql') === 'sqlite') {
            $pdo->exec("CREATE TABLE IF NOT EXISTS public_products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                thumb_url TEXT NOT NULL,
                platform TEXT NOT NULL,
                apk_version TEXT NOT NULL DEFAULT '',
                download_type TEXT NOT NULL,
                download_url TEXT NOT NULL,
                is_active INTEGER NOT NULL DEFAULT 1,
                sort_order INTEGER NOT NULL DEFAULT 0,
                created_by INTEGER NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )");
            $pdo->exec('CREATE INDEX IF NOT EXISTS idx_public_products_active ON public_products(is_active, sort_order, id)');
        } else {
            $pdo->exec("CREATE TABLE IF NOT EXISTS public_products (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                title VARCHAR(120) NOT NULL,
                description VARCHAR(500) NOT NULL DEFAULT '',
                thumb_url VARCHAR(2048) NOT NULL,
                platform ENUM('android','iphone','pc') NOT NULL,
                apk_version VARCHAR(32) NOT NULL DEFAULT '',
                download_type ENUM('direct','shortened') NOT NULL,
                download_url VARCHAR(2048) NOT NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                sort_order INT NOT NULL DEFAULT 0,
                created_by INT UNSIGNED NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_public_products_active (is_active, sort_order, id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        }
        $ready = true;
    }

    public static function validateUrl(string $url, int $maxLength = 2048): string
    {
        $url = trim($url);
        if ($url === '' || strlen($url) > $maxLength) {
            throw new InvalidArgumentException('URL inválida.');
        }
        $parts = parse_url($url);
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https') {
            throw new InvalidArgumentException('Use somente HTTPS.');
        }
        if (!empty($parts['user']) || !empty($parts['pass']) || !empty($parts['fragment'])) {
            throw new InvalidArgumentException('URL inválida.');
        }
        $host = strtolower(trim((string) ($parts['host'] ?? '')));
        if ($host === '' || !preg_match('/^[a-z0-9.-]+$/', $host) || filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6)) {
            throw new InvalidArgumentException('Host inválido.');
        }
        return $url;
    }

    public static function normalizePlatform(string $platform): string
    {
        $platform = strtolower(trim($platform));
        if (!in_array($platform, ['android', 'iphone', 'pc'], true)) {
            throw new InvalidArgumentException('Classificação inválida.');
        }
        return $platform;
    }

    public static function normalizeDownloadType(string $type): string
    {
        $type = strtolower(trim($type));
        if (!in_array($type, ['direct', 'shortened'], true)) {
            throw new InvalidArgumentException('Tipo de link inválido.');
        }
        return $type;
    }

    private static function validateFields(array $input): array
    {
        $title = trim((string) ($input['title'] ?? ''));
        $description = trim((string) ($input['description'] ?? ''));
        $thumb = self::validateUrl((string) ($input['thumb_url'] ?? ''));
        $platform = self::normalizePlatform((string) ($input['platform'] ?? 'android'));
        $apkVersion = trim((string) ($input['apk_version'] ?? ''));
        $downloadType = self::normalizeDownloadType((string) ($input['download_type'] ?? 'direct'));
        $downloadUrl = self::validateUrl((string) ($input['download_url'] ?? ''));
        $sortOrder = filter_var($input['sort_order'] ?? 0, FILTER_VALIDATE_INT);
        if ($title === '' || mb_strlen($title) > 120) {
            throw new InvalidArgumentException('Título inválido.');
        }
        if (mb_strlen($description) > 500) {
            throw new InvalidArgumentException('Descrição muito longa.');
        }
        if (mb_strlen($apkVersion) > 32) {
            throw new InvalidArgumentException('Versão inválida.');
        }
        if ($sortOrder === false) {
            $sortOrder = 0;
        }
        $sortOrder = max(-1000000, min(1000000, (int) $sortOrder));
        return [$title, $description, $thumb, $platform, $apkVersion, $downloadType, $downloadUrl, $sortOrder];
    }

    public static function create(array $input, int $actorId): int
    {
        self::ensureSchema();
        [$title, $description, $thumb, $platform, $apkVersion, $downloadType, $downloadUrl, $sortOrder] = self::validateFields($input);
        $stmt = db()->prepare('INSERT INTO ' . self::TABLE . ' (title, description, thumb_url, platform, apk_version, download_type, download_url, is_active, sort_order, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)');
        $stmt->execute([$title, $description, $thumb, $platform, $apkVersion, $downloadType, $downloadUrl, $sortOrder, $actorId]);
        $id = (int) db()->lastInsertId();
        audit('public_product_created', $actorId, 'public_product', (string) $id, ['platform' => $platform, 'download_type' => $downloadType]);
        return $id;
    }

    public static function update(int $id, array $input, int $actorId): void
    {
        self::ensureSchema();
        if ($id < 1) {
            throw new InvalidArgumentException('Item inválido.');
        }
        [$title, $description, $thumb, $platform, $apkVersion, $downloadType, $downloadUrl, $sortOrder] = self::validateFields($input);
        $stmt = db()->prepare('UPDATE ' . self::TABLE . ' SET title = ?, description = ?, thumb_url = ?, platform = ?, apk_version = ?, download_type = ?, download_url = ?, sort_order = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
        $stmt->execute([$title, $description, $thumb, $platform, $apkVersion, $downloadType, $downloadUrl, $sortOrder, $id]);
        if ($stmt->rowCount() < 1) {
            $check = db()->prepare('SELECT id FROM ' . self::TABLE . ' WHERE id = ? LIMIT 1');
            $check->execute([$id]);
            if (!$check->fetch()) {
                throw new RuntimeException('Item não encontrado.');
            }
        }
        audit('public_product_updated', $actorId, 'public_product', (string) $id);
    }

    public static function delete(int $id, int $actorId): void
    {
        self::ensureSchema();
        $pdo = db();
        $stmt = $pdo->prepare('DELETE FROM ' . self::TABLE . ' WHERE id = ?');
        $stmt->execute([$id]);
        if ($stmt->rowCount() !== 1) {
            throw new RuntimeException('Item não encontrado.');
        }
        audit('public_product_deleted', $actorId, 'public_product', (string) $id);
    }

    public static function setActive(int $id, bool $active, int $actorId): void
    {
        self::ensureSchema();
        $stmt = db()->prepare('UPDATE ' . self::TABLE . ' SET is_active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
        $stmt->execute([$active ? 1 : 0, $id]);
        if ($stmt->rowCount() < 1) {
            $check = db()->prepare('SELECT id FROM ' . self::TABLE . ' WHERE id = ? LIMIT 1');
            $check->execute([$id]);
            if (!$check->fetch()) {
                throw new RuntimeException('Item não encontrado.');
            }
        }
        audit($active ? 'public_product_enabled' : 'public_product_disabled', $actorId, 'public_product', (string) $id);
    }

    public static function listActive(int $limit = 50): array
    {
        self::ensureSchema();
        $limit = max(1, min(100, $limit));
        $stmt = db()->query('SELECT id, title, description, thumb_url, platform, apk_version, download_type, download_url, sort_order, created_at, updated_at FROM ' . self::TABLE . ' WHERE is_active = 1 ORDER BY sort_order ASC, id DESC LIMIT ' . $limit);
        return $stmt->fetchAll();
    }

    public static function listAll(int $limit = 200): array
    {
        self::ensureSchema();
        $limit = max(1, min(500, $limit));
        $stmt = db()->query('SELECT id, title, description, thumb_url, platform, apk_version, download_type, download_url, is_active, sort_order, created_at, updated_at FROM ' . self::TABLE . ' ORDER BY sort_order ASC, id DESC LIMIT ' . $limit);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        self::ensureSchema();
        $stmt = db()->prepare('SELECT id, title, description, thumb_url, platform, apk_version, download_type, download_url, is_active, sort_order, created_at, updated_at FROM ' . self::TABLE . ' WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }
}
