<?php
declare(strict_types=1);

final class Auth
{
    public static function login(string $username, string $password): array
    {
        if (!rate_limit('admin-login', 12, 60) || !rate_limit('admin-login-account', 6, 300)) {
            return ['ok' => false, 'error' => 'Não foi possível concluir o login agora. Tente novamente mais tarde.'];
        }
        $username = mb_substr(trim($username), 0, 190);
        $stmt = db()->prepare('SELECT * FROM admin_users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        $dummy = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC7VQ1gO5V5A5hT9u8iK';
        $validPassword = password_verify($password, $user['password_hash'] ?? $dummy);
        $locked = $user && !empty($user['locked_until']) && strtotime((string) $user['locked_until']) > time();
        $active = $user && (int) $user['is_active'] === 1;
        $ok = $user && $active && !$locked && $validPassword;
        $ctx = client_context();

        $log = db()->prepare('INSERT INTO login_logs (admin_user_id, success, browser, operating_system, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
        $log->execute([$user['id'] ?? null, $ok ? 1 : 0, $ctx['browser'], $ctx['os'], $ctx['ip'], $ctx['user_agent']]);

        if (!$ok) {
            if ($user) {
                $attempts = (int) $user['failed_attempts'] + 1;
                $delay = $attempts >= 5 ? min(900, 2 ** min(9, $attempts - 4)) : 0;
                $until = $delay ? gmdate('Y-m-d H:i:s', time() + $delay) : null;
                $update = db()->prepare('UPDATE admin_users SET failed_attempts = ?, locked_until = ? WHERE id = ?');
                $update->execute([$attempts, $until, $user['id']]);
            }
            audit('admin_login_failed', $user['id'] ?? null, 'admin_user', isset($user['id']) ? (string) $user['id'] : null, ['username_supplied' => $username !== '']);
            usleep(random_int(150000, 450000));
            return ['ok' => false, 'error' => 'Usuário ou senha inválidos.'];
        }

        $reset = db()->prepare('UPDATE admin_users SET failed_attempts = 0, locked_until = NULL, last_login_at = CURRENT_TIMESTAMP WHERE id = ?');
        $reset->execute([$user['id']]);

        $totpEnabled = !empty($user['totp_confirmed_at'] ?? null);
        if ($totpEnabled) {
            session_regenerate_id(true);
            $_SESSION['pending_2fa_user_id'] = (int) $user['id'];
            $_SESSION['pending_2fa_started'] = time();
            $_SESSION['csrf'] = random_token(32);
            audit('admin_login_password_ok', (int) $user['id'], 'admin_user', (string) $user['id'], ['awaiting_2fa' => true]);
            return ['ok' => true, 'requires_2fa' => true];
        }

        start_authenticated_session((int) $user['id']);
        audit('admin_login_success', (int) $user['id'], 'admin_user', (string) $user['id'], ['browser' => $ctx['browser'], 'os' => $ctx['os']]);
        return ['ok' => true, 'role' => (string) $user['role']];
    }

    public static function completeTwoFactor(string $code): array
    {
        $pendingId = (int) ($_SESSION['pending_2fa_user_id'] ?? 0);
        $startedAt = (int) ($_SESSION['pending_2fa_started'] ?? 0);
        if ($pendingId <= 0 || $startedAt <= 0 || (time() - $startedAt) > 300) {
            self::clearPendingTwoFactor();
            return ['ok' => false, 'error' => 'Sessão de login expirada. Entre novamente.'];
        }
        if (!rate_limit('admin-2fa-verify', 8, 300)) {
            return ['ok' => false, 'error' => 'Muitas tentativas. Aguarde alguns minutos.'];
        }
        $stmt = db()->prepare('SELECT * FROM admin_users WHERE id = ? LIMIT 1');
        $stmt->execute([$pendingId]);
        $user = $stmt->fetch();
        $storedSecret = (string) ($user['totp_secret'] ?? '');
        $secret = Totp::open($storedSecret);
        if (!$user || $secret === '' || empty($user['totp_confirmed_at']) || (int) $user['is_active'] !== 1) {
            self::clearPendingTwoFactor();
            return ['ok' => false, 'error' => 'Não foi possível validar o código. Entre novamente.'];
        }
        $lastCounter = (int) ($user['totp_last_counter'] ?? 0);
        $counter = Totp::matchingCounter($secret, $code);
        if ($counter === null || $counter <= $lastCounter) {
            audit('admin_login_2fa_failed', (int) $user['id'], 'admin_user', (string) $user['id']);
            return ['ok' => false, 'error' => 'Código inválido ou já utilizado.'];
        }
        // Consome o contador de forma atômica: duas requisições concorrentes
        // não conseguem autenticar com o mesmo código TOTP.
        $consume = db()->prepare('UPDATE admin_users SET totp_last_counter = ? WHERE id = ? AND totp_last_counter < ?');
        $consume->execute([$counter, (int) $user['id'], $counter]);
        if ($consume->rowCount() !== 1) {
            audit('admin_login_2fa_failed', (int) $user['id'], 'admin_user', (string) $user['id'], ['reason' => 'counter_race']);
            return ['ok' => false, 'error' => 'Código inválido ou já utilizado.'];
        }
        self::upgradeSecretStorage((int) $user['id'], $secret, $storedSecret);
        self::clearPendingTwoFactor();
        start_authenticated_session((int) $user['id']);
        audit('admin_login_2fa_success', (int) $user['id'], 'admin_user', (string) $user['id']);
        return ['ok' => true];
    }

    /**
     * Contas que ativaram o 2FA antes da cifragem têm o segredo em texto puro.
     * No próximo login com código válido ele é regravado cifrado. Se algo falhar
     * (ex.: sem permissão de ALTER), o segredo antigo continua funcionando.
     */
    private static function upgradeSecretStorage(int $userId, string $secret, string $stored): void
    {
        if ($secret === '' || Totp::isSealed($stored)) {
            return;
        }
        try {
            if (!self::ensureSecretColumn()) {
                return;
            }
            db()->prepare('UPDATE admin_users SET totp_secret = ? WHERE id = ?')->execute([Totp::seal($secret), $userId]);
        } catch (Throwable $e) {
            error_log('[gustaxy] totp upgrade: ' . $e->getMessage());
        }
    }

    /** O valor cifrado é maior que 64 caracteres: garante a coluna com 255 (MySQL). */
    private static function ensureSecretColumn(): bool
    {
        if ((string) cfg('DB_DRIVER', 'mysql') === 'sqlite') {
            return true;
        }
        try {
            $len = db()->query("SELECT CHARACTER_MAXIMUM_LENGTH FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admin_users' AND COLUMN_NAME = 'totp_secret'")->fetchColumn();
            if ($len === false || $len === null) {
                return false;
            }
            if ((int) $len >= 255) {
                return true;
            }
            db()->exec('ALTER TABLE admin_users MODIFY totp_secret VARCHAR(255) NULL');
            return true;
        } catch (Throwable $e) {
            error_log('[gustaxy] totp column: ' . $e->getMessage());
            return false;
        }
    }

    public static function hasPendingTwoFactor(): bool
    {
        $startedAt = (int) ($_SESSION['pending_2fa_started'] ?? 0);
        return (int) ($_SESSION['pending_2fa_user_id'] ?? 0) > 0 && $startedAt > 0 && (time() - $startedAt) <= 300;
    }

    public static function clearPendingTwoFactor(): void
    {
        unset($_SESSION['pending_2fa_user_id'], $_SESSION['pending_2fa_started']);
    }

    public static function changePassword(int $userId, string $currentPassword, string $newPassword): array
    {
        if (!rate_limit('admin-password-change', 8, 300)) {
            return ['ok' => false, 'error' => 'Muitas tentativas. Aguarde alguns minutos.'];
        }
        $stmt = db()->prepare('SELECT * FROM admin_users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($currentPassword, (string) $user['password_hash'])) {
            audit('admin_password_change_failed', $userId, 'admin_user', (string) $userId);
            return ['ok' => false, 'error' => 'Senha atual incorreta.'];
        }
        if (strlen($newPassword) < 12) {
            return ['ok' => false, 'error' => 'A nova senha deve ter pelo menos 12 caracteres.'];
        }
        if (password_verify($newPassword, (string) $user['password_hash'])) {
            return ['ok' => false, 'error' => 'A nova senha deve ser diferente da atual.'];
        }
        $algorithm = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
        db()->prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?')->execute([password_hash($newPassword, $algorithm), $userId]);
        session_regenerate_id(true);
        $_SESSION['csrf'] = random_token(32);
        $_SESSION['fingerprint'] = session_fingerprint();
        audit('admin_password_changed', $userId, 'admin_user', (string) $userId);
        return ['ok' => true];
    }

    public static function beginTotpEnrollment(string $username): string
    {
        $secret = Totp::generateSecret();
        $_SESSION['pending_totp_secret'] = $secret;
        return $secret;
    }

    public static function confirmTotpEnrollment(int $userId, string $code): array
    {
        if (!rate_limit('admin-2fa-setup', 10, 300)) {
            return ['ok' => false, 'error' => 'Muitas tentativas. Aguarde alguns minutos.'];
        }
        $secret = (string) ($_SESSION['pending_totp_secret'] ?? '');
        if ($secret === '') {
            return ['ok' => false, 'error' => 'Gere um novo código secreto antes de confirmar.'];
        }
        $counter = Totp::matchingCounter($secret, $code);
        if ($counter === null) {
            audit('totp_enable_failed', $userId, 'admin_user', (string) $userId);
            return ['ok' => false, 'error' => 'Código inválido. Verifique o horário do seu dispositivo e tente de novo.'];
        }
        $stored = $secret;
        if (self::ensureSecretColumn()) {
            try {
                $stored = Totp::seal($secret);
            } catch (Throwable $e) {
                error_log('[gustaxy] totp seal: ' . $e->getMessage());
            }
        }
        db()->prepare('UPDATE admin_users SET totp_secret = ?, totp_confirmed_at = CURRENT_TIMESTAMP, totp_last_counter = ? WHERE id = ?')
            ->execute([$stored, $counter, $userId]);
        unset($_SESSION['pending_totp_secret']);
        audit('totp_enabled', $userId, 'admin_user', (string) $userId);
        return ['ok' => true];
    }

    public static function disableTotp(int $userId, string $currentPassword): array
    {
        if (!rate_limit('admin-2fa-disable', 8, 300)) {
            return ['ok' => false, 'error' => 'Muitas tentativas. Aguarde alguns minutos.'];
        }
        $stmt = db()->prepare('SELECT * FROM admin_users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($currentPassword, (string) $user['password_hash'])) {
            return ['ok' => false, 'error' => 'Senha atual incorreta.'];
        }
        db()->prepare('UPDATE admin_users SET totp_secret = NULL, totp_confirmed_at = NULL, totp_last_counter = 0 WHERE id = ?')->execute([$userId]);
        audit('totp_disabled', $userId, 'admin_user', (string) $userId);
        return ['ok' => true];
    }

    public static function logout(): void
    {
        $user = current_user();
        if ($user) {
            audit('admin_logout', (int) $user['id'], 'admin_user', (string) $user['id']);
        }
        self::clearPendingTwoFactor();
        unset($_SESSION['pending_totp_secret'], $_SESSION['fingerprint'], $_SESSION['session_started']);
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], '', (bool) $params['secure'], (bool) $params['httponly']);
        }
        session_destroy();
    }
}
