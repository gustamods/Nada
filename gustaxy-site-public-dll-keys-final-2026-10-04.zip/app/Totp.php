<?php
declare(strict_types=1);

final class Totp
{
    private const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    private const PERIOD = 30;
    private const DIGITS = 6;

    private const SEAL_PREFIX = 'enc:v1:';

    public static function generateSecret(int $bytes = 20): string
    {
        return self::base32Encode(random_bytes($bytes));
    }

    public static function isSealed(string $stored): bool
    {
        return str_starts_with($stored, self::SEAL_PREFIX);
    }

    /** Cifra o segredo (AES-256-GCM, subchave HKDF) para guardar no banco. */
    public static function seal(string $secret): string
    {
        $iv = random_bytes(12);
        $tag = '';
        $ciphertext = openssl_encrypt($secret, 'aes-256-gcm', app_subkey('totp-secret-v1'), OPENSSL_RAW_DATA, $iv, $tag);
        if ($ciphertext === false || strlen($tag) !== 16) {
            throw new RuntimeException('Não foi possível proteger o segredo do 2FA.');
        }
        return self::SEAL_PREFIX . b64url_encode($iv . $tag . $ciphertext);
    }

    /**
     * Devolve o segredo em claro. Valores antigos (sem prefixo) são segredos
     * em texto puro de antes da cifragem e passam direto. '' = não conseguiu abrir.
     */
    public static function open(string $stored): string
    {
        if (!self::isSealed($stored)) {
            return $stored;
        }
        $payload = b64url_decode(substr($stored, strlen(self::SEAL_PREFIX)));
        if (strlen($payload) < 29) {
            return '';
        }
        $plain = openssl_decrypt(substr($payload, 28), 'aes-256-gcm', app_subkey('totp-secret-v1'), OPENSSL_RAW_DATA, substr($payload, 0, 12), substr($payload, 12, 16));
        return is_string($plain) ? $plain : '';
    }

    public static function base32Encode(string $data): string
    {
        if ($data === '') {
            return '';
        }
        $bits = '';
        for ($i = 0, $len = strlen($data); $i < $len; $i++) {
            $bits .= str_pad(decbin(ord($data[$i])), 8, '0', STR_PAD_LEFT);
        }
        $output = '';
        foreach (str_split($bits, 5) as $chunk) {
            if (strlen($chunk) < 5) {
                $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
            }
            $output .= self::ALPHABET[bindec($chunk)];
        }
        return $output;
    }

    public static function base32Decode(string $secret): string
    {
        $secret = strtoupper(preg_replace('/[^A-Z2-7]/', '', $secret) ?? '');
        if ($secret === '') {
            return '';
        }
        $bits = '';
        for ($i = 0, $len = strlen($secret); $i < $len; $i++) {
            $pos = strpos(self::ALPHABET, $secret[$i]);
            if ($pos === false) {
                continue;
            }
            $bits .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
        }
        $bytes = '';
        foreach (str_split($bits, 8) as $byte) {
            if (strlen($byte) < 8) {
                break;
            }
            $bytes .= chr((int) bindec($byte));
        }
        return $bytes;
    }

    public static function formatForDisplay(string $secret): string
    {
        return trim(chunk_split($secret, 4, ' '));
    }

    public static function provisioningUri(string $secret, string $accountLabel, string $issuer = 'Gustaxy Admin'): string
    {
        $label = rawurlencode($issuer) . ':' . rawurlencode($accountLabel);
        $query = http_build_query([
            'secret' => $secret,
            'issuer' => $issuer,
            'algorithm' => 'SHA1',
            'digits' => (string) self::DIGITS,
            'period' => (string) self::PERIOD,
        ], '', '&', PHP_QUERY_RFC3986);
        return 'otpauth://totp/' . $label . '?' . $query;
    }

    public static function counterAt(int $timestamp): int
    {
        return intdiv($timestamp, self::PERIOD);
    }

    public static function codeForCounter(string $secretBase32, int $counter): string
    {
        $key = self::base32Decode($secretBase32);
        $binCounter = pack('N2', 0, $counter);
        $hash = hash_hmac('sha1', $binCounter, $key, true);
        $offset = ord($hash[19]) & 0x0F;
        $part = ((ord($hash[$offset]) & 0x7F) << 24)
            | ((ord($hash[$offset + 1]) & 0xFF) << 16)
            | ((ord($hash[$offset + 2]) & 0xFF) << 8)
            | (ord($hash[$offset + 3]) & 0xFF);
        $otp = $part % (10 ** self::DIGITS);
        return str_pad((string) $otp, self::DIGITS, '0', STR_PAD_LEFT);
    }

    public static function matchingCounter(string $secretBase32, string $code, int $window = 1): ?int
    {
        $code = preg_replace('/\D+/', '', $code) ?? '';
        if (strlen($code) !== self::DIGITS) {
            return null;
        }
        $now = self::counterAt(time());
        for ($i = -$window; $i <= $window; $i++) {
            $counter = $now + $i;
            if (hash_equals(self::codeForCounter($secretBase32, $counter), $code)) {
                return $counter;
            }
        }
        return null;
    }
}
