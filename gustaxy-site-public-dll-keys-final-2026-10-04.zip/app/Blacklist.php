<?php
declare(strict_types=1);

final class Blacklist
{
    public static function isBlocked(string $deviceHash): bool
    {
        if ($deviceHash === '') {
            return false;
        }
        $stmt = db()->prepare('SELECT 1 FROM device_blocklist WHERE device_id_hash = ? AND unbanned_at IS NULL LIMIT 1');
        $stmt->execute([$deviceHash]);
        return (bool) $stmt->fetchColumn();
    }

    public static function recordIntegrity(
        int $apiKeyId,
        string $deviceHash,
        string $reason,
        string $appVersion,
        string $androidVersion,
        string $certificateSha256,
        string $eventNonce,
        int $threshold,
        bool $blacklistEnabled,
        bool $noticeEnabled,
        string $noticeTitle,
        string $noticeMessage,
        string $noticeImagePath
    ): array {
        $threshold = max(1, min($threshold, 20));
        $nonce = trim($eventNonce);
        if ($nonce === '' || strlen($nonce) > 128) {
            return ['accepted' => false, 'blocked' => false, 'tamper_count' => 0, 'notice' => null, 'registered' => false];
        }

        $pdo = db();
        $pdo->beginTransaction();
        try {
            // O evento precisa partir de uma key realmente vinculada ao mesmo device.
            $deviceStmt = $pdo->prepare('SELECT id FROM devices WHERE api_key_id = ? AND device_id_hash = ? AND revoked_at IS NULL LIMIT 1');
            $deviceStmt->execute([$apiKeyId, $deviceHash]);
            if (!$deviceStmt->fetch()) {
                $pdo->rollBack();
                return ['accepted' => false, 'blocked' => false, 'tamper_count' => 0, 'notice' => null, 'registered' => false];
            }

            $nonceHash = hash_hmac('sha256', $nonce, app_key());

            // Garante uma linha de estado e obtém lock por dispositivo antes de
            // incrementar o contador. Isso evita colisões em eventos simultâneos.
            if ((string) cfg('DB_DRIVER', 'mysql') !== 'sqlite') {
                $pdo->prepare('INSERT INTO device_security (device_id_hash, tamper_count, last_reason, last_seen_at, notice_shown_at, updated_at)
                    VALUES (?, 0, NULL, CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP)
                    ON DUPLICATE KEY UPDATE device_id_hash = VALUES(device_id_hash)')->execute([$deviceHash]);
                $secStmt = $pdo->prepare('SELECT * FROM device_security WHERE device_id_hash = ? FOR UPDATE');
            } else {
                $pdo->prepare('INSERT OR IGNORE INTO device_security (device_id_hash, tamper_count, last_reason, last_seen_at, notice_shown_at, updated_at)
                    VALUES (?, 0, NULL, CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP)')->execute([$deviceHash]);
                $secStmt = $pdo->prepare('SELECT * FROM device_security WHERE device_id_hash = ? LIMIT 1');
            }
            $secStmt->execute([$deviceHash]);
            $security = $secStmt->fetch();
            if (!$security) {
                throw new RuntimeException('Não foi possível preparar o estado de integridade do dispositivo.');
            }

            // Um mesmo lançamento do APK usa um nonce único. Repetir o mesmo
            // nonce nunca incrementa o contador duas vezes.
            $duplicate = $pdo->prepare('SELECT id FROM device_security_events WHERE device_id_hash = ? AND event_nonce_hash = ? LIMIT 1');
            $duplicate->execute([$deviceHash, $nonceHash]);
            if ($duplicate->fetch()) {
                $pdo->commit();
                $blocked = self::isBlockedWithinTransaction($pdo, $deviceHash);
                return [
                    'accepted' => false,
                    'blocked' => $blocked,
                    'tamper_count' => (int) $security['tamper_count'],
                    'notice' => null,
                    'registered' => true,
                ];
            }

            $event = $pdo->prepare('INSERT INTO device_security_events (device_id_hash, api_key_id, event_nonce_hash, reason, app_version, android_version, certificate_sha256, ip_address, user_agent, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
            $event->execute([
                $deviceHash,
                $apiKeyId,
                $nonceHash,
                mb_substr($reason, 0, 120),
                mb_substr($appVersion, 0, 32),
                mb_substr($androidVersion, 0, 32),
                mb_substr(normalize_fingerprint($certificateSha256), 0, 128),
                client_ip(),
                user_agent(),
            ]);

            $tamperCount = (int) $security['tamper_count'] + 1;
            $pdo->prepare('UPDATE device_security SET tamper_count = ?, last_reason = ?, last_seen_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE device_id_hash = ?')
                ->execute([$tamperCount, mb_substr($reason, 0, 120), $deviceHash]);

            $blocked = self::isBlockedWithinTransaction($pdo, $deviceHash);
            $notice = null;
            $autoBlockedNow = false;
            if ($tamperCount >= $threshold) {
                if (!$blocked && $blacklistEnabled) {
                    $reasonText = 'Bloqueado automaticamente após ' . $tamperCount . ' violações de integridade.';
                    self::upsertBlock($pdo, $deviceHash, $reasonText, 'automatic', null);
                    // Um blacklist global também precisa invalidar todos os tokens
                    // desse dispositivo, independentemente da key usada.
                    $pdo->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE device_id_hash = ? AND revoked_at IS NULL')
                        ->execute([$deviceHash]);
                    $blocked = true;
                    $autoBlockedNow = true;
                }

                $shouldShowNotice = $noticeEnabled && empty($security['notice_shown_at']);
                if ($shouldShowNotice) {
                    $notice = [
                        'title' => $noticeTitle !== '' ? $noticeTitle : 'Aplicativo modificado',
                        'message' => $noticeMessage !== '' ? $noticeMessage : 'Foi detectada uma alteração não autorizada neste aplicativo.',
                        'image_path' => $noticeImagePath,
                        'image_url' => self::publicAssetUrl($noticeImagePath),
                    ];
                    $pdo->prepare('UPDATE device_security SET notice_shown_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE device_id_hash = ?')
                        ->execute([$deviceHash]);
                }
            }

            $pdo->commit();
            audit('apk_integrity_report', null, 'device', substr($deviceHash, 0, 16), [
                'api_key_id' => $apiKeyId,
                'tamper_count' => $tamperCount,
                'blocked' => $blocked,
            ]);
            if ($autoBlockedNow) {
                audit('device_blacklisted', null, 'device', substr($deviceHash, 0, 16), [
                    'source' => 'automatic',
                    'tamper_count' => $tamperCount,
                ]);
            }
            return [
                'accepted' => false,
                'blocked' => $blocked,
                'tamper_count' => $tamperCount,
                'notice' => $notice,
                'registered' => true,
            ];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    private static function isBlockedWithinTransaction(PDO $pdo, string $deviceHash): bool
    {
        $stmt = $pdo->prepare('SELECT 1 FROM device_blocklist WHERE device_id_hash = ? AND unbanned_at IS NULL LIMIT 1');
        $stmt->execute([$deviceHash]);
        return (bool) $stmt->fetchColumn();
    }

    private static function upsertBlock(PDO $pdo, string $deviceHash, string $reason, string $source, ?int $actorId): void
    {
        if ((string) cfg('DB_DRIVER', 'mysql') === 'sqlite') {
            $sql = 'INSERT INTO device_blocklist (device_id_hash, reason, source, actor_user_id, banned_at, unbanned_at, unbanned_by)
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, NULL, NULL)
                ON CONFLICT(device_id_hash) DO UPDATE SET
                    reason = excluded.reason,
                    source = excluded.source,
                    actor_user_id = excluded.actor_user_id,
                    banned_at = CURRENT_TIMESTAMP,
                    unbanned_at = NULL,
                    unbanned_by = NULL';
        } else {
            $sql = 'INSERT INTO device_blocklist (device_id_hash, reason, source, actor_user_id, banned_at, unbanned_at, unbanned_by)
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, NULL, NULL)
                ON DUPLICATE KEY UPDATE
                    reason = VALUES(reason),
                    source = VALUES(source),
                    actor_user_id = VALUES(actor_user_id),
                    banned_at = CURRENT_TIMESTAMP,
                    unbanned_at = NULL,
                    unbanned_by = NULL';
        }
        $pdo->prepare($sql)->execute([$deviceHash, $reason, $source, $actorId]);
    }

    public static function banDevice(int $deviceRowId, int $actorId, string $reason = ''): void
    {
        $stmt = db()->prepare('SELECT device_id_hash FROM devices WHERE id = ? LIMIT 1');
        $stmt->execute([$deviceRowId]);
        $row = $stmt->fetch();
        if (!$row) {
            throw new RuntimeException('Dispositivo não encontrado.');
        }
        self::banHash((string) $row['device_id_hash'], $actorId, $reason !== '' ? $reason : 'Bloqueio manual pelo painel.');
    }

    public static function banHash(string $deviceHash, int $actorId, string $reason = ''): void
    {
        $deviceHash = trim($deviceHash);
        if (!preg_match('/^[a-f0-9]{64}$/i', $deviceHash)) {
            throw new InvalidArgumentException('Identificador de dispositivo inválido.');
        }
        $pdo = db();
        $reason = mb_substr(trim($reason), 0, 255);
        if ($reason === '') {
            $reason = 'Bloqueio manual pelo painel.';
        }
        $pdo->beginTransaction();
        try {
            self::upsertBlock($pdo, $deviceHash, $reason, 'manual', $actorId);
            $pdo->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE device_id_hash = ? AND revoked_at IS NULL')->execute([$deviceHash]);
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        audit('device_blacklisted', $actorId, 'device', substr($deviceHash, 0, 16), ['source' => 'manual']);
    }

    public static function unbanHash(string $deviceHash, int $actorId): void
    {
        $deviceHash = trim($deviceHash);
        if (!preg_match('/^[a-f0-9]{64}$/i', $deviceHash)) {
            throw new InvalidArgumentException('Identificador de dispositivo inválido.');
        }
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('UPDATE device_blocklist SET unbanned_at = CURRENT_TIMESTAMP, unbanned_by = ? WHERE device_id_hash = ? AND unbanned_at IS NULL');
            $stmt->execute([$actorId, $deviceHash]);
            $pdo->prepare('UPDATE device_security SET tamper_count = 0, notice_shown_at = NULL, updated_at = CURRENT_TIMESTAMP WHERE device_id_hash = ?')->execute([$deviceHash]);
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        audit('device_unblacklisted', $actorId, 'device', substr($deviceHash, 0, 16));
    }

    public static function activeList(): array
    {
        return db()->query("SELECT b.id, b.device_id_hash, b.reason, b.source, b.banned_at,
            COALESCE((SELECT MAX(d.device_name) FROM devices d WHERE d.device_id_hash = b.device_id_hash), 'Desconhecido') AS device_name,
            (SELECT COUNT(*) FROM devices d WHERE d.device_id_hash = b.device_id_hash) AS key_count,
            COALESCE((SELECT s.tamper_count FROM device_security s WHERE s.device_id_hash = b.device_id_hash LIMIT 1), 0) AS tamper_count
            FROM device_blocklist b
            WHERE b.unbanned_at IS NULL
            ORDER BY b.banned_at DESC")->fetchAll();
    }

    public static function knownDevices(): array
    {
        return db()->query("SELECT d.id, d.device_id_hash, d.device_name, d.app_version, d.android_version,
            d.first_seen_at, d.last_seen_at, k.key_prefix
            FROM devices d
            JOIN api_keys k ON k.id = d.api_key_id
            WHERE d.revoked_at IS NULL
              AND NOT EXISTS (SELECT 1 FROM device_blocklist b WHERE b.device_id_hash = d.device_id_hash AND b.unbanned_at IS NULL)
            ORDER BY d.last_seen_at DESC
            LIMIT 200")->fetchAll();
    }

    private static function publicAssetUrl(string $path): string
    {
        $path = trim($path);
        if ($path === '') {
            return '';
        }
        if (str_starts_with($path, 'data:image/')) {
            return $path;
        }
        $base = rtrim((string) cfg('APP_URL', ''), '/');
        $base = (string) preg_replace('~/api/v1$~i', '', $base);
        $baseHost = strtolower((string) parse_url($base, PHP_URL_HOST));
        if (preg_match('~^https://([^/]+)(/.*)?$~i', $path, $m)) {
            $host = strtolower($m[1]);
            if ($baseHost !== '' && !hash_equals($baseHost, $host)) {
                return '';
            }
            return $path;
        }
        if (str_starts_with($path, '//') || preg_match('~^[a-z][a-z0-9+.-]*:~i', $path)) {
            return '';
        }
        return $base !== '' ? $base . '/' . ltrim($path, '/') : '/' . ltrim($path, '/');
    }
}
