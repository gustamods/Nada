<?php
declare(strict_types=1);

final class UserAdmin
{
    private const CREATABLE_ROLES = ['admin', 'reseller'];

    public static function roleLabel(string $role): string
    {
        return match ($role) {
            'owner' => 'Criador',
            'admin' => 'Administrador',
            'reseller' => 'Revendedor',
            default => $role,
        };
    }

    public static function createStaff(string $username, string $password, string $role, bool $active, int $actorId): int
    {
        $username = trim($username);
        $role = trim($role);

        if (!in_array($role, self::CREATABLE_ROLES, true)) {
            throw new InvalidArgumentException('Papel inválido.');
        }
        if ($role === 'reseller') {
            throw new InvalidArgumentException('Use o formulário de revendedor para criar revendedores.');
        }
        if (!preg_match('/^[A-Za-z0-9@._-]{3,190}$/', $username)) {
            throw new InvalidArgumentException('Nome de usuário inválido. Use 3 a 190 caracteres entre letras, números, ponto, hífen, underline ou arroba.');
        }
        if (strlen($password) < 12) {
            throw new InvalidArgumentException('A senha deve ter pelo menos 12 caracteres.');
        }

        $pdo = db();
        $exists = $pdo->prepare('SELECT id FROM admin_users WHERE username = ? LIMIT 1');
        $exists->execute([$username]);
        if ($exists->fetch()) {
            throw new InvalidArgumentException('Este usuário já existe.');
        }

        $algorithm = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
        $insert = $pdo->prepare('INSERT INTO admin_users (username, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)');
        $insert->execute([$username, password_hash($password, $algorithm), $role, $active ? 1 : 0]);
        $id = (int) $pdo->lastInsertId();

        audit('admin_user_created', $actorId, 'admin_user', (string) $id, [
            'username' => $username,
            'role' => $role,
            'active' => $active,
        ]);

        return $id;
    }

    public static function listStaff(): array
    {
        return db()->query(
            "SELECT u.id, u.username, u.role, u.is_active, u.created_at, u.last_login_at,
                    u.totp_confirmed_at,
                    (SELECT COUNT(*) FROM api_keys k WHERE k.created_by = u.id) AS keys_created
             FROM admin_users u
             WHERE u.role IN ('owner', 'admin')
             ORDER BY (u.role = 'owner') DESC, u.id ASC"
        )->fetchAll();
    }

    public static function find(int $userId): ?array
    {
        $stmt = db()->prepare('SELECT id, username, role, is_active FROM admin_users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function setActive(int $userId, bool $active, array $actor): void
    {
        $actorId = (int) $actor['id'];

        if ($userId === $actorId) {
            throw new InvalidArgumentException('Você não pode banir a própria conta.');
        }

        $target = self::find($userId);
        if (!$target) {
            throw new InvalidArgumentException('Conta não encontrada.');
        }
        if ((string) $target['role'] === 'owner') {
            throw new InvalidArgumentException('A conta de criador não pode ser banida pelo painel.');
        }

        $desired = $active ? 1 : 0;
        if ((int) $target['is_active'] === $desired) {
            return;
        }

        db()->prepare('UPDATE admin_users SET is_active = ? WHERE id = ?')->execute([$desired, $userId]);

        audit($active ? 'admin_user_unbanned' : 'admin_user_banned', $actorId, 'admin_user', (string) $userId, [
            'username' => (string) $target['username'],
            'role' => (string) $target['role'],
        ]);
    }

    public static function resetPassword(int $userId, string $password, array $actor): void
    {
        if (strlen($password) < 12) {
            throw new InvalidArgumentException('A senha deve ter pelo menos 12 caracteres.');
        }

        $target = self::find($userId);
        if (!$target) {
            throw new InvalidArgumentException('Conta não encontrada.');
        }
        if ((string) $target['role'] === 'owner' && (int) $target['id'] !== (int) $actor['id']) {
            throw new InvalidArgumentException('A senha de outro criador não pode ser alterada aqui.');
        }

        $algorithm = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
        db()->prepare('UPDATE admin_users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?')
            ->execute([password_hash($password, $algorithm), $userId]);

        audit('admin_password_reset_by_owner', (int) $actor['id'], 'admin_user', (string) $userId, [
            'username' => (string) $target['username'],
        ]);
    }
}
