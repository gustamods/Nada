<?php
declare(strict_types=1);

final class Api
{
    private static function maintenancePayload(array $maintenance): array
    {
        $path = trim((string) ($maintenance['image_path'] ?? ''));
        $maintenance['image_url'] = self::publicAssetUrl($path);
        return $maintenance;
    }

    private static function publicAssetUrl(string $path): string
    {
        if ($path === '') {
            return '';
        }
        if (str_starts_with($path, 'data:image/')) {
            return $path;
        }
        $base = rtrim((string) cfg('APP_URL', ''), '/');
        $base = (string) preg_replace('~/api/v1$~i', '', $base);
        $baseHost = strtolower((string) parse_url($base, PHP_URL_HOST));
        if (preg_match('~^https://([^/]+)(/.*)?$~i', $path, $m)) {
            $host = strtolower($m[1]);
            if ($baseHost !== '' && !hash_equals($baseHost, $host)) {
                return '';
            }
            return $path;
        }
        if (str_starts_with($path, '//') || preg_match('~^[a-z][a-z0-9+.-]*:~i', $path)) {
            return '';
        }
        return $base !== '' ? $base . '/' . ltrim($path, '/') : '/' . ltrim($path, '/');
    }

    public static function config(): never
    {
        if (!rate_limit('public-config', 60, 60)) {
            json_response(['error' => 'Muitas solicitações.'], 429);
        }
        $maintenance = self::maintenancePayload(Settings::maintenance());
        json_response([
            'maintenance' => $maintenance,
            'keys_paused' => Settings::keysPaused(),
        ]);
    }

    public static function update(array $query): never
    {
        if (!rate_limit('public-update', 30, 60)) {
            json_response(['error' => 'Muitas solicitações.'], 429);
        }
        $rawCode = $query['version_code'] ?? null;
        $clientVersionCode = is_scalar($rawCode) ? filter_var((string) $rawCode, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 2000000000]]) : null;
        $clientVersionCode = $clientVersionCode === false ? null : $clientVersionCode;
        json_response(UpdateService::publicPayload($clientVersionCode));
    }

    public static function login(array $input): never
    {
        self::requireClientApp();
        self::requireRequestNonce('auth/login');
        if (!rate_limit('api-login', 20, 60)) {
            json_response(['error' => 'Não foi possível concluir a solicitação agora.'], 429);
        }
        $rawKey = trim((string) ($input['key'] ?? ''));
        $deviceId = trim((string) ($input['device_id'] ?? ''));
        $deviceName = mb_substr(trim((string) ($input['device_name'] ?? 'Android')), 0, 120);
        $appVersion = mb_substr(trim((string) ($input['app_version'] ?? '')), 0, 32);
        $androidVersion = mb_substr(trim((string) ($input['android_version'] ?? '')), 0, 32);
        if ($deviceId === '' || strlen($deviceId) < 8 || strlen($deviceId) > 256) {
            json_response(['error' => 'Credenciais inválidas.'], 401);
        }
        $deviceHash = KeyService::deviceHash($deviceId);
        if (Blacklist::isBlocked($deviceHash)) {
            self::logApiLogin(null, $deviceHash, false);
            json_response(['error' => 'Dispositivo bloqueado.'], 403);
        }
        $maintenance = self::maintenancePayload(Settings::maintenance());
        if ($maintenance['enabled']) {
            json_response(['error' => 'Aplicativo em manutenção.', 'maintenance' => $maintenance], 503);
        }
        $certificateSha256 = normalize_fingerprint((string) ($input['cert_sha256'] ?? ''));
        $expectedCertificate = normalize_fingerprint((string) cfg('EXPECTED_CERT_SHA256', ''));
        if ($expectedCertificate !== '' && !hash_equals($expectedCertificate, $certificateSha256)) {
            self::logApiLogin(null, KeyService::deviceHash($deviceId), false);
            json_response(['error' => 'Aplicativo não autorizado.'], 403);
        }
        if ($rawKey === '' || strlen($rawKey) > 256) {
            json_response(['error' => 'Credenciais inválidas.'], 401);
        }
        $keyHash = KeyService::fingerprint($rawKey);

        if (!rate_limit('api-login-device-' . substr($deviceHash, 0, 16), 30, 300)) {
            self::logApiLogin(null, $deviceHash, false);
            json_response(['error' => 'Muitas tentativas neste dispositivo.'], 429);
        }

        $stmt = db()->prepare('SELECT * FROM api_keys WHERE key_hash = ? LIMIT 1');
        $stmt->execute([$keyHash]);
        $key = $stmt->fetch();
        if (!$key) {
            usleep(random_int(100000, 300000));
            self::logApiLogin(null, $deviceHash, false);
            json_response(['error' => 'Credenciais inválidas.'], 401);
        }
        if (Settings::keysPaused() || $key['status'] === 'paused') {
            self::logApiLogin((int) $key['id'], $deviceHash, false);
            json_response(['error' => 'Acesso temporariamente pausado.'], 423);
        }
        if ($key['status'] !== 'active' || strtotime((string) $key['expires_at']) <= time()) {
            self::logApiLogin((int) $key['id'], $deviceHash, false);
            json_response(['error' => 'Credenciais expiradas ou desativadas.'], 401);
        }

        $pdo = db();
        $pdo->beginTransaction();
        $deviceBlocked = false;
        $limitReached = false;
        try {
            if ((string) cfg('DB_DRIVER', 'mysql') !== 'sqlite') {
                $pdo->prepare('SELECT id FROM api_keys WHERE id = ? FOR UPDATE')->execute([(int) $key['id']]);
            }
            $existing = $pdo->prepare('SELECT * FROM devices WHERE api_key_id = ? AND device_id_hash = ? LIMIT 1');
            $existing->execute([(int) $key['id'], $deviceHash]);
            $device = $existing->fetch();

            if ($device && !empty($device['revoked_at'])) {
                $deviceBlocked = true;
            } elseif (!$device) {
                $count = $pdo->prepare('SELECT COUNT(*) FROM devices WHERE api_key_id = ? AND revoked_at IS NULL');
                $count->execute([(int) $key['id']]);
                if ((int) $count->fetchColumn() >= (int) $key['max_devices']) {
                    $limitReached = true;
                } else {
                    $insert = $pdo->prepare('INSERT INTO devices (api_key_id, device_id_hash, device_name, app_version, android_version, first_seen_at, last_seen_at, login_count) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1)');
                    $insert->execute([(int) $key['id'], $deviceHash, $deviceName, $appVersion, $androidVersion]);
                }
            } else {
                $update = $pdo->prepare('UPDATE devices SET device_name = ?, app_version = ?, android_version = ?, last_seen_at = CURRENT_TIMESTAMP, login_count = login_count + 1 WHERE id = ?');
                $update->execute([$deviceName, $appVersion, $androidVersion, (int) $device['id']]);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        if ($deviceBlocked) {
            json_response(['error' => 'Dispositivo não autorizado.'], 403);
        }
        if ($limitReached) {
            self::logApiLogin((int) $key['id'], $deviceHash, false);
            json_response(['error' => 'Limite de dispositivos atingido.'], 403);
        }

        $token = random_token(48);
        $tokenHash = hash_hmac('sha256', $token, app_key());
        $ttl = min((int) cfg('API_TOKEN_TTL', 86400), max(60, strtotime((string) $key['expires_at']) - time()));
        $expires = gmdate('Y-m-d H:i:s', time() + $ttl);
        $insertToken = db()->prepare('INSERT INTO api_tokens (token_hash, api_key_id, device_id_hash, expires_at, created_at, last_seen_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)');
        $insertToken->execute([$tokenHash, (int) $key['id'], $deviceHash, $expires]);
        self::logApiLogin((int) $key['id'], $deviceHash, true);
        audit('api_login_success', null, 'api_key', (string) $key['id'], ['device_hash_prefix' => substr($deviceHash, 0, 12)]);
        json_response(['token' => $token, 'expires_at' => $expires, 'key_expires_at' => $key['expires_at'], 'device_limit' => (int) $key['max_devices']]);
    }

    public static function integrityReport(array $input): never
    {
        self::requireClientApp();
        self::requireRequestNonce('integrity/report');
        if (!rate_limit('api-integrity-report', 12, 300)) {
            json_response(['error' => 'Muitas ocorrências em sequência.'], 429);
        }
        $rawKey = trim((string) ($input['key'] ?? ''));
        $deviceId = trim((string) ($input['device_id'] ?? ''));
        $reason = mb_substr(trim((string) ($input['reason'] ?? 'integrity_failure')), 0, 120);
        $appVersion = mb_substr(trim((string) ($input['app_version'] ?? '')), 0, 32);
        $androidVersion = mb_substr(trim((string) ($input['android_version'] ?? '')), 0, 32);
        $certificateSha256 = normalize_fingerprint((string) ($input['cert_sha256'] ?? ''));
        $eventNonce = trim((string) ($input['event_nonce'] ?? ''));
        if ($rawKey === '' || strlen($rawKey) > 256 || strlen($deviceId) < 8 || strlen($deviceId) > 256) {
            json_response(['error' => 'Solicitação inválida.'], 400);
        }
        $deviceHash = KeyService::deviceHash($deviceId);
        if (!rate_limit('api-integrity-device-' . substr($deviceHash, 0, 16), 6, 300)) {
            json_response(['error' => 'Muitas ocorrências neste dispositivo.'], 429);
        }
        if (Blacklist::isBlocked($deviceHash)) {
            json_response(['accepted' => false, 'blocked' => true, 'tamper_count' => 0, 'notice' => null]);
        }
        $keyHash = KeyService::fingerprint($rawKey);
        $stmt = db()->prepare('SELECT id, status, expires_at FROM api_keys WHERE key_hash = ? LIMIT 1');
        $stmt->execute([$keyHash]);
        $key = $stmt->fetch();
        if (!$key || $key['status'] !== 'active' || strtotime((string) $key['expires_at']) <= time()) {
            json_response(['error' => 'Solicitação não autorizada.'], 403);
        }

        // Uma ocorrência de integridade só pode ser registrada para o par
        // key + dispositivo que já existe no servidor. Isso impede que um
        // cliente invente um device_id e manipule o contador de outro device.
        $binding = db()->prepare('SELECT 1 FROM devices WHERE api_key_id = ? AND device_id_hash = ? AND revoked_at IS NULL LIMIT 1');
        $binding->execute([(int) $key['id'], $deviceHash]);
        if (!$binding->fetchColumn()) {
            json_response(['error' => 'Dispositivo não registrado.'], 403);
        }

        $noticeMode = (string) Settings::get('tamper_notice_mode', 'automatic');
        $noticeEnabled = (string) Settings::get('tamper_notice_enabled', '0') === '1';
        $blacklistEnabled = (string) Settings::get('tamper_blacklist_enabled', '1') === '1';
        $threshold = max(1, min(20, (int) Settings::get('tamper_blacklist_threshold', '3')));
        $title = $noticeMode === 'manual' ? trim((string) Settings::get('tamper_notice_title', '')) : 'Aplicativo modificado';
        $message = $noticeMode === 'manual' ? trim((string) Settings::get('tamper_notice_description', '')) : 'Foi detectada uma alteração não autorizada neste aplicativo.';
        $imagePath = trim((string) Settings::get('tamper_notice_image_path', ''));
        $result = Blacklist::recordIntegrity(
            (int) $key['id'],
            $deviceHash,
            $reason,
            $appVersion,
            $androidVersion,
            $certificateSha256,
            $eventNonce,
            $threshold,
            $blacklistEnabled,
            $noticeEnabled,
            $title,
            $message,
            $imagePath
        );
        if (!empty($result['notice'])) {
            $notice = $result['notice'];
            // Só devolve ao APK o caminho que já foi salvo pelo painel.
            json_response([
                'accepted' => false,
                'blocked' => (bool) $result['blocked'],
                'tamper_count' => (int) $result['tamper_count'],
                'notice' => [
                    'title' => (string) $notice['title'],
                    'message' => (string) $notice['message'],
                    'image_url' => (string) $notice['image_url'],
                ],
            ]);
        }
        json_response([
            'accepted' => false,
            'blocked' => (bool) $result['blocked'],
            'tamper_count' => (int) $result['tamper_count'],
            'notice' => null,
        ]);
    }

    public static function current(): never
    {
        $session = self::bearer();
        json_response(['authenticated' => true, 'key_expires_at' => $session['key']['expires_at'], 'device_id' => substr($session['token']['device_id_hash'], 0, 12), 'keys_paused' => Settings::keysPaused()]);
    }

    public static function resourceManifest(): never
    {
        self::requireClientApp();
        self::requireRequestNonce('resources/manifest');
        if (!rate_limit('public-resource-manifest', 30, 60)) {
            json_response(['error' => 'Muitas solicitações.'], 429);
        }
        $deviceId = trim((string) ($_SERVER['HTTP_X_GUSTAXY_DEVICE'] ?? ''));
        if ($deviceId === '' || strlen($deviceId) < 8 || strlen($deviceId) > 256) {
            json_response(['error' => 'Dispositivo inválido.'], 400);
        }
        $certificateSha256 = normalize_fingerprint((string) ($_SERVER['HTTP_X_GUSTAXY_CERT'] ?? ''));
        $expectedCertificate = normalize_fingerprint((string) cfg('EXPECTED_CERT_SHA256', ''));
        if ($expectedCertificate !== '' && !hash_equals($expectedCertificate, $certificateSha256)) {
            json_response(['error' => 'Aplicativo não autorizado.'], 403);
        }
        $deviceHash = KeyService::deviceHash($deviceId);
        json_response(ResourceVaultService::manifestPayload($deviceHash, $certificateSha256));
    }

    public static function resourceDownload(array $query): never
    {
        self::requireClientApp();
        self::requireRequestNonce('resources/download');
        if (!rate_limit('resource-download-' . (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 20, 60)) {
            json_response(['error' => 'Muitas solicitações.'], 429);
        }
        $ticket = trim((string) ($query['ticket'] ?? ''));
        $deviceId = trim((string) ($_SERVER['HTTP_X_GUSTAXY_DEVICE'] ?? ''));
        if ($ticket === '' || $deviceId === '') {
            json_response(['error' => 'Solicitação inválida.'], 400);
        }
        $certificateSha256 = normalize_fingerprint((string) ($_SERVER['HTTP_X_GUSTAXY_CERT'] ?? ''));
        $expectedCertificate = normalize_fingerprint((string) cfg('EXPECTED_CERT_SHA256', ''));
        if ($expectedCertificate !== '' && !hash_equals($expectedCertificate, $certificateSha256)) {
            json_response(['error' => 'Aplicativo não autorizado.'], 403);
        }
        $status = ResourceVaultService::verifyTicket($ticket, KeyService::deviceHash($deviceId), $certificateSha256);
        if ($status === null) {
            json_response(['error' => 'Download não autorizado.'], 403);
        }
        $file = (string) $status['file'];
        if (!is_file($file) || !is_readable($file)) {
            json_response(['error' => 'Recurso indisponível.'], 404);
        }
        $size = (int) filesize($file);
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="gx-resource.bin"');
        header('Cache-Control: private, no-store, no-cache, max-age=0');
        header('Pragma: no-cache');
        header('X-Content-Type-Options: nosniff');
        header('X-Gustaxy-Resource-SHA256: ' . (string) $status['sha256']);
        header('X-Gustaxy-Resource-Version: ' . (int) $status['version']);
        header('Accept-Ranges: bytes');
        $start = 0;
        $end = max(0, $size - 1);
        $range = (string) ($_SERVER['HTTP_RANGE'] ?? '');
        if ($range !== '' && preg_match('/^bytes=(\d*)-(\d*)$/', trim($range), $m)) {
            if ($m[1] === '' && $m[2] === '') {
                json_response(['error' => 'Faixa inválida.'], 416);
            }
            if ($m[1] === '') {
                $suffix = (int) $m[2];
                if ($suffix <= 0) json_response(['error' => 'Faixa inválida.'], 416);
                $start = max(0, $size - $suffix);
            } else {
                $start = (int) $m[1];
                if ($start >= $size) {
                    header('Content-Range: bytes */' . $size);
                    json_response(['error' => 'Faixa fora do arquivo.'], 416);
                }
                if ($m[2] !== '') $end = min($size - 1, (int) $m[2]);
            }
            if ($end < $start) {
                header('Content-Range: bytes */' . $size);
                json_response(['error' => 'Faixa inválida.'], 416);
            }
            http_response_code(206);
            header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
        }
        $length = $end - $start + 1;
        header('Content-Length: ' . $length);
        $handle = fopen($file, 'rb');
        if ($handle === false) {
            json_response(['error' => 'Recurso indisponível.'], 503);
        }
        if ($start > 0) fseek($handle, $start);
        while (!feof($handle) && $length > 0) {
            $chunk = fread($handle, (int) min(1048576, $length));
            if ($chunk === false || $chunk === '') break;
            echo $chunk;
            $length -= strlen($chunk);
            if (function_exists('flush')) flush();
        }
        fclose($handle);
        exit;
    }

    public static function integrationStatus(): never
    {
        $user = self::integrationActor('read');
        $release = UpdateService::active();
        $resource = ResourceVaultService::status();
        json_response([
            'ok' => true,
            'actor' => ['id' => (int) $user['id'], 'username' => (string) $user['username'], 'role' => (string) $user['role']],
            'maintenance' => Settings::maintenance()['enabled'] ?? false,
            'keys_paused' => Settings::keysPaused(),
            'update' => $release ? ['version' => (string) $release['version'], 'version_code' => (int) $release['version_code'], 'active' => true] : ['active' => false],
            'resource' => ['available' => (bool) $resource['available'], 'version' => (int) $resource['version'], 'size_bytes' => (int) $resource['size_bytes'], 'sha256' => (string) $resource['sha256']],
        ]);
    }

    public static function integrationKeysGenerate(array $input): never
    {
        $user = self::integrationActor('keys.generate');
        $quantity = filter_var($input['quantity'] ?? 1, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 500]]);
        $maxDevices = filter_var($input['max_devices'] ?? 1, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 50]]);
        $amount = filter_var($input['amount'] ?? 1, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 8760]]);
        $unit = trim((string) ($input['unit'] ?? 'days'));
        $prefix = trim((string) ($input['prefix'] ?? ''));
        if ($quantity === false || $maxDevices === false || $amount === false || !in_array($unit, ['hours', 'days', 'weeks', 'months', 'years'], true)) {
            json_response(['error' => 'Parâmetros inválidos.'], 400);
        }
        try {
            $result = KeyService::generate((int) $quantity, (int) $maxDevices, (int) $amount, $unit, (int) $user['id'], $prefix);
        } catch (Throwable $e) {
            json_response(['error' => $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível gerar as keys.'], 422);
        }
        json_response([
            'ok' => true,
            'keys' => $result['keys'],
            'ids' => $result['ids'],
            'prefix' => $result['prefix'],
            'expires_at' => $result['expires_at'],
            'max_devices' => $result['max_devices'],
            'started_paused' => $result['started_paused'],
        ]);
    }

    public static function integrationKeysList(): never
    {
        self::integrationActor('read');
        if (!rate_limit('integration-key-list', 30, 60)) json_response(['error' => 'Muitas solicitações.'], 429);
        $rows = db()->query("SELECT id, key_prefix, max_devices, expires_at, status, created_at FROM api_keys ORDER BY id DESC LIMIT 100")->fetchAll();
        json_response(['ok' => true, 'keys' => array_map(static function(array $row): array { return [
            'id' => (int) $row['id'],
            'prefix' => (string) $row['key_prefix'],
            'max_devices' => (int) $row['max_devices'],
            'expires_at' => (string) $row['expires_at'],
            'status' => (string) $row['status'],
            'created_at' => (string) $row['created_at'],
        ]; }, $rows)]);
    }

    public static function integrationKeyAction(array $input, string $action, string $scope): never
    {
        $user = self::integrationActor($scope);
        $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false) json_response(['error' => 'ID da key inválido.'], 400);
        try {
            switch ($action) {
                case 'pause': KeyService::pause((int) $id, (int) $user['id']); break;
                case 'resume': KeyService::resume((int) $id, (int) $user['id']); break;
                case 'revoke': KeyService::revoke((int) $id, (int) $user['id']); break;
                case 'reset_device': KeyService::resetDevice((int) $id, (int) $user['id']); break;
                case 'reset_key': KeyService::resetKey((int) $id, (int) $user['id']); break;
                case 'delete_key': KeyService::delete((int) $id, (int) $user['id']); break;
                default: json_response(['error' => 'Ação inválida.'], 400);
            }
        } catch (Throwable $e) {
            json_response(['error' => $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível concluir a ação.'], 422);
        }
        json_response(['ok' => true, 'id' => (int) $id, 'action' => $action]);
    }

    public static function integrationGlobalKeys(array $input, bool $pause): never
    {
        $user = self::integrationActor('keys.manage');
        if ((string) ($user['role'] ?? '') !== 'owner') json_response(['error' => 'Somente o owner pode alterar a pausa global.'], 403);
        try {
            if ($pause) Settings::pauseAll((int) $user['id']); else Settings::resumeAll((int) $user['id']);
        } catch (Throwable $e) {
            json_response(['error' => $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível alterar a pausa global.'], 422);
        }
        json_response(['ok' => true, 'keys_paused' => $pause]);
    }

    public static function integrationUpdatePublish(array $input): never
    {
        $user = self::integrationActor('updates.publish');
        if ((string) ($user['role'] ?? '') !== 'owner') json_response(['error' => 'Somente o owner pode publicar atualizações.'], 403);
        $name = mb_substr(trim((string) ($input['name'] ?? '')), 0, 120);
        $version = mb_substr(trim((string) ($input['version'] ?? '')), 0, 32);
        $versionCode = filter_var($input['version_code'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 2000000000]]);
        $url = trim((string) ($input['download_url'] ?? ''));
        $sha256 = trim((string) ($input['sha256'] ?? ''));
        $sizeText = trim((string) ($input['size_bytes'] ?? ''));
        $sizeBytes = $sizeText === '' ? null : filter_var($sizeText, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 524288000]]);
        if ($name === '' || $version === '' || $versionCode === false || ($sizeText !== '' && $sizeBytes === false)) json_response(['error' => 'Metadados inválidos.'], 400);
        try {
            UpdateService::publish($name, $version, (int) $versionCode, $url, $sha256, $sizeBytes === false ? null : $sizeBytes, (int) $user['id']);
        } catch (Throwable $e) {
            json_response(['error' => $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível publicar a atualização.'], 422);
        }
        json_response(['ok' => true, 'message' => 'Atualização publicada.']);
    }

    public static function integrationResourcePublish(array $input): never
    {
        $user = self::integrationActor('resources.publish');
        if ((string) ($user['role'] ?? '') !== 'owner') json_response(['error' => 'Somente o owner pode publicar o BIN.'], 403);
        $url = trim((string) ($input['url'] ?? $input['download_url'] ?? ''));
        if ($url === '') json_response(['error' => 'Informe a URL do BIN.'], 400);
        try {
            $result = ResourceVaultService::importFromUrl($url, (int) $user['id']);
        } catch (Throwable $e) {
            json_response(['error' => $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível publicar o BIN.'], 422);
        }
        json_response(['ok' => true, 'version' => (int) $result['version'], 'sha256' => (string) $result['sha256'], 'size_bytes' => (int) $result['size_bytes']]);
    }

    private static function integrationActor(string $scope): array
    {
        $token = IntegrationTokenService::extractToken();
        $integration = IntegrationTokenService::authenticate($token, $scope);
        $stmt = db()->prepare('SELECT id, username, role, is_active FROM admin_users WHERE id = ? LIMIT 1');
        $stmt->execute([(int) ($integration['created_by'] ?? 0)]);
        $user = $stmt->fetch();
        if (!$user || (int) $user['is_active'] !== 1 || !in_array((string) $user['role'], ['owner', 'admin'], true)) {
            json_response(['error' => 'Conta do token não autorizada.'], 401);
        }
        return $user;
    }

    public static function logout(): never
    {
        self::requireClientApp();
        self::requireRequestNonce('auth/logout');
        $session = self::bearer();
        db()->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([(int) $session['token']['id']]);
        audit('api_logout', null, 'api_key', (string) $session['key']['id']);
        json_response(['ok' => true]);
    }

    private static function bearer(): array
    {
        self::requireClientApp();
        if (!rate_limit('api-request', 120, 60)) {
            json_response(['error' => 'Muitas solicitações.'], 429);
        }
        $header = (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? '');
        if (!preg_match('/^Bearer\s+([A-Za-z0-9_\-]+)$/', $header, $m)) {
            json_response(['error' => 'Não autenticado.'], 401);
        }
        $hash = hash_hmac('sha256', $m[1], app_key());
        $stmt = db()->prepare('SELECT t.*, k.expires_at AS key_expires_at, k.status AS key_status FROM api_tokens t JOIN api_keys k ON k.id = t.api_key_id WHERE t.token_hash = ? AND t.revoked_at IS NULL LIMIT 1');
        $stmt->execute([$hash]);
        $token = $stmt->fetch();
        if (!$token || strtotime((string) $token['expires_at']) <= time() || $token['key_status'] !== 'active' || strtotime((string) $token['key_expires_at']) <= time() || Settings::keysPaused() || Blacklist::isBlocked((string) $token['device_id_hash'])) {
            json_response(['error' => 'Não autenticado.'], 401);
        }

        $rawDevice = trim((string) ($_SERVER['HTTP_X_GUSTAXY_DEVICE'] ?? ''));
        if ($rawDevice === '' || strlen($rawDevice) > 256 || !hash_equals((string) $token['device_id_hash'], KeyService::deviceHash($rawDevice))) {
            json_response(['error' => 'Dispositivo não autorizado.'], 401);
        }

        $deviceStmt = db()->prepare('SELECT 1 FROM devices WHERE api_key_id = ? AND device_id_hash = ? AND revoked_at IS NULL LIMIT 1');
        $deviceStmt->execute([(int) $token['api_key_id'], (string) $token['device_id_hash']]);
        if (!$deviceStmt->fetchColumn()) {
            db()->prepare('UPDATE api_tokens SET revoked_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([(int) $token['id']]);
            json_response(['error' => 'Dispositivo não registrado.'], 401);
        }

        db()->prepare('UPDATE api_tokens SET last_seen_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([(int) $token['id']]);
        $key = ['id' => $token['api_key_id'], 'expires_at' => $token['key_expires_at']];
        return ['token' => $token, 'key' => $key];
    }

    private static function requireRequestNonce(string $scope): void
    {
        $nonce = trim((string) ($_SERVER['HTTP_X_REQUEST_NONCE'] ?? ''));
        $timestampRaw = trim((string) ($_SERVER['HTTP_X_GUSTAXY_TIMESTAMP'] ?? ''));
        if ($nonce === '' || !preg_match('/^[A-Za-z0-9._:-]{16,128}$/', $nonce) || !ctype_digit($timestampRaw)) {
            json_response(['error' => 'Solicitação inválida.'], 400);
        }
        $timestamp = (int) $timestampRaw;
        if (abs(time() - $timestamp) > 300) {
            json_response(['error' => 'Solicitação expirada.'], 408);
        }
        if (!consume_request_nonce($scope, $nonce, 300)) {
            json_response(['error' => 'Solicitação repetida.'], 409);
        }
    }

    private static function requireClientApp(): void
    {
        $identity = trim((string) ($_SERVER['HTTP_X_GUSTAXY_APP'] ?? ''));
        // DEBUG acrescenta `.debug`; release usa exatamente o applicationId.
        if ($identity !== 'com.gustaxy.android' && $identity !== 'com.gustaxy.android.debug') {
            json_response(['error' => 'Aplicativo não autorizado.'], 403);
        }
    }

    private static function logApiLogin(?int $keyId, string $deviceHash, bool $success): void
    {
        $ctx = client_context();
        $stmt = db()->prepare('INSERT INTO login_logs (api_key_id, device_id_hash, success, browser, operating_system, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
        $stmt->execute([$keyId, $deviceHash, $success ? 1 : 0, $ctx['browser'], $ctx['os'], $ctx['ip'], $ctx['user_agent']]);
    }
}
