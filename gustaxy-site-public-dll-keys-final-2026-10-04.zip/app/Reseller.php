<?php
declare(strict_types=1);

final class Reseller
{
    private const PLANS = [
        1 => ['label' => '1 dia', 'credits' => 1],
        7 => ['label' => '7 dias', 'credits' => 3],
        14 => ['label' => '14 dias', 'credits' => 6],
        15 => ['label' => '15 dias', 'credits' => 7],
        30 => ['label' => '30 dias', 'credits' => 15],
        60 => ['label' => '60 dias', 'credits' => 28],
        90 => ['label' => '90 dias', 'credits' => 40],
        180 => ['label' => '180 dias', 'credits' => 75],
        365 => ['label' => '365 dias', 'credits' => 140],
    ];

    public static function plans(): array
    {
        return self::PLANS;
    }

    public static function plan(int $days): array
    {
        if (!isset(self::PLANS[$days])) {
            throw new InvalidArgumentException('Plano inválido.');
        }
        return self::PLANS[$days] + ['days' => $days];
    }

    public static function isOwner(array $user): bool
    {
        return (string) ($user['role'] ?? '') === 'owner';
    }

    public static function isStaff(array $user): bool
    {
        return in_array((string) ($user['role'] ?? ''), ['owner', 'admin'], true);
    }

    public static function isReseller(array $user): bool
    {
        return (string) ($user['role'] ?? '') === 'reseller';
    }

    public static function create(string $username, string $password, int $credits, bool $active, string $note, int $actorId): int
    {
        $username = trim($username);
        if (!preg_match('/^[A-Za-z0-9@._-]{3,190}$/', $username)) {
            throw new InvalidArgumentException('Nome de usuário inválido.');
        }
        if (strlen($password) < 12) {
            throw new InvalidArgumentException('A senha deve ter pelo menos 12 caracteres.');
        }
        $credits = max(0, min($credits, 1000000000));
        $note = mb_substr(trim($note), 0, 255);
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $exists = $pdo->prepare('SELECT id FROM admin_users WHERE username = ? LIMIT 1');
            $exists->execute([$username]);
            if ($exists->fetch()) {
                throw new InvalidArgumentException('Este usuário já existe.');
            }
            $insert = $pdo->prepare("INSERT INTO admin_users (username, password_hash, role, is_active, created_at) VALUES (?, ?, 'reseller', ?, CURRENT_TIMESTAMP)");
            $insert->execute([$username, password_hash($password, defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT), $active ? 1 : 0]);
            $id = (int) $pdo->lastInsertId();
            $wallet = $pdo->prepare('INSERT INTO reseller_wallets (user_id, credits, unlimited, note, created_at, updated_at) VALUES (?, ?, 0, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)');
            $wallet->execute([$id, $credits, $note !== '' ? $note : null]);
            if ($credits > 0) {
                $ledger = $pdo->prepare("INSERT INTO credit_ledger (reseller_id, actor_user_id, amount, balance_after, event_type, description, created_at) VALUES (?, ?, ?, ?, 'initial_grant', 'Crédito inicial', CURRENT_TIMESTAMP)");
                $ledger->execute([$id, $actorId, $credits, $credits]);
            }
            $pdo->commit();
            audit('reseller_created', $actorId, 'admin_user', (string) $id, ['username' => $username, 'credits' => $credits, 'active' => $active]);
            return $id;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    public static function listAll(): array
    {
        return db()->query("SELECT u.id, u.username, u.is_active, u.created_at, w.credits, w.unlimited, w.note FROM admin_users u LEFT JOIN reseller_wallets w ON w.user_id = u.id WHERE u.role = 'reseller' ORDER BY u.id DESC")->fetchAll();
    }

    public static function wallet(int $userId): array
    {
        $stmt = db()->prepare('SELECT user_id, credits, unlimited, note FROM reseller_wallets WHERE user_id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $wallet = $stmt->fetch();
        if (!$wallet) {
            throw new RuntimeException('Carteira do revendedor não encontrada. Execute a migração SQL.');
        }
        return [
            'user_id' => (int) $wallet['user_id'],
            'credits' => (int) $wallet['credits'],
            'unlimited' => (int) $wallet['unlimited'] === 1,
            'note' => (string) ($wallet['note'] ?? ''),
        ];
    }

    public static function generateKey(int $resellerId, int $actorId, int $days): array
    {
        if (Settings::keysPaused()) {
            throw new RuntimeException('A geração global está pausada.');
        }
        $plan = self::plan($days);
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $walletQuery = (string) cfg('DB_DRIVER', 'mysql') === 'sqlite'
                ? 'SELECT credits, unlimited FROM reseller_wallets WHERE user_id = ?'
                : 'SELECT credits, unlimited FROM reseller_wallets WHERE user_id = ? FOR UPDATE';
            $stmt = $pdo->prepare($walletQuery);
            $stmt->execute([$resellerId]);
            $wallet = $stmt->fetch();
            if (!$wallet) {
                throw new RuntimeException('Carteira do revendedor não encontrada.');
            }
            $credits = (int) $wallet['credits'];
            $unlimited = (int) $wallet['unlimited'] === 1;
            if (!$unlimited && $credits < (int) $plan['credits']) {
                throw new RuntimeException('Créditos insuficientes.');
            }
            $generated = KeyService::generateInTransaction(1, 1, $days, 'days', $actorId, 'RES', $resellerId);
            $after = $unlimited ? $credits : $credits - (int) $plan['credits'];
            if (!$unlimited) {
                $pdo->prepare('UPDATE reseller_wallets SET credits = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?')->execute([$after, $resellerId]);
            }
            $ledger = $pdo->prepare("INSERT INTO credit_ledger (reseller_id, actor_user_id, amount, balance_after, event_type, reference_type, reference_id, description, created_at) VALUES (?, ?, ?, ?, 'key_generation', 'api_key', ?, ?, CURRENT_TIMESTAMP)");
            $ledger->execute([$resellerId, $actorId, -(int) $plan['credits'], $unlimited ? null : $after, (string) ($generated['ids'][0] ?? ''), 'Key de ' . $plan['label']]);
            $pdo->commit();
            audit('reseller_key_generated', $actorId, 'api_key', (string) ($generated['ids'][0] ?? ''), ['reseller_id' => $resellerId, 'days' => $days, 'cost_credits' => $plan['credits'], 'unlimited' => $unlimited]);
            return [
                'key' => $generated['keys'][0],
                'key_id' => (int) ($generated['ids'][0] ?? 0),
                'expires_at' => $generated['expires_at'],
                'cost_credits' => (int) $plan['credits'],
                'credits_remaining' => $unlimited ? null : $after,
                'unlimited' => $unlimited,
                'plan' => $plan,
            ];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    public static function keysForReseller(int $resellerId): array
    {
        $stmt = db()->prepare("SELECT k.id, k.key_prefix, k.key_ciphertext, k.max_devices, k.expires_at, k.status, k.created_at, u.username AS reseller_username FROM api_keys k LEFT JOIN admin_users u ON u.id = k.reseller_id WHERE k.reseller_id = ? ORDER BY k.id DESC LIMIT 100");
        $stmt->execute([$resellerId]);
        return self::withPlaintext($stmt->fetchAll());
    }

    public static function keysForOwner(): array
    {
        $rows = db()->query("SELECT k.id, k.key_prefix, k.key_ciphertext, k.max_devices, k.expires_at, k.status, k.created_at, k.reseller_id, u.username AS reseller_username FROM api_keys k LEFT JOIN admin_users u ON u.id = k.reseller_id WHERE k.reseller_id IS NOT NULL ORDER BY k.id DESC LIMIT 300")->fetchAll();
        return self::withPlaintext($rows);
    }

    private static function withPlaintext(array $rows): array
    {
        foreach ($rows as &$row) {
            $ciphertext = (string) ($row['key_ciphertext'] ?? '');
            $row['plaintext_key'] = $ciphertext !== '' ? KeyService::decryptKey($ciphertext) : '';
        }
        unset($row);
        return $rows;
    }
}
