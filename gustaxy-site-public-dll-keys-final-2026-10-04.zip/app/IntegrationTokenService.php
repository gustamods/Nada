<?php
declare(strict_types=1);

/**
 * Tokens de integração (API externa).
 *
 * Ficam na tabela integration_tokens (antes eram um JSON em storage/api, que era
 * reescrito inteiro a cada uso e podia desfazer uma revogação feita ao mesmo tempo).
 * A tabela é criada sozinha no primeiro uso e os tokens do JSON antigo são importados.
 */
final class IntegrationTokenService
{
    public const SCOPES = [
        'keys.generate' => 'Gerar keys',
        'keys.manage' => 'Gerenciar keys',
        'updates.publish' => 'Publicar atualização',
        'resources.publish' => 'Publicar BIN',
        'read' => 'Consultar status',
    ];

    private const FAIL_BUCKET = 'integration-auth-fail';
    private const FAIL_MAX = 10;
    private const FAIL_WINDOW = 300;

    private static function legacyFile(): string
    {
        return GUSTAXY_ROOT . '/storage/api/integration-tokens.json';
    }

    private static function ensureSchema(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;
        try {
            db()->query('SELECT 1 FROM integration_tokens LIMIT 1')->fetchAll();
        } catch (Throwable) {
            $mysql = (string) cfg('DB_DRIVER', 'mysql') !== 'sqlite';
            db()->exec(
                'CREATE TABLE IF NOT EXISTS integration_tokens ('
                . 'id VARCHAR(16) NOT NULL PRIMARY KEY, '
                . 'label VARCHAR(80) NOT NULL, '
                . 'token_prefix VARCHAR(20) NOT NULL, '
                . 'token_hash CHAR(64) NOT NULL, '
                . 'scopes TEXT NOT NULL, '
                . 'ip_allowlist TEXT NOT NULL, '
                . 'created_by INTEGER NOT NULL, '
                . 'created_at DATETIME NOT NULL, '
                . 'expires_at DATETIME NOT NULL, '
                . 'last_used_at DATETIME NULL, '
                . 'revoked_at DATETIME NULL, '
                . 'UNIQUE (token_hash)'
                . ')' . ($mysql ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4' : '')
            );
        }
        self::importLegacy();
    }

    /** Importa (uma vez) os tokens do JSON antigo e aposenta o arquivo. */
    private static function importLegacy(): void
    {
        $file = self::legacyFile();
        if (!is_file($file) || !is_readable($file)) {
            return;
        }
        $data = json_decode((string) file_get_contents($file), true);
        $tokens = is_array($data) && isset($data['tokens']) && is_array($data['tokens']) ? $data['tokens'] : [];
        $pdo = db();
        $exists = $pdo->prepare('SELECT 1 FROM integration_tokens WHERE id = ? LIMIT 1');
        $insert = $pdo->prepare('INSERT INTO integration_tokens (id, label, token_prefix, token_hash, scopes, ip_allowlist, created_by, created_at, expires_at, last_used_at, revoked_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $pdo->beginTransaction();
        try {
            foreach ($tokens as $token) {
                if (!is_array($token)) {
                    continue;
                }
                $id = (string) ($token['id'] ?? '');
                $hash = (string) ($token['token_hash'] ?? '');
                if (!preg_match('/^[a-f0-9]{16}$/', $id) || !preg_match('/^[a-f0-9]{64}$/', $hash)) {
                    continue;
                }
                $exists->execute([$id]);
                if ($exists->fetchColumn()) {
                    continue;
                }
                $insert->execute([
                    $id,
                    mb_substr((string) ($token['label'] ?? 'token'), 0, 80),
                    mb_substr((string) ($token['token_prefix'] ?? ''), 0, 20),
                    $hash,
                    json_encode(array_values((array) ($token['scopes'] ?? [])), JSON_UNESCAPED_UNICODE),
                    json_encode(array_values((array) ($token['ip_allowlist'] ?? [])), JSON_UNESCAPED_UNICODE),
                    (int) ($token['created_by'] ?? 0),
                    (string) ($token['created_at'] ?? gmdate('Y-m-d H:i:s')),
                    (string) ($token['expires_at'] ?? gmdate('Y-m-d H:i:s')),
                    !empty($token['last_used_at']) ? (string) $token['last_used_at'] : null,
                    !empty($token['revoked_at']) ? (string) $token['revoked_at'] : null,
                ]);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('[gustaxy] integration token import: ' . $e->getMessage());
            return;
        }
        if (!@rename($file, $file . '.migrated')) {
            error_log('[gustaxy] não foi possível renomear integration-tokens.json após a importação');
        }
    }

    public static function create(string $label, array $scopes, int $expiresDays, int $actorId, string $ipAllowlist = ''): array
    {
        self::ensureSchema();
        $label = function_exists('mb_substr') ? mb_substr(trim($label), 0, 80) : substr(trim($label), 0, 80);
        if ($label === '') throw new InvalidArgumentException('Informe um nome para o token.');
        $scopes = array_values(array_unique(array_intersect(array_keys(self::SCOPES), array_map('strval', $scopes))));
        if (!$scopes) throw new InvalidArgumentException('Selecione pelo menos uma permissão.');
        $expiresDays = max(1, min(365, $expiresDays));
        $ips = [];
        foreach (preg_split('/[\s,;]+/', trim($ipAllowlist)) ?: [] as $ip) {
            if ($ip === '') continue;
            if (!filter_var($ip, FILTER_VALIDATE_IP)) throw new InvalidArgumentException('A lista de IP possui um valor inválido.');
            $ips[] = $ip;
        }
        $raw = 'gx_' . rtrim(strtr(base64_encode(random_bytes(42)), '+/', '-_'), '=');
        $hash = hash_hmac('sha256', $raw, app_key());
        $id = bin2hex(random_bytes(8));
        $now = gmdate('Y-m-d H:i:s');
        $expiresAt = gmdate('Y-m-d H:i:s', time() + $expiresDays * 86400);
        db()->prepare('INSERT INTO integration_tokens (id, label, token_prefix, token_hash, scopes, ip_allowlist, created_by, created_at, expires_at, last_used_at, revoked_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL)')
            ->execute([$id, $label, substr($raw, 0, 14), $hash, json_encode($scopes), json_encode($ips), $actorId, $now, $expiresAt]);
        audit('integration_token_created', $actorId, 'integration_token', $id, ['label' => $label, 'scopes' => $scopes, 'expires_at' => $expiresAt]);
        return ['token' => $raw, 'token_prefix' => substr($raw, 0, 14), 'expires_at' => $expiresAt, 'id' => $id];
    }

    public static function revoke(string $id, int $actorId): void
    {
        self::ensureSchema();
        $id = trim($id);
        if (!preg_match('/^[a-f0-9]{16}$/', $id)) throw new InvalidArgumentException('Token inválido.');
        $stmt = db()->prepare('UPDATE integration_tokens SET revoked_at = ? WHERE id = ? AND revoked_at IS NULL');
        $stmt->execute([gmdate('Y-m-d H:i:s'), $id]);
        if ($stmt->rowCount() === 0) {
            $check = db()->prepare('SELECT 1 FROM integration_tokens WHERE id = ? LIMIT 1');
            $check->execute([$id]);
            if (!$check->fetchColumn()) throw new InvalidArgumentException('Token não encontrado.');
            return; // já estava revogado
        }
        audit('integration_token_revoked', $actorId, 'integration_token', $id);
    }

    private static function decodeList(mixed $value): array
    {
        $decoded = json_decode((string) $value, true);
        return is_array($decoded) ? array_values($decoded) : [];
    }

    public static function all(): array
    {
        self::ensureSchema();
        $rows = [];
        foreach (db()->query('SELECT * FROM integration_tokens ORDER BY created_at DESC, id DESC')->fetchAll() as $token) {
            $rows[] = [
                'id' => (string) ($token['id'] ?? ''),
                'label' => (string) ($token['label'] ?? ''),
                'token_prefix' => (string) ($token['token_prefix'] ?? ''),
                'scopes' => self::decodeList($token['scopes'] ?? ''),
                'ip_allowlist' => self::decodeList($token['ip_allowlist'] ?? ''),
                'created_at' => (string) ($token['created_at'] ?? ''),
                'expires_at' => (string) ($token['expires_at'] ?? ''),
                'last_used_at' => (string) ($token['last_used_at'] ?? ''),
                'revoked_at' => (string) ($token['revoked_at'] ?? ''),
            ];
        }
        return $rows;
    }

    /** Registra a falha (conta para o bloqueio por IP) e responde. */
    private static function fail(string $message, int $status = 401): never
    {
        rate_limit(self::FAIL_BUCKET, self::FAIL_MAX, self::FAIL_WINDOW);
        json_response(['error' => $message], $status);
    }

    public static function authenticate(string $rawToken, string $scope): array
    {
        // Depois de 10 falhas em 5 min, o IP fica bloqueado até para token válido.
        if (!rate_limit_peek(self::FAIL_BUCKET, self::FAIL_MAX, self::FAIL_WINDOW)) {
            header('Retry-After: ' . self::FAIL_WINDOW);
            json_response(['error' => 'Muitas tentativas inválidas. Aguarde alguns minutos.'], 429);
        }
        $rawToken = trim($rawToken);
        if (!in_array($scope, array_keys(self::SCOPES), true)) {
            json_response(['error' => 'Token inválido.'], 401);
        }
        if ($rawToken === '' || strlen($rawToken) > 128) {
            self::fail('Token inválido.');
        }
        self::ensureSchema();
        $hash = hash_hmac('sha256', $rawToken, app_key());
        $stmt = db()->prepare('SELECT * FROM integration_tokens WHERE token_hash = ? LIMIT 1');
        $stmt->execute([$hash]);
        $selected = $stmt->fetch();
        if (!$selected || !hash_equals((string) $selected['token_hash'], $hash)) {
            self::fail('Token não autorizado.');
        }
        if (!empty($selected['revoked_at']) || strtotime((string) $selected['expires_at'] . ' UTC') <= time()) {
            self::fail('Token expirado ou revogado.');
        }
        $scopes = self::decodeList($selected['scopes'] ?? '');
        if (!in_array($scope, $scopes, true)) {
            json_response(['error' => 'Permissão insuficiente.'], 403);
        }
        $allow = self::decodeList($selected['ip_allowlist'] ?? '');
        $ip = (string) (client_context()['ip'] ?? ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'));
        if ($allow && !in_array($ip, $allow, true)) {
            self::fail('Origem não autorizada.', 403);
        }
        $id = (string) $selected['id'];
        if (!rate_limit('integration-token-' . $id, 60, 60)) json_response(['error' => 'Muitas solicitações.'], 429);
        $now = gmdate('Y-m-d H:i:s');
        db()->prepare('UPDATE integration_tokens SET last_used_at = ? WHERE id = ?')->execute([$now, $id]);
        self::logActivity($selected, $scope, $now, $ip);

        $selected['scopes'] = $scopes;
        $selected['ip_allowlist'] = $allow;
        return $selected;
    }

    /** Feed das notificações do painel (mantido em arquivo; perder uma linha não afeta segurança). */
    private static function logActivity(array $selected, string $scope, string $now, string $ip): void
    {
        $dir = GUSTAXY_ROOT . '/storage/api';
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        $activityFile = $dir . '/integration-activity.json';
        $activities = [];
        if (is_file($activityFile)) {
            $decoded = json_decode((string) @file_get_contents($activityFile), true);
            if (is_array($decoded)) {
                $activities = array_values(array_filter($decoded, 'is_array'));
            }
        }
        $activities[] = [
            'created_at' => $now,
            'token_id' => (string) ($selected['id'] ?? ''),
            'token_prefix' => (string) ($selected['token_prefix'] ?? ''),
            'token_label' => (string) ($selected['label'] ?? ''),
            'scope' => $scope,
            'method' => (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'),
            'path' => (string) (parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'),
            'ip' => $ip,
        ];
        $activities = array_slice($activities, -100, 100);
        $tmp = $activityFile . '.' . bin2hex(random_bytes(6)) . '.tmp';
        if (file_put_contents($tmp, json_encode($activities, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX) !== false) {
            @chmod($tmp, 0600);
            @rename($tmp, $activityFile);
        } else {
            @unlink($tmp);
        }
    }

    public static function extractToken(): string
    {
        $auth = trim((string) ($_SERVER['HTTP_AUTHORIZATION'] ?? ''));
        if (preg_match('/^Bearer\s+([A-Za-z0-9_-]{20,128})$/', $auth, $m)) return $m[1];
        $header = trim((string) ($_SERVER['HTTP_X_GUSTAXY_API_TOKEN'] ?? ''));
        if ($header !== '') return $header;
        // Token na URL vaza em logs do servidor/proxy: desativado por padrão.
        // Para uma migração temporária, defina INTEGRATION_ALLOW_QUERY_TOKEN => true no env.php.
        if ((bool) cfg('INTEGRATION_ALLOW_QUERY_TOKEN', false)) {
            $query = trim((string) ($_GET['token'] ?? ''));
            if ($query !== '') return $query;
        }
        return '';
    }
}
