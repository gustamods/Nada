<?php
declare(strict_types=1);
require __DIR__ . '/config/bootstrap.php';
require __DIR__ . '/app/PublicLayout.php';
public_header('Keys Grátis', 'keys');
public_footer();
