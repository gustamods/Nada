CREATE TABLE IF NOT EXISTS admin_users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(32) NOT NULL DEFAULT 'admin',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  failed_attempts INT UNSIGNED NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login_at DATETIME NULL,
  totp_secret VARCHAR(255) NULL,
  totp_confirmed_at DATETIME NULL,
  totp_last_counter BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_admin_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS api_keys (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  key_prefix VARCHAR(24) NOT NULL,
  key_hash CHAR(64) NOT NULL,
  key_ciphertext TEXT NULL,
  max_devices INT UNSIGNED NOT NULL DEFAULT 1,
  expires_at DATETIME NOT NULL,
  status ENUM('active','paused','revoked','expired') NOT NULL DEFAULT 'active',
  created_by INT UNSIGNED NULL,
  reseller_id INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paused_at DATETIME NULL,
  pause_started_at DATETIME NULL,
  revoked_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_key_hash (key_hash),
  KEY idx_keys_status_expiry (status, expires_at),
  KEY idx_keys_reseller (reseller_id, created_at),
  CONSTRAINT fk_keys_admin FOREIGN KEY (created_by) REFERENCES admin_users(id) ON DELETE SET NULL,
  CONSTRAINT fk_keys_reseller FOREIGN KEY (reseller_id) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS devices (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  api_key_id BIGINT UNSIGNED NOT NULL,
  device_id_hash CHAR(64) NOT NULL,
  device_name VARCHAR(120) NULL,
  app_version VARCHAR(32) NULL,
  android_version VARCHAR(32) NULL,
  first_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  login_count INT UNSIGNED NOT NULL DEFAULT 1,
  revoked_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_key_device (api_key_id, device_id_hash),
  KEY idx_devices_last_seen (last_seen_at),
  CONSTRAINT fk_devices_key FOREIGN KEY (api_key_id) REFERENCES api_keys(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS api_tokens (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  token_hash CHAR(64) NOT NULL,
  api_key_id BIGINT UNSIGNED NOT NULL,
  device_id_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME NULL,
  revoked_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_token_hash (token_hash),
  KEY idx_token_expiry (expires_at),
  CONSTRAINT fk_tokens_key FOREIGN KEY (api_key_id) REFERENCES api_keys(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  event_type VARCHAR(80) NOT NULL,
  actor_user_id INT UNSIGNED NULL,
  target_type VARCHAR(40) NULL,
  target_id VARCHAR(80) NULL,
  metadata_json JSON NULL,
  ip_address VARCHAR(45) NOT NULL,
  user_agent VARCHAR(512) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_created (created_at),
  CONSTRAINT fk_audit_admin FOREIGN KEY (actor_user_id) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_logs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  admin_user_id INT UNSIGNED NULL,
  api_key_id BIGINT UNSIGNED NULL,
  device_id_hash CHAR(64) NULL,
  success TINYINT(1) NOT NULL DEFAULT 0,
  browser VARCHAR(64) NULL,
  operating_system VARCHAR(64) NULL,
  ip_address VARCHAR(45) NOT NULL,
  user_agent VARCHAR(512) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_login_created (created_at),
  CONSTRAINT fk_login_admin FOREIGN KEY (admin_user_id) REFERENCES admin_users(id) ON DELETE SET NULL,
  CONSTRAINT fk_login_key FOREIGN KEY (api_key_id) REFERENCES api_keys(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS app_settings (
  setting_key VARCHAR(80) NOT NULL,
  setting_value TEXT NOT NULL,
  updated_by INT UNSIGNED NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (setting_key),
  CONSTRAINT fk_settings_admin FOREIGN KEY (updated_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reseller_wallets (
  user_id INT UNSIGNED NOT NULL,
  credits BIGINT UNSIGNED NOT NULL DEFAULT 0,
  unlimited TINYINT(1) NOT NULL DEFAULT 0,
  note VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_wallet_user FOREIGN KEY (user_id) REFERENCES admin_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS credit_ledger (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  reseller_id INT UNSIGNED NOT NULL,
  actor_user_id INT UNSIGNED NULL,
  amount BIGINT NOT NULL,
  balance_after BIGINT UNSIGNED NULL,
  event_type VARCHAR(40) NOT NULL,
  reference_type VARCHAR(40) NULL,
  reference_id VARCHAR(80) NULL,
  description VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_credit_ledger_reseller (reseller_id, created_at),
  CONSTRAINT fk_ledger_reseller FOREIGN KEY (reseller_id) REFERENCES admin_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ledger_actor FOREIGN KEY (actor_user_id) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS device_security (
  device_id_hash CHAR(64) NOT NULL,
  tamper_count INT UNSIGNED NOT NULL DEFAULT 0,
  last_reason VARCHAR(120) NULL,
  last_seen_at DATETIME NULL,
  notice_shown_at DATETIME NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (device_id_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS device_security_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  device_id_hash CHAR(64) NOT NULL,
  api_key_id BIGINT UNSIGNED NULL,
  event_nonce_hash CHAR(64) NOT NULL,
  reason VARCHAR(120) NOT NULL,
  app_version VARCHAR(32) NULL,
  android_version VARCHAR(32) NULL,
  certificate_sha256 VARCHAR(128) NULL,
  ip_address VARCHAR(45) NOT NULL,
  user_agent VARCHAR(512) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_security_events_device (device_id_hash, created_at),
  UNIQUE KEY uq_security_event_nonce (device_id_hash, event_nonce_hash),
  KEY idx_security_events_key (api_key_id, created_at),
  CONSTRAINT fk_security_events_key FOREIGN KEY (api_key_id) REFERENCES api_keys(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS device_blocklist (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  device_id_hash CHAR(64) NOT NULL,
  reason VARCHAR(255) NOT NULL,
  source ENUM('automatic','manual') NOT NULL DEFAULT 'manual',
  actor_user_id INT UNSIGNED NULL,
  banned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  unbanned_at DATETIME NULL,
  unbanned_by INT UNSIGNED NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_blocklist_device (device_id_hash),
  KEY idx_blocklist_active (unbanned_at, banned_at),
  CONSTRAINT fk_blocklist_actor FOREIGN KEY (actor_user_id) REFERENCES admin_users(id) ON DELETE SET NULL,
  CONSTRAINT fk_blocklist_unbanned_by FOREIGN KEY (unbanned_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS apk_releases (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  version VARCHAR(32) NOT NULL,
  version_code BIGINT UNSIGNED NOT NULL,
  download_url VARCHAR(2048) NOT NULL,
  sha256 CHAR(64) NOT NULL,
  size_bytes BIGINT UNSIGNED NULL,
  released_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_apk_release_active (is_active, version_code),
  KEY idx_apk_release_version (version_code),
  CONSTRAINT fk_apk_release_admin FOREIGN KEY (created_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS integration_tokens (
  id VARCHAR(16) NOT NULL,
  label VARCHAR(80) NOT NULL,
  token_prefix VARCHAR(20) NOT NULL,
  token_hash CHAR(64) NOT NULL,
  scopes TEXT NOT NULL,
  ip_allowlist TEXT NOT NULL,
  created_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  expires_at DATETIME NOT NULL,
  last_used_at DATETIME NULL,
  revoked_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_integration_token_hash (token_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS public_products (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(120) NOT NULL,
  description VARCHAR(500) NOT NULL DEFAULT '',
  thumb_url VARCHAR(2048) NOT NULL,
  platform ENUM('android','iphone','pc') NOT NULL,
  apk_version VARCHAR(32) NOT NULL DEFAULT '',
  download_type ENUM('direct','shortened') NOT NULL,
  download_url VARCHAR(2048) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  created_by INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_public_products_active (is_active, sort_order, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
