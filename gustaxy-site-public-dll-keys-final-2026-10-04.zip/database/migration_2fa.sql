-- Gustaxy 2FA migration; safe to run after database.sql / migration_controls.sql.
-- Não apaga nem altera nenhuma conta existente: os administradores atuais
-- continuam entrando normalmente com usuário e senha até ativarem o 2FA
-- em /admin/security.php.
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS totp_secret VARCHAR(255) NULL AFTER last_login_at;
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS totp_confirmed_at DATETIME NULL AFTER totp_secret;
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS totp_last_counter BIGINT NOT NULL DEFAULT 0 AFTER totp_confirmed_at;
-- Segredos novos são guardados cifrados (enc:v1:...), por isso a coluna precisa de 255.
ALTER TABLE admin_users MODIFY totp_secret VARCHAR(255) NULL;
