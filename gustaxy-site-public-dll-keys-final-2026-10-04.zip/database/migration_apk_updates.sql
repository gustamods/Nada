-- GUSTAXY APK update metadata migration. Execute once after database.sql.
CREATE TABLE IF NOT EXISTS apk_releases (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  version VARCHAR(32) NOT NULL,
  version_code BIGINT UNSIGNED NOT NULL,
  download_url VARCHAR(2048) NOT NULL,
  sha256 CHAR(64) NOT NULL,
  size_bytes BIGINT UNSIGNED NULL,
  released_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_apk_release_active (is_active, version_code),
  KEY idx_apk_release_version (version_code),
  CONSTRAINT fk_apk_release_admin FOREIGN KEY (created_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
