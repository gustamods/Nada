CREATE TABLE IF NOT EXISTS apk_releases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  version TEXT NOT NULL,
  version_code INTEGER NOT NULL,
  download_url TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  size_bytes INTEGER NULL,
  released_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_apk_release_active ON apk_releases(is_active, version_code);
CREATE INDEX IF NOT EXISTS idx_apk_release_version ON apk_releases(version_code);
