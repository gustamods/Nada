-- Gustaxy: revendedores, créditos e keys recuperáveis.
-- Execute esta migração uma vez no banco de produção.
-- Antes de usar a aba Revendedores, promova explicitamente a sua conta:
-- UPDATE admin_users SET role = 'owner' WHERE username = 'SEU_USUARIO_OWNER';
-- Não deixe o valor literal acima sem substituir pelo seu usuário real.

ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS reseller_id INT UNSIGNED NULL AFTER created_by;
ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS key_ciphertext TEXT NULL AFTER key_hash;

CREATE TABLE IF NOT EXISTS reseller_wallets (
  user_id INT UNSIGNED NOT NULL,
  credits BIGINT UNSIGNED NOT NULL DEFAULT 0,
  unlimited TINYINT(1) NOT NULL DEFAULT 0,
  note VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_wallet_user FOREIGN KEY (user_id) REFERENCES admin_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS credit_ledger (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  reseller_id INT UNSIGNED NOT NULL,
  actor_user_id INT UNSIGNED NULL,
  amount BIGINT NOT NULL,
  balance_after BIGINT UNSIGNED NULL,
  event_type VARCHAR(40) NOT NULL,
  reference_type VARCHAR(40) NULL,
  reference_id VARCHAR(80) NULL,
  description VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_credit_ledger_reseller (reseller_id, created_at),
  CONSTRAINT fk_ledger_reseller FOREIGN KEY (reseller_id) REFERENCES admin_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ledger_actor FOREIGN KEY (actor_user_id) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE api_keys
  ADD CONSTRAINT fk_keys_reseller FOREIGN KEY (reseller_id) REFERENCES admin_users(id) ON DELETE SET NULL;

CREATE INDEX idx_keys_reseller ON api_keys (reseller_id, created_at);
