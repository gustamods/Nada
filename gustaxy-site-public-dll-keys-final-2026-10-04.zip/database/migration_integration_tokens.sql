-- Tokens de integração passam a ficar no banco (antes: storage/api/integration-tokens.json).
-- Opcional: a tabela também é criada sozinha no primeiro uso da API, e os tokens
-- do JSON antigo são importados automaticamente (o arquivo vira *.migrated).
CREATE TABLE IF NOT EXISTS integration_tokens (
  id VARCHAR(16) NOT NULL,
  label VARCHAR(80) NOT NULL,
  token_prefix VARCHAR(20) NOT NULL,
  token_hash CHAR(64) NOT NULL,
  scopes TEXT NOT NULL,
  ip_allowlist TEXT NOT NULL,
  created_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  expires_at DATETIME NOT NULL,
  last_used_at DATETIME NULL,
  revoked_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_integration_token_hash (token_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
