-- GUSTAXY APK integrity / blacklist migration
-- Execute once after database.sql + existing migrations.

CREATE TABLE IF NOT EXISTS device_security (
  device_id_hash CHAR(64) NOT NULL,
  tamper_count INT UNSIGNED NOT NULL DEFAULT 0,
  last_reason VARCHAR(120) NULL,
  last_seen_at DATETIME NULL,
  notice_shown_at DATETIME NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (device_id_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS device_security_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  device_id_hash CHAR(64) NOT NULL,
  api_key_id BIGINT UNSIGNED NULL,
  event_nonce_hash CHAR(64) NOT NULL,
  reason VARCHAR(120) NOT NULL,
  app_version VARCHAR(32) NULL,
  android_version VARCHAR(32) NULL,
  certificate_sha256 VARCHAR(128) NULL,
  ip_address VARCHAR(45) NOT NULL,
  user_agent VARCHAR(512) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_security_events_device (device_id_hash, created_at),
  UNIQUE KEY uq_security_event_nonce (device_id_hash, event_nonce_hash),
  KEY idx_security_events_key (api_key_id, created_at),
  CONSTRAINT fk_security_events_key FOREIGN KEY (api_key_id) REFERENCES api_keys(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS device_blocklist (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  device_id_hash CHAR(64) NOT NULL,
  reason VARCHAR(255) NOT NULL,
  source ENUM('automatic','manual') NOT NULL DEFAULT 'manual',
  actor_user_id INT UNSIGNED NULL,
  banned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  unbanned_at DATETIME NULL,
  unbanned_by INT UNSIGNED NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_blocklist_device (device_id_hash),
  KEY idx_blocklist_active (unbanned_at, banned_at),
  CONSTRAINT fk_blocklist_actor FOREIGN KEY (actor_user_id) REFERENCES admin_users(id) ON DELETE SET NULL,
  CONSTRAINT fk_blocklist_unbanned_by FOREIGN KEY (unbanned_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO app_settings (setting_key, setting_value) VALUES
  ('tamper_notice_enabled', '0'),
  ('tamper_notice_mode', 'automatic'),
  ('tamper_notice_title', 'Aplicativo modificado'),
  ('tamper_notice_description', 'Foi detectada uma alteração não autorizada neste aplicativo.'),
  ('tamper_notice_image_path', ''),
  ('tamper_blacklist_threshold', '3'),
  ('tamper_blacklist_enabled', '1')
ON DUPLICATE KEY UPDATE setting_key = VALUES(setting_key);
