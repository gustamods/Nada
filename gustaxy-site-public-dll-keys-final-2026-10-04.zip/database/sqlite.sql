CREATE TABLE IF NOT EXISTS admin_users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'admin', is_active INTEGER NOT NULL DEFAULT 1, failed_attempts INTEGER NOT NULL DEFAULT 0, locked_until TEXT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, last_login_at TEXT NULL, totp_secret TEXT NULL, totp_confirmed_at TEXT NULL, totp_last_counter INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS api_keys (id INTEGER PRIMARY KEY AUTOINCREMENT, key_prefix TEXT NOT NULL, key_hash TEXT NOT NULL UNIQUE, key_ciphertext TEXT NULL, max_devices INTEGER NOT NULL DEFAULT 1, expires_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active', created_by INTEGER NULL, reseller_id INTEGER NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, paused_at TEXT NULL, pause_started_at TEXT NULL, revoked_at TEXT NULL);
CREATE TABLE IF NOT EXISTS devices (id INTEGER PRIMARY KEY AUTOINCREMENT, api_key_id INTEGER NOT NULL, device_id_hash TEXT NOT NULL, device_name TEXT NULL, app_version TEXT NULL, android_version TEXT NULL, first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, login_count INTEGER NOT NULL DEFAULT 1, revoked_at TEXT NULL, UNIQUE(api_key_id, device_id_hash));
CREATE TABLE IF NOT EXISTS api_tokens (id INTEGER PRIMARY KEY AUTOINCREMENT, token_hash TEXT NOT NULL UNIQUE, api_key_id INTEGER NOT NULL, device_id_hash TEXT NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen_at TEXT NULL, revoked_at TEXT NULL);
CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT NOT NULL, actor_user_id INTEGER NULL, target_type TEXT NULL, target_id TEXT NULL, metadata_json TEXT NULL, ip_address TEXT NOT NULL, user_agent TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS login_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, admin_user_id INTEGER NULL, api_key_id INTEGER NULL, device_id_hash TEXT NULL, success INTEGER NOT NULL DEFAULT 0, browser TEXT NULL, operating_system TEXT NULL, ip_address TEXT NOT NULL, user_agent TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS app_settings (setting_key TEXT PRIMARY KEY NOT NULL, setting_value TEXT NOT NULL, updated_by INTEGER NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS reseller_wallets (user_id INTEGER PRIMARY KEY, credits INTEGER NOT NULL DEFAULT 0, unlimited INTEGER NOT NULL DEFAULT 0, note TEXT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS credit_ledger (id INTEGER PRIMARY KEY AUTOINCREMENT, reseller_id INTEGER NOT NULL, actor_user_id INTEGER NULL, amount INTEGER NOT NULL, balance_after INTEGER NULL, event_type TEXT NOT NULL, reference_type TEXT NULL, reference_id TEXT NULL, description TEXT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_keys_status_expiry ON api_keys(status, expires_at);
CREATE INDEX IF NOT EXISTS idx_keys_reseller ON api_keys(reseller_id, created_at);
CREATE INDEX IF NOT EXISTS idx_devices_last_seen ON devices(last_seen_at);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_login_created ON login_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_credit_ledger_reseller ON credit_ledger(reseller_id, created_at);


CREATE TABLE IF NOT EXISTS device_security (
  device_id_hash TEXT PRIMARY KEY,
  tamper_count INTEGER NOT NULL DEFAULT 0,
  last_reason TEXT NULL,
  last_seen_at TEXT NULL,
  notice_shown_at TEXT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS device_security_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  device_id_hash TEXT NOT NULL,
  api_key_id INTEGER NULL,
  event_nonce_hash TEXT NOT NULL,
  reason TEXT NOT NULL,
  app_version TEXT NULL,
  android_version TEXT NULL,
  certificate_sha256 TEXT NULL,
  ip_address TEXT NOT NULL,
  user_agent TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS device_blocklist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  device_id_hash TEXT NOT NULL UNIQUE,
  reason TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'manual',
  actor_user_id INTEGER NULL,
  banned_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  unbanned_at TEXT NULL,
  unbanned_by INTEGER NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_security_event_nonce ON device_security_events(device_id_hash, event_nonce_hash);
CREATE INDEX IF NOT EXISTS idx_security_events_device ON device_security_events(device_id_hash, created_at);
CREATE INDEX IF NOT EXISTS idx_security_events_key ON device_security_events(api_key_id, created_at);
CREATE INDEX IF NOT EXISTS idx_blocklist_active ON device_blocklist(unbanned_at, banned_at);

CREATE TABLE IF NOT EXISTS apk_releases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  version TEXT NOT NULL,
  version_code INTEGER NOT NULL,
  download_url TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  size_bytes INTEGER NULL,
  released_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_apk_release_active ON apk_releases(is_active, version_code);
CREATE INDEX IF NOT EXISTS idx_apk_release_version ON apk_releases(version_code);
CREATE TABLE IF NOT EXISTS integration_tokens (id TEXT NOT NULL PRIMARY KEY, label TEXT NOT NULL, token_prefix TEXT NOT NULL, token_hash TEXT NOT NULL UNIQUE, scopes TEXT NOT NULL, ip_allowlist TEXT NOT NULL, created_by INTEGER NOT NULL, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, last_used_at TEXT NULL, revoked_at TEXT NULL);

CREATE TABLE IF NOT EXISTS public_products (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', thumb_url TEXT NOT NULL, platform TEXT NOT NULL, apk_version TEXT NOT NULL DEFAULT '', download_type TEXT NOT NULL, download_url TEXT NOT NULL, is_active INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 0, created_by INTEGER NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_public_products_active ON public_products(is_active, sort_order, id);
