<?php
declare(strict_types=1);

const GUSTAXY_ROOT = __DIR__ . '/..';

require_once GUSTAXY_ROOT . '/app/AccessGuard.php';

$configPath = getenv('GUSTAXY_CONFIG') ?: (__DIR__ . '/env.php');
if (!is_file($configPath)) {
    $configPath = __DIR__ . '/env.example.php';
}
$GLOBALS['gustaxy_config'] = require $configPath;

function cfg(string $key, mixed $default = null): mixed
{
    return $GLOBALS['gustaxy_config'][$key] ?? $default;
}

$gustaxyShowErrors = ((string) cfg('APP_ENV', 'production')) === 'testing';
ini_set('display_errors', $gustaxyShowErrors ? '1' : '0');
ini_set('display_startup_errors', $gustaxyShowErrors ? '1' : '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);
set_exception_handler(static function (Throwable $e) use ($gustaxyShowErrors): void {
    error_log('[gustaxy] uncaught: ' . $e->getMessage() . ' at ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
    }
    echo $gustaxyShowErrors ? ((string) $e) : 'Erro interno. Tente novamente mais tarde.';
});
set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
    if ($severity === E_DEPRECATED || $severity === E_USER_DEPRECATED) {
        return true;
    }
    if (!(error_reporting() & $severity)) {
        return true;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (bool) cfg('COOKIE_SECURE', true);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.sid_length', '48');
    ini_set('session.sid_bits_per_character', '6');
    ini_set('session.gc_maxlifetime', (string) max(3600, (int) cfg('SESSION_IDLE_TTL', 1800) * 4));
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');
    if ($secure) {
        ini_set('session.cookie_secure', '1');
    }
    session_name('gustaxy_admin');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $driver = (string) cfg('DB_DRIVER', 'mysql');
    if ($driver === 'sqlite') {
        $path = (string) cfg('DB_PATH', GUSTAXY_ROOT . '/storage/gustaxy.sqlite');
        if (!is_dir(dirname($path))) {
            mkdir(dirname($path), 0700, true);
        }
        $dsn = 'sqlite:' . $path;
        $pdo = new PDO($dsn);
    } else {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', cfg('DB_HOST'), cfg('DB_PORT', '3306'), cfg('DB_NAME'));
        $pdo = new PDO($dsn, (string) cfg('DB_USER'), (string) cfg('DB_PASS'), [
            PDO::ATTR_TIMEOUT => 5,
        ]);
        // Força UTC na sessão: CURRENT_TIMESTAMP passa a gravar em UTC, que é o que fmt_date() espera.
        $pdo->exec("SET time_zone = '+00:00'");
    }
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    return $pdo;
}

function app_key(): string
{
    $key = (string) cfg('APP_KEY', '');
    if (strlen($key) < 32 || str_contains($key, 'gere-uma-chave')) {
        throw new RuntimeException('APP_KEY não configurada.');
    }
    return $key;
}

/**
 * Subchave derivada da APP_KEY (HKDF-SHA256) para um propósito específico.
 * Evita reutilizar a mesma chave bruta para tudo; só é usada em dados novos
 * (hoje: segredo do 2FA). Keys, tokens e devices continuam com a APP_KEY
 * original para não invalidar o que já existe.
 */
function app_subkey(string $context): string
{
    return hash_hkdf('sha256', app_key(), 32, 'gustaxy:' . $context);
}

function b64url_encode(string $value): string
{
    return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
}

function b64url_decode(string $value): string
{
    $padded = str_pad(strtr($value, '-_', '+/'), (int) (4 * ceil(strlen($value) / 4)), '=', STR_PAD_RIGHT);
    return (string) base64_decode($padded, true);
}

function random_token(int $bytes = 32): string
{
    return b64url_encode(random_bytes($bytes));
}

function json_input(): array
{
    if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 65536) {
        json_response(['error' => 'Payload muito grande.'], 413);
    }
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function redirect_to(string $path): never
{
    header('Location: ' . $path, true, 303);
    exit;
}

function client_ip(): string
{
    if ((bool) cfg('TRUST_PROXY', false) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $first = trim(explode(',', (string) $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
        if (filter_var($first, FILTER_VALIDATE_IP)) {
            return $first;
        }
    }
    return filter_var($_SERVER['REMOTE_ADDR'] ?? '', FILTER_VALIDATE_IP) ?: '0.0.0.0';
}

function normalize_fingerprint(string $value): string
{
    return strtoupper(str_replace([':', '-', ' '], '', trim($value)));
}

function user_agent(): string
{
    return mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown'), 0, 512);
}

function client_context(): array
{
    $ua = strtolower(user_agent());
    $browser = str_contains($ua, 'edg/') ? 'Edge' : (str_contains($ua, 'chrome') ? 'Google Chrome' : (str_contains($ua, 'firefox') ? 'Firefox' : (str_contains($ua, 'safari') ? 'Safari' : 'Outro')));
    $os = str_contains($ua, 'android') ? 'Android' : (str_contains($ua, 'iphone') || str_contains($ua, 'ipad') ? 'iOS' : (str_contains($ua, 'linux') ? 'Linux' : (str_contains($ua, 'windows') ? 'Windows' : (str_contains($ua, 'mac') ? 'macOS' : 'Outro'))));
    return ['browser' => $browser, 'os' => $os, 'ip' => client_ip(), 'user_agent' => user_agent()];
}

function security_headers(): void
{
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=(), browsing-topics=()');
    header("Content-Security-Policy: default-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'; script-src 'self'; style-src 'self'; img-src 'self' https: data:; font-src 'self'; connect-src 'self'; object-src 'none'; frame-src 'none'; worker-src 'none'; manifest-src 'none'; media-src 'none'; upgrade-insecure-requests");
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Cross-Origin-Resource-Policy: same-origin');
    header('Cross-Origin-Embedder-Policy: require-corp');
    header('X-Permitted-Cross-Domain-Policies: none');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    header_remove('X-Powered-By');
    header_remove('Server');
    if ((bool) cfg('COOKIE_SECURE', true)) {
        header('Strict-Transport-Security: max-age=63072000; includeSubDomains; preload');
    }
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
    if (str_starts_with($uri, '/admin')) {
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');
    }
}

function global_request_shield(): void
{
    $max = (int) cfg('GLOBAL_RATE_LIMIT', 240);
    $window = (int) cfg('GLOBAL_RATE_WINDOW', 60);
    if (!rate_limit('global-shield', $max, $window)) {
        json_response(['error' => 'Muitas solicitações. Tente novamente em instantes.'], 429);
    }
}

function rate_limit_gc(): void
{
    if (random_int(1, 200) !== 1) {
        return;
    }
    $dir = GUSTAXY_ROOT . '/storage/ratelimit';
    if (!is_dir($dir)) {
        return;
    }
    $cutoff = time() - 3600;
    foreach ((glob($dir . '/*.json') ?: []) as $file) {
        if (@filemtime($file) < $cutoff) {
            @unlink($file);
        }
    }

    $nonceDir = GUSTAXY_ROOT . '/storage/request-nonces';
    if (is_dir($nonceDir)) {
        $nonceCutoff = time() - 900;
        foreach ((glob($nonceDir . '/*.nonce') ?: []) as $file) {
            if (@filemtime($file) < $nonceCutoff) {
                @unlink($file);
            }
        }
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = random_token(32);
    }
    return (string) $_SESSION['csrf'];
}

function verify_csrf(?string $token): void
{
    if (!$token || !hash_equals((string) ($_SESSION['csrf'] ?? ''), $token)) {
        http_response_code(419);
        exit('Sessão expirada. Recarregue a página.');
    }
}

function session_fingerprint(): string
{
    $ip = client_ip();
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $parts = explode('.', $ip);
        $ip = $parts[0] . '.' . $parts[1] . '.' . $parts[2] . '.0';
    } elseif (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        $packed = inet_pton($ip);
        if (is_string($packed) && strlen($packed) === 16) {
            $ip = inet_ntop(substr($packed, 0, 8) . str_repeat("\0", 8)) ?: $ip;
        }
    }
    return hash('sha256', user_agent() . '|' . $ip);
}

function current_user(): ?array
{
    $id = $_SESSION['user_id'] ?? null;
    if (!$id) {
        return null;
    }
    $now = time();
    $idle = (int) cfg('SESSION_IDLE_TTL', 1800);
    $absolute = (int) cfg('SESSION_ABSOLUTE_TTL', 28800);
    if (!empty($_SESSION['last_seen']) && $now - (int) $_SESSION['last_seen'] > $idle) {
        $_SESSION = [];
        session_destroy();
        return null;
    }
    if (!empty($_SESSION['session_started']) && $now - (int) $_SESSION['session_started'] > $absolute) {
        $_SESSION = [];
        session_destroy();
        return null;
    }
    if ((bool) cfg('SESSION_BIND', true) && !empty($_SESSION['fingerprint']) && !hash_equals((string) $_SESSION['fingerprint'], session_fingerprint())) {
        $_SESSION = [];
        session_destroy();
        return null;
    }
    $_SESSION['last_seen'] = $now;
    $stmt = db()->prepare('SELECT id, username, role, is_active FROM admin_users WHERE id = ? LIMIT 1');
    $stmt->execute([(int) $id]);
    $user = $stmt->fetch();
    return ($user && (int) $user['is_active'] === 1) ? $user : null;
}

function start_authenticated_session(int $userId): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    $_SESSION['last_seen'] = time();
    $_SESSION['session_started'] = time();
    $_SESSION['fingerprint'] = session_fingerprint();
    $_SESSION['csrf'] = random_token(32);
}

function require_admin(): array
{
    $user = current_user();
    if (!$user) {
        redirect_to('/admin/login.php');
    }
    AccessGuard::blockTor();
    if (!in_array((string) ($user['role'] ?? ''), ['owner', 'admin'], true)) {
        redirect_to('/admin/reseller.php');
    }
    return $user;
}

function require_owner(): array
{
    $user = current_user();
    if (!$user) {
        redirect_to('/admin/login.php');
    }
    AccessGuard::blockTor();
    if ((string) ($user['role'] ?? '') !== 'owner') {
        redirect_to('/admin/index.php');
    }
    return $user;
}

function require_reseller(): array
{
    $user = current_user();
    if (!$user) {
        redirect_to('/admin/login.php');
    }
    AccessGuard::blockTor();
    if ((string) ($user['role'] ?? '') !== 'reseller') {
        redirect_to('/admin/index.php');
    }
    return $user;
}

function audit(string $event, ?int $actorId = null, ?string $targetType = null, ?string $targetId = null, array $metadata = []): void
{
    $stmt = db()->prepare('INSERT INTO audit_logs (event_type, actor_user_id, target_type, target_id, metadata_json, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
    $stmt->execute([$event, $actorId, $targetType, $targetId, json_encode($metadata, JSON_UNESCAPED_UNICODE), client_ip(), user_agent()]);
}


function consume_request_nonce(string $scope, string $nonce, int $ttlSeconds = 300): bool
{
    $nonce = trim($nonce);
    $ttlSeconds = max(30, min(900, $ttlSeconds));
    if ($nonce === '' || strlen($nonce) > 128 || !preg_match('/^[A-Za-z0-9._:-]{16,128}$/', $nonce)) {
        return false;
    }

    $dir = GUSTAXY_ROOT . '/storage/request-nonces';
    if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) {
        return false;
    }

    $file = $dir . '/' . hash('sha256', $scope . '|' . $nonce) . '.nonce';
    $now = time();
    if (is_file($file)) {
        $mtime = @filemtime($file);
        if ($mtime !== false && ($now - $mtime) >= $ttlSeconds) {
            @unlink($file);
        } else {
            return false;
        }
    }

    $fh = @fopen($file, 'x');
    if ($fh === false) {
        return false;
    }
    fwrite($fh, (string) $now);
    fflush($fh);
    fclose($fh);
    @chmod($file, 0600);
    return true;
}

function rate_limit(string $bucket, int $max, int $windowSeconds): bool
{
    $dir = GUSTAXY_ROOT . '/storage/ratelimit';
    if (!is_dir($dir)) {
        mkdir($dir, 0700, true);
    }
    $file = $dir . '/' . hash('sha256', $bucket . '|' . client_ip()) . '.json';
    $fh = fopen($file, 'c+');
    if (!$fh) {
        return false;
    }
    flock($fh, LOCK_EX);
    $raw = stream_get_contents($fh);
    $state = is_string($raw) ? json_decode($raw, true) : null;
    $now = time();
    if (!is_array($state) || ($now - (int) ($state['started'] ?? 0)) >= $windowSeconds) {
        $state = ['started' => $now, 'count' => 0];
    }
    $state['count']++;
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($state));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    if ((int) $state['count'] > $max) {
        header('Retry-After: ' . max(1, $windowSeconds - ($now - (int) $state['started'])));
        return false;
    }
    return true;
}

/**
 * Consulta o limite sem consumir uma tentativa. Retorna false quando o IP já
 * atingiu $max ocorrências dentro da janela. Use junto com rate_limit(), que
 * registra a ocorrência (ex.: só nas falhas de autenticação).
 */
function rate_limit_peek(string $bucket, int $max, int $windowSeconds): bool
{
    $file = GUSTAXY_ROOT . '/storage/ratelimit/' . hash('sha256', $bucket . '|' . client_ip()) . '.json';
    if (!is_file($file)) {
        return true;
    }
    $raw = @file_get_contents($file);
    $state = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($state) || (time() - (int) ($state['started'] ?? 0)) >= $windowSeconds) {
        return true;
    }
    return (int) ($state['count'] ?? 0) < $max;
}

function method(string $expected): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== $expected) {
        header('Allow: ' . $expected);
        json_response(['error' => 'Método não permitido.'], 405);
    }
}

security_headers();
global_request_shield();
rate_limit_gc();
