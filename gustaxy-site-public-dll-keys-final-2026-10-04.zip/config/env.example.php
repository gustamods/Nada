<?php
declare(strict_types=1);
return [
    'APP_ENV' => 'production',
    'APP_NAME' => 'Gustaxy Admin',
    'APP_URL' => 'https://SEU-DOMINIO.example',
    'APP_KEY' => 'gere-uma-chave-hexadecimal-de-64-caracteres',
    'SETUP_TOKEN' => 'defina-um-token-longo-e-remova-o-instalador',
    'DB_DRIVER' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_PORT' => '3306',
    'DB_NAME' => 'gustaxy',
    'DB_USER' => 'gustaxy_user',
    'DB_PASS' => 'troque-esta-senha',
    'DB_PATH' => __DIR__ . '/../storage/gustaxy.sqlite',
    'COOKIE_SECURE' => true,
    'TRUST_PROXY' => false,
    'CORS_ORIGIN' => '',
    'EXPECTED_CERT_SHA256' => '',
    // Hosts HTTPS autorizados para links de atualização do APK.
    // Vazio = somente o mesmo host de APP_URL.
    'UPDATE_ALLOWED_HOSTS' => [],
    // Token de integração na URL (?token=) vaza em logs. Mantenha false; ligue só
    // temporariamente enquanto migra integrações antigas para o header X-Gustaxy-Api-Token.
    'INTEGRATION_ALLOW_QUERY_TOKEN' => false,
    'API_TOKEN_TTL' => 86400,
    'SESSION_IDLE_TTL' => 1800,
    'SESSION_ABSOLUTE_TTL' => 28800,
    'SESSION_BIND' => true,
    'GLOBAL_RATE_LIMIT' => 240,
    'GLOBAL_RATE_WINDOW' => 60,
    'ACCESS_GUARD_ENABLED' => true,
    'ACCESS_GUARD_BLOCK_TOR' => true,
    'ACCESS_GUARD_TOR_LIST_PATH' => __DIR__ . '/../storage/security/tor_exit_nodes.txt',
    'ACCESS_GUARD_DNSEL' => true,
    'ACCESS_GUARD_SERVER_IP' => '',
    'ACCESS_GUARD_SERVER_PORT' => 443,
    'ACCESS_GUARD_SCORE_THRESHOLD' => 5,
];
