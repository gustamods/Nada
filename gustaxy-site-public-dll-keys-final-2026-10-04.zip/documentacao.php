<?php
declare(strict_types=1);
require __DIR__ . '/config/bootstrap.php';
require __DIR__ . '/app/UpdateService.php';
require __DIR__ . '/app/PublicLayout.php';

$release = UpdateService::active();
public_header('Documentação', 'docs');
?>
<?php if ($release): ?>
<section class="product-card doc-card">
    <div class="product-body">
        <div class="product-meta"><span>APK</span><span>v<?= public_e((string) $release['version']) ?></span></div>
        <h2><?= public_e((string) $release['name']) ?></h2>
        <p>Code <?= (int) $release['version_code'] ?></p>
        <a class="product-download" href="<?= public_e((string) $release['download_url']) ?>" rel="noopener noreferrer" referrerpolicy="no-referrer"><?= public_icon('download') ?> Download</a>
    </div>
</section>
<?php endif; ?>
<?php public_footer(); ?>
