<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/ResourceVaultService.php';
require __DIR__ . '/_layout.php';

$user = require_owner();
$error = '';
$success = '';
$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    if (!rate_limit('admin-resource-publish', 10, 300)) {
        $error = 'Muitas publicações em sequência.';
    } else {
        try {
            $result = ResourceVaultService::importFromUrl((string) ($_POST['resource_url'] ?? ''), (int) $user['id']);
            $success = 'BIN publicado.';
        } catch (Throwable $e) {
            $error = $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível publicar o BIN.';
        }
    }
}

$status = ResourceVaultService::status();
render_header('Texturas', 'textures', $user);
?>
<header class="topbar"><div><h1>Texturas</h1></div></header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="notice success"><?= e($success) ?></p><?php endif; ?>

<section class="section card reveal">
    <div class="section-head">
        <div><h2><?= icon_badge('image') ?> Publicar BIN</h2></div>
        <span class="pill <?= $status['available'] ? 'green' : 'yellow' ?>"><?= $status['available'] ? 'Ativo' : 'Nenhum publicado' ?></span>
    </div>
    <form method="post" class="form-grid" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <label class="wide">URL do BIN
            <input type="url" name="resource_url" maxlength="2048" required placeholder="https://gstxonline.x10.mx/arquivo/gx_7c91e4a2.bin">
        </label>
        <div class="wide"><button class="btn primary" type="submit"><?= icon('download') ?> Publicar</button></div>
    </form>
</section>

<section class="section card reveal">
    <div class="section-head">
        <h2><?= icon_badge('shield') ?> Recurso ativo</h2>
        <span class="pill <?= $status['available'] ? 'green' : 'yellow' ?>"><?= $status['available'] ? 'Disponível' : 'Indisponível' ?></span>
    </div>
    <?php if ($status['available']): ?>
    <div class="status-grid">
        <div class="status-item"><strong>Versão</strong><?= (int) $status['version'] ?></div>
        <div class="status-item"><strong>Tamanho</strong><?= number_format((int) $status['size_bytes'] / 1048576, 2, ',', '.') ?> MB</div>
        <div class="status-item"><strong>SHA-256</strong><span class="break-all tiny"><?= e((string) $status['sha256']) ?></span></div>
    </div>
    <?php else: ?>
    <div class="empty-state"></div>
    <?php endif; ?>
</section>
<?php render_footer(); ?>
