<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Reseller.php';
require dirname(__DIR__) . '/app/KeyService.php';
require __DIR__ . '/_layout.php';

$user = require_owner();
$error = '';
try {
    $keys = Reseller::keysForOwner();
} catch (Throwable) {
    $keys = [];
    $error = 'Execute database/migration_resellers.sql antes de usar esta aba.';
}

render_header('Keys de revendedores', 'reseller-keys', $user);
?>
<header class="topbar">
    <div><h1>Keys de revendedores</h1></div>
</header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<section class="section card reseller-keys-section reveal">
    <div class="section-head"><h2><?= icon_badge('key') ?> Keys geradas</h2></div>
    <div class="table-wrap">
        <table class="management-table card-table">
            <thead><tr><th>Revendedor</th><th>Key</th><th>Expira em</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($keys as $key): ?>
                <tr>
                    <td data-label="Revendedor"><strong><?= e((string) ($key['reseller_username'] ?? '')) ?></strong></td>
                    <td data-label="Key" class="td-stack">
                        <?php if ((string) $key['plaintext_key'] !== ''): ?>
                            <code class="key-plaintext"><?= e((string) $key['plaintext_key']) ?></code>
                            <button type="button" class="btn compact copy-key" data-copy="<?= e((string) $key['plaintext_key']) ?>"><?= icon('copy') ?> Copiar</button>
                        <?php else: ?>
                            <span class="muted">Indisponível</span>
                        <?php endif; ?>
                    </td>
                    <td data-label="Expira em"><?= fmt_date((string) $key['expires_at']) ?></td>
                    <td data-label="Status"><span class="pill <?= (string) $key['status'] === 'active' ? 'green' : 'red' ?>"><?= e((string) $key['status']) ?></span></td>
                </tr>
            <?php endforeach; if (!$keys): ?>
                <tr><td colspan="4">
                    <div class="empty-state">
                        <?= icon('inbox') ?>
                        <strong>Nenhuma key de revendedor</strong>
                        <span>Aparecem aqui assim que um revendedor gerar uma key.</span>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php render_footer(); ?>
