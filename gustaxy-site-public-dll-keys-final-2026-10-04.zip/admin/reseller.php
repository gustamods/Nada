<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Reseller.php';
require dirname(__DIR__) . '/app/KeyService.php';
require __DIR__ . '/_layout.php';

$user = require_reseller();
$error = '';
try {
    $wallet = Reseller::wallet((int) $user['id']);
    $keys = Reseller::keysForReseller((int) $user['id']);
} catch (Throwable) {
    $wallet = ['credits' => 0, 'unlimited' => false];
    $keys = [];
    $error = 'Execute database/migration_resellers.sql antes de usar o painel do revendedor.';
}

render_header('Minhas keys', 'reseller', $user);
?>
<header class="topbar">
    <div><h1>Minhas keys</h1></div>
    <a class="btn primary" href="/admin/reseller_generate.php"><?= icon('plus') ?> Gerar key</a>
</header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<section class="grid">
    <div class="card stat-card reveal">
        <div class="stat-top"><span class="metric-label">Créditos disponíveis</span><?= icon('wallet') ?></div>
        <div class="metric"><?= $wallet['unlimited'] ? '∞' : (int) $wallet['credits'] ?></div>
    </div>
    <div class="card stat-card reveal">
        <div class="stat-top"><span class="metric-label">Keys geradas</span><?= icon('key') ?></div>
        <div class="metric"><?= count($keys) ?></div>
    </div>
</section>
<section class="section card reveal">
    <div class="section-head"><h2><?= icon_badge('key') ?> Keys geradas</h2></div>
    <div class="table-wrap">
        <table class="management-table card-table">
            <thead><tr><th>Key</th><th>Expira em</th><th>Status</th><th>Criada em</th></tr></thead>
            <tbody>
            <?php foreach ($keys as $key): ?>
                <tr>
                    <td data-label="Key" class="td-stack">
                        <?php if ((string) $key['plaintext_key'] !== ''): ?>
                            <code class="key-plaintext"><?= e((string) $key['plaintext_key']) ?></code>
                            <button type="button" class="btn compact copy-key" data-copy="<?= e((string) $key['plaintext_key']) ?>"><?= icon('copy') ?> Copiar</button>
                        <?php else: ?>
                            <span class="muted">Indisponível</span>
                        <?php endif; ?>
                    </td>
                    <td data-label="Expira em"><?= fmt_date((string) $key['expires_at']) ?></td>
                    <td data-label="Status"><span class="pill <?= (string) $key['status'] === 'active' ? 'green' : 'red' ?>"><?= e((string) $key['status']) ?></span></td>
                    <td data-label="Criada em"><?= fmt_date((string) $key['created_at']) ?></td>
                </tr>
            <?php endforeach; if (!$keys): ?>
                <tr><td colspan="4">
                    <div class="empty-state">
                        <?= icon('inbox') ?>
                        <strong>Nenhuma key gerada</strong>
                        <span>Use Gerar key para criar a primeira.</span>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php render_footer(); ?>
