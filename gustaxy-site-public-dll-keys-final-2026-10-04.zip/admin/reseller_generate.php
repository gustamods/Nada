<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Reseller.php';
require dirname(__DIR__) . '/app/Settings.php';
require dirname(__DIR__) . '/app/KeyService.php';
require __DIR__ . '/_layout.php';

$user = require_reseller();
$error = '';
$result = null;
$plans = Reseller::plans();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    if (!rate_limit('reseller-generate', 20, 60)) {
        $error = 'Muitas gerações em sequência. Aguarde um instante.';
    } else {
        try {
            $result = Reseller::generateKey((int) $user['id'], (int) $user['id'], (int) ($_POST['days'] ?? 1));
        } catch (Throwable $exception) {
            $error = $exception instanceof InvalidArgumentException || $exception instanceof RuntimeException ? $exception->getMessage() : 'Não foi possível gerar a key.';
        }
    }
}

try {
    $wallet = Reseller::wallet((int) $user['id']);
} catch (Throwable) {
    $wallet = ['credits' => 0, 'unlimited' => false];
    $error = $error ?: 'Execute database/migration_resellers.sql antes de usar esta tela.';
}

render_header('Gerar key', 'reseller-generate', $user);
?>
<header class="topbar">
    <div><h1>Gerar key</h1></div>
    <span class="pill green"><?= $wallet['unlimited'] ? '∞' : (int) $wallet['credits'] . ' créditos' ?></span>
</header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($result): ?>
<section class="section card reveal">
    <div class="section-head"><h2><?= icon_badge('key') ?> Key gerada</h2><span class="pill green"><?= (int) $result['cost_credits'] ?> crédito(s)</span></div>
    <div class="key-result"><code class="key-plaintext"><?= e((string) $result['key']) ?></code><button type="button" class="btn copy-key" data-copy="<?= e((string) $result['key']) ?>"><?= icon('copy') ?> Copiar</button></div>
    <p class="notice success">Expira em <?= fmt_date((string) $result['expires_at']) ?> · 1 dispositivo</p>
</section>
<?php endif; ?>
<section class="section card reveal">
    <div class="section-head"><h2><?= icon_badge('plus') ?> Nova key</h2></div>
    <form method="post" class="form-grid">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <label>Validade
            <select name="days" required>
                <?php foreach ($plans as $days => $plan): ?>
                    <option value="<?= (int) $days ?>"><?= e((string) $plan['label']) ?> · <?= (int) $plan['credits'] ?> crédito(s)</option>
                <?php endforeach; ?>
            </select>
        </label>
        <div class="field-help">1 key · 1 dispositivo</div>
        <div class="wide"><button class="btn primary" type="submit"><?= icon('plus') ?> Gerar key</button></div>
    </form>
</section>
<?php render_footer(); ?>
