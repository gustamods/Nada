<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require __DIR__ . '/_layout.php';
$user = require_admin();
$type = ($_GET['type'] ?? 'system') === 'entry' ? 'entry' : 'system';
$keyFilter = filter_var($_GET['key'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

if ($type === 'system') {
    $rows = db()->query('SELECT a.*, u.username FROM audit_logs a LEFT JOIN admin_users u ON u.id = a.actor_user_id ORDER BY a.id DESC LIMIT 200')->fetchAll();
} elseif ($keyFilter) {
    $stmt = db()->prepare('SELECT l.*, k.key_prefix FROM login_logs l LEFT JOIN api_keys k ON k.id = l.api_key_id WHERE l.api_key_id = ? ORDER BY l.id DESC LIMIT 200');
    $stmt->execute([$keyFilter]);
    $rows = $stmt->fetchAll();
} else {
    $rows = db()->query('SELECT l.*, k.key_prefix FROM login_logs l LEFT JOIN api_keys k ON k.id = l.api_key_id ORDER BY l.id DESC LIMIT 200')->fetchAll();
}

render_header($type === 'entry' ? 'Logs de entrada' : 'Logs do sistema', $type, $user);
?>
<header class="topbar">
    <div>
        <h1><?= $type === 'entry' ? 'Logs de entrada' : 'Logs do sistema' ?></h1>
        <p class="sub"><?= $type === 'entry' ? 'Dispositivos, navegador, sistema operacional e IP observado.' : 'Ações de login, keys, dispositivos e sessões administrativas.' ?></p>
    </div>
</header>
<section class="section card reveal">
    <div class="table-wrap">
        <table class="card-table">
            <thead>
            <?php if ($type === 'system'): ?>
                <tr><th>Evento</th><th>Administrador</th><th>Alvo</th><th>IP</th><th>Detalhes</th><th>Data</th></tr>
            <?php else: ?>
                <tr><th>Status</th><th>Key</th><th>Dispositivo</th><th>Navegador</th><th>Sistema</th><th>IP</th><th>Data</th></tr>
            <?php endif; ?>
            </thead>
            <tbody>
            <?php if ($type === 'system'): ?>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td data-label="Evento"><span class="pill <?= str_contains((string) $row['event_type'], 'failed') ? 'red' : 'green' ?>"><?= e((string) $row['event_type']) ?></span></td>
                        <td data-label="Administrador"><?= e((string) ($row['username'] ?? 'sistema')) ?></td>
                        <td data-label="Alvo"><?= e((string) ($row['target_type'] ?? '')) ?> #<?= e((string) ($row['target_id'] ?? '')) ?></td>
                        <td data-label="IP"><?= e((string) $row['ip_address']) ?></td>
                        <td data-label="Detalhes" class="td-stack"><code class="break-all"><?= e((string) ($row['metadata_json'] ?? '{}')) ?></code></td>
                        <td data-label="Data"><?= fmt_date((string) $row['created_at']) ?></td>
                    </tr>
                <?php endforeach; if (!$rows): ?>
                    <tr><td colspan="6">
                        <div class="empty-state"><?= icon('inbox') ?><strong>Nenhum evento registrado</strong></div>
                    </td></tr>
                <?php endif; ?>
            <?php else: ?>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td data-label="Status"><span class="pill <?= (int) $row['success'] === 1 ? 'green' : 'red' ?>"><?= (int) $row['success'] === 1 ? 'sucesso' : 'falha' ?></span></td>
                        <td data-label="Key"><?= e((string) ($row['key_prefix'] ?? 'admin')) ?></td>
                        <td data-label="Dispositivo"><code><?= e((string) ($row['device_id_hash'] ? substr($row['device_id_hash'], 0, 16) : 'n/a')) ?></code></td>
                        <td data-label="Navegador"><?= e((string) ($row['browser'] ?? 'Outro')) ?></td>
                        <td data-label="Sistema"><?= e((string) ($row['operating_system'] ?? 'Outro')) ?></td>
                        <td data-label="IP"><?= e((string) $row['ip_address']) ?></td>
                        <td data-label="Data"><?= fmt_date((string) $row['created_at']) ?></td>
                    </tr>
                <?php endforeach; if (!$rows): ?>
                    <tr><td colspan="7">
                        <div class="empty-state"><?= icon('inbox') ?><strong>Nenhuma entrada registrada</strong></div>
                    </td></tr>
                <?php endif; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php render_footer(); ?>
