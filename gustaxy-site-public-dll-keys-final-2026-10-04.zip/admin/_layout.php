<?php
declare(strict_types=1);

date_default_timezone_set('America/Sao_Paulo');

function e(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function icon(string $name, string $class = 'icon'): string
{
    $stroke = 'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
    $icons = [
        'home' => '<polyline points="4 11 12 4 20 11"/><rect x="6" y="11" width="12" height="9" rx="1"/><line x1="10" y1="20" x2="10" y2="15"/><line x1="14" y1="20" x2="14" y2="15"/>',
        'key' => '<circle cx="8" cy="15" r="4"/><line x1="11" y1="12" x2="20" y2="3"/><line x1="16" y1="7" x2="19" y2="10"/><line x1="13" y1="10" x2="16" y2="13"/>',
        'users' => '<path d="M16 20v-1.5a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4V20"/><circle cx="9.5" cy="7" r="3"/><path d="M17 11a3 3 0 1 0-1-5.8"/><path d="M21 20v-1.5a4 4 0 0 0-2.6-3.7"/>',
        'wallet' => '<path d="M4 7.5A2.5 2.5 0 0 1 6.5 5H20a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H6.5A2.5 2.5 0 0 1 4 16.5z"/><path d="M4 8h14.5A2.5 2.5 0 0 1 21 10.5V14h-4a2 2 0 0 1 0-4h4"/><circle cx="17" cy="12" r=".7"/>',
        'settings' => '<circle cx="12" cy="12" r="3.2"/><line x1="12" y1="3" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="21"/><line x1="3" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="21" y2="12"/><line x1="5.6" y1="5.6" x2="7.8" y2="7.8"/><line x1="16.2" y1="16.2" x2="18.4" y2="18.4"/><line x1="5.6" y1="18.4" x2="7.8" y2="16.2"/><line x1="16.2" y1="7.8" x2="18.4" y2="5.6"/>',
        'shield' => '<path d="M12 3l7 3v6c0 4.4-2.9 7.6-7 9-4.1-1.4-7-4.6-7-9V6l7-3z"/><polyline points="9 12 11.3 14.3 15.5 9.5"/>',
        'terminal' => '<rect x="3" y="4" width="18" height="16" rx="2"/><line x1="7" y1="9" x2="17" y2="9"/><line x1="7" y1="13" x2="17" y2="13"/><line x1="7" y1="17" x2="13" y2="17"/>',
        'devices' => '<path d="M10 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4"/><polyline points="14 8 18 12 14 16"/><line x1="18" y1="12" x2="8" y2="12"/>',
        'logout' => '<path d="M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3"/><polyline points="15 8 19 12 15 16"/><line x1="19" y1="12" x2="9" y2="12"/>',
        'check' => '<circle cx="12" cy="12" r="9"/><polyline points="8 12.5 10.5 15 16 9"/>',
        'alert' => '<path d="M12 3.5 21 19H3z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="16" x2="12" y2="16.1"/>',
        'lock' => '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
        'copy' => '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
        'eye' => '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
        'plus' => '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
        'inbox' => '<path d="M4 12h4l2 3h4l2-3h4"/><path d="M5.5 5h13l2.5 7v7a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-7z"/>',
        'pause' => '<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>',
        'activity' => '<polyline points="3 12 8 12 10 6 14 18 16 12 21 12"/>',
        'download' => '<path d="M12 3v11"/><polyline points="8 10 12 14 16 10"/><path d="M5 19h14"/>',
        'image' => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.6"/><path d="M21 16l-5.5-5.5L5 21"/>',
        'sun' => '<circle cx="12" cy="12" r="4.2"/><line x1="12" y1="2.5" x2="12" y2="5"/><line x1="12" y1="19" x2="12" y2="21.5"/><line x1="2.5" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="21.5" y2="12"/><line x1="4.9" y1="4.9" x2="6.6" y2="6.6"/><line x1="17.4" y1="17.4" x2="19.1" y2="19.1"/><line x1="4.9" y1="19.1" x2="6.6" y2="17.4"/><line x1="17.4" y1="6.6" x2="19.1" y2="4.9"/>',
        'moon' => '<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a6.8 6.8 0 0 0 10.5 10.5z"/>',
        'bell' => '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
        'box' => '<path d="M4 7.5 12 3l8 4.5v9L12 21l-8-4.5z"/><path d="M4 7.5 12 12l8-4.5M12 12v9"/>' ,
    ];
    $body = $icons[$name] ?? '';
    return '<svg class="' . e($class) . '" viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true">' . $body . '</svg>';
}

function nav_icon(string $name): string
{
    return icon($name, 'nav-icon');
}

function icon_badge(string $name): string
{
    return '<span class="icon-badge">' . icon($name) . '</span>';
}

function fmt_date(?string $utc): string
{
    $value = trim((string) $utc);
    if ($value === '') {
        return '<span class="muted">—</span>';
    }
    $ts = strtotime($value . ' UTC');
    if ($ts === false) {
        return e($value);
    }
    $brasilia = (new DateTimeImmutable('@' . $ts))->setTimezone(new DateTimeZone('America/Sao_Paulo'));
    return '<time class="dt" data-ts="' . $ts . '">' . e($brasilia->format('d/m/Y \\à\\s H:i')) . ' BRT</time>';
}

function asset_version(string $relativePath): string
{
    static $cache = [];
    if (isset($cache[$relativePath])) {
        return $cache[$relativePath];
    }
    $full = GUSTAXY_ROOT . $relativePath;
    $hash = is_file($full) ? substr((string) md5_file($full), 0, 10) : '';
    if ($hash === '') {
        $hash = (string) time();
    }
    return $cache[$relativePath] = $hash;
}

function brand_logo_data_uri(): string
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $path = GUSTAXY_ROOT . '/assets/img/logo_gstx_proxy.png';
    if (is_file($path) && is_readable($path) && filesize($path) <= 2 * 1024 * 1024) {
        $cached = 'data:image/png;base64,' . base64_encode((string) file_get_contents($path));
    } else {
        $cached = '/assets/img/logo_gstx_proxy.png';
    }
    return $cached;
}

function render_assets(bool $withPickr = true): void
{
    ?>
<link rel="stylesheet" href="/assets/vendor/pico.conditional.min.css?v=<?= asset_version('/assets/vendor/pico.conditional.min.css') ?>">
<link rel="stylesheet" href="/assets/css/app.css?v=<?= asset_version('/assets/css/app.css') ?>">
<?php if ($withPickr): ?>
<link rel="stylesheet" href="/assets/vendor/pickr-nano.min.css?v=<?= asset_version('/assets/vendor/pickr-nano.min.css') ?>">
<?php endif; ?>
<?php if ($withPickr): ?>
<script src="/assets/vendor/pickr.min.js?v=<?= asset_version('/assets/vendor/pickr.min.js') ?>" defer></script>
<?php endif; ?>
<script src="/assets/js/app.js?v=<?= asset_version('/assets/js/app.js') ?>" defer></script>
<?php
}

function render_auth_header(string $title): void
{
    ?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#000000">
<title><?= e($title) ?> · GSTX PROXY</title>
<?php render_assets(false); ?>
</head>
<body class="auth-page">
<main class="auth-card pico reveal">
    <img class="brand-logo" src="<?= e(brand_logo_data_uri()) ?>" alt="GSTX PROXY">
<?php }

function render_auth_footer(): void { ?>
</main>
</body>
</html>
<?php }

function recent_api_notifications(int $limit = 20): array
{
    $file = GUSTAXY_ROOT . '/storage/api/integration-activity.json';
    if (!is_file($file) || !is_readable($file)) {
        return [];
    }
    $data = json_decode((string) @file_get_contents($file), true);
    if (!is_array($data)) {
        return [];
    }
    $rows = array_values(array_filter($data, static function ($row): bool {
        return is_array($row) && !empty($row['created_at']) && !empty($row['token_prefix']);
    }));
    usort($rows, static function (array $a, array $b): int {
        return strcmp((string) ($b['created_at'] ?? ''), (string) ($a['created_at'] ?? ''));
    });
    return array_slice($rows, 0, max(1, min(50, $limit)));
}

function render_notification_center(array $user): void
{
    if ((string) ($user['role'] ?? '') !== 'owner') {
        return;
    }
    $notifications = recent_api_notifications(20);
    ?>
    <div class="notification-center" data-notification-center>
        <button type="button" class="corner-btn notification-btn" data-notification-toggle aria-label="Notificações" title="Notificações" aria-expanded="false">
            <?= icon('bell', 'icon') ?>
            <?php if ($notifications): ?><span class="notification-dot" data-notification-dot></span><?php endif; ?>
        </button>
        <div class="notification-panel" data-notification-panel hidden>
            <div class="notification-list">
                <?php foreach ($notifications as $item): ?>
                    <button type="button" class="notification-item" data-notification-ts="<?= e((string) $item['created_at']) ?>">
                        <span class="notification-icon"><?= icon('terminal', 'icon') ?></span>
                        <span class="notification-copy">
                            <strong><?= e((string) ($item['token_label'] ?: $item['token_prefix'])) ?></strong>
                            <span><?= e(strtoupper((string) ($item['method'] ?? 'GET'))) ?> · <?= e((string) ($item['scope'] ?? 'API')) ?></span>
                            <small><?= fmt_date((string) $item['created_at']) ?></small>
                        </span>
                    </button>
                <?php endforeach; ?>
                <?php if (!$notifications): ?>
                    <div class="notification-empty"><?= icon('check') ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
}

function render_header(string $title, string $active, array $user): void
{
    $role = (string) ($user['role'] ?? 'admin');
    $isOwner = $role === 'owner';
    $isReseller = $role === 'reseller';
    $logo = e(brand_logo_data_uri());
    $absTtl = (int) cfg('SESSION_ABSOLUTE_TTL', 28800);
    $startedAt = (int) ($_SESSION['session_started'] ?? 0);
    $absRemaining = $startedAt > 0 ? max(0, $absTtl - (time() - $startedAt)) : $absTtl;
    ?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#000000">
<title><?= e($title) ?> · GSTX PROXY</title>
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<?php render_assets(true); ?>
</head>
<body data-keepalive-url="/admin/keepalive.php" data-session-idle="<?= (int) cfg('SESSION_IDLE_TTL', 1800) ?>" data-session-abs="<?= $absRemaining ?>">
<div class="shell">
    <div class="nav-overlay" data-nav-overlay></div>
    <div class="corner-tools">
        <?php render_notification_center($user); ?>
        <button type="button" id="accent-picker" class="corner-btn" aria-label="Escolher cor de destaque" title="Cor de destaque"></button>
        <button type="button" id="theme-toggle" class="corner-btn" aria-label="Alternar tema claro/escuro" title="Tema claro/escuro">
            <?= icon('sun', 'icon icon-sun') ?><?= icon('moon', 'icon icon-moon') ?>
        </button>
    </div>
    <header class="app-bar">
        <button type="button" class="nav-toggle" data-nav-toggle aria-expanded="false" aria-controls="primary-nav" aria-label="Abrir menu">
            <span></span><span></span><span></span>
        </button>
        <a class="brand-compact" href="<?= $isReseller ? '/admin/reseller.php' : '/admin/index.php' ?>">
            <img src="<?= $logo ?>" alt="GSTX PROXY">
        </a>
    </header>
    <aside class="sidebar" id="primary-nav" data-sidebar>
        <a class="brand" href="<?= $isReseller ? '/admin/reseller.php' : '/admin/index.php' ?>">
            <img src="<?= $logo ?>" alt="GSTX PROXY">
            <span><?= $isReseller ? 'Revendedor' : ($isOwner ? '∞ Criador' : 'Admin') ?></span>
        </a>
        <nav class="nav">
<?php if ($isReseller): ?>
            <a class="<?= $active === 'reseller' ? 'active' : '' ?>" href="/admin/reseller.php"><?= nav_icon('wallet') ?><span>Minhas keys</span></a>
            <a class="<?= $active === 'reseller-generate' ? 'active' : '' ?>" href="/admin/reseller_generate.php"><?= nav_icon('key') ?><span>Gerar key</span></a>
<?php else: ?>
            <a class="<?= $active === 'keys-list' ? 'active' : '' ?>" href="/admin/keys.php"><?= nav_icon('key') ?><span>Keys geradas</span></a>
            <a class="<?= $active === 'home' ? 'active' : '' ?>" href="/admin/index.php"><?= nav_icon('home') ?><span>Início</span></a>
            <a class="<?= $active === 'keys' ? 'active' : '' ?>" href="/admin/generate.php"><?= nav_icon('key') ?><span>Gerar keys</span></a>
<?php if ($isOwner): ?>
            <a class="<?= $active === 'resellers' ? 'active' : '' ?>" href="/admin/resellers.php"><?= nav_icon('users') ?><span>Contas</span></a>
            <a class="<?= $active === 'reseller-keys' ? 'active' : '' ?>" href="/admin/reseller_keys.php"><?= nav_icon('key') ?><span>Keys de revendedores</span></a>
            <a class="<?= $active === 'settings' ? 'active' : '' ?>" href="/admin/settings.php"><?= nav_icon('settings') ?><span>Configurações</span></a>
            <a class="<?= $active === 'update' ? 'active' : '' ?>" href="/admin/update.php"><?= nav_icon('download') ?><span>Atualização</span></a>
            <a class="<?= $active === 'textures' ? 'active' : '' ?>" href="/admin/texturas.php"><?= nav_icon('image') ?><span>Texturas</span></a>
            <a class="<?= $active === 'dll' ? 'active' : '' ?>" href="/admin/dll.php"><?= nav_icon('box') ?><span>DLL</span></a>
            <a class="<?= $active === 'api' ? 'active' : '' ?>" href="/admin/api.php"><?= nav_icon('terminal') ?><span>API</span></a>
<?php endif; ?>
            <a class="<?= $active === 'security' ? 'active' : '' ?>" href="/admin/security.php"><?= nav_icon('shield') ?><span>Segurança</span></a>
<?php if ($isOwner): ?>
            <a class="<?= $active === 'blacklist' ? 'active' : '' ?>" href="/admin/blacklist.php"><?= nav_icon('lock') ?><span>Lista negra</span></a>
<?php endif; ?>
            <a class="<?= $active === 'system' ? 'active' : '' ?>" href="/admin/logs.php?type=system"><?= nav_icon('terminal') ?><span>Logs do sistema</span></a>
            <a class="<?= $active === 'entry' ? 'active' : '' ?>" href="/admin/logs.php?type=entry"><?= nav_icon('devices') ?><span>Logs de entrada</span></a>
<?php endif; ?>
            <form method="post" action="/admin/logout.php" class="logout-form">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                <button type="submit" class="logout"><?= nav_icon('logout') ?><span>Sair</span></button>
            </form>
        </nav>
        <p class="muted session-label">Sessão: <?= e((string) $user['username']) ?></p>
    </aside>
    <main class="main pico">
<?php }

function render_footer(): void { ?>
    </main>
</div>
</body>
</html>
<?php }
