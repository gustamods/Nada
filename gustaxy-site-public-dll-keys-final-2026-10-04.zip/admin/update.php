<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/UpdateService.php';
require __DIR__ . '/_layout.php';

$user = require_owner();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    if (!rate_limit('admin-apk-update-publish', 10, 300)) {
        $error = 'Muitas publicações em sequência. Aguarde alguns minutos.';
    } else {
        try {
            $name = mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 120);
            $version = mb_substr(trim((string) ($_POST['version'] ?? '')), 0, 32);
            $versionCode = filter_var($_POST['version_code'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 2000000000]]);
            $url = trim((string) ($_POST['download_url'] ?? ''));
            $sha256 = trim((string) ($_POST['sha256'] ?? ''));
            $sizeText = trim((string) ($_POST['size_bytes'] ?? ''));
            $sizeBytes = $sizeText === '' ? null : filter_var($sizeText, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 524288000]]);
            if ($versionCode === false) {
                throw new InvalidArgumentException('Informe um versionCode válido.');
            }
            if ($sizeText !== '' && $sizeBytes === false) {
                throw new InvalidArgumentException('Informe um tamanho válido em bytes ou deixe em branco.');
            }
            UpdateService::publish($name, $version, (int) $versionCode, $url, $sha256, $sizeBytes === false ? null : $sizeBytes, (int) $user['id']);
            $success = 'Atualização publicada. Ela passa a ser a versão ativa para o APK.';
        } catch (Throwable $e) {
            $error = $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível publicar a atualização.';
        }
    }
}

$active = UpdateService::active();
$history = UpdateService::history();
render_header('Atualização do APK', 'update', $user);
?>
<header class="topbar">
    <div>
        <h1>Atualização do APK</h1>
        <p class="sub">Publique a versão que o aplicativo deve oferecer aos usuários.</p>
    </div>
</header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="notice success"><?= e($success) ?></p><?php endif; ?>

<section class="section card reveal">
    <div class="section-head">
        <div>
            <h2><?= icon_badge('inbox') ?> Enviar atualização</h2>
            <p class="muted">O APK recebe estes metadados pela API. O SHA-256 é conferido localmente depois do download.</p>
        </div>
        <span class="pill <?= $active ? 'green' : 'yellow' ?>"><?= $active ? 'Versão ativa' : 'Nenhuma publicada' ?></span>
    </div>
    <form method="post" class="form-grid" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <label>Nome do APK
            <input type="text" name="name" maxlength="120" required placeholder="GUSTAXY PROXY">
        </label>
        <label>Versão APK
            <input type="text" name="version" maxlength="32" required placeholder="1.3.0">
        </label>
        <label>VersionCode
            <input type="number" name="version_code" min="1" max="2000000000" required placeholder="4">
            <span class="field-help">Use um número maior que o da versão atualmente instalada.</span>
        </label>
        <label>Link de download do APK
            <input type="url" name="download_url" maxlength="2048" required placeholder="https://seu-dominio/apk/GustaxyProxy.apk">
            <span class="field-help">HTTPS obrigatório. Por padrão, o host deve ser o mesmo de APP_URL; CDNs autorizadas podem ser configuradas em UPDATE_ALLOWED_HOSTS.</span>
        </label>
        <label>SHA-256 do APK
            <input type="text" name="sha256" minlength="64" maxlength="64" pattern="[A-Fa-f0-9]{64}" required placeholder="64 caracteres hexadecimais">
        </label>
        <label>Tamanho em bytes (opcional)
            <input type="number" name="size_bytes" min="1" max="524288000" placeholder="Ex.: 52428800">
        </label>
        <div class="wide">
            <button class="btn primary" type="submit"><?= icon('check') ?> Enviar atualização</button>
        </div>
    </form>
</section>

<?php if ($active): ?>
<section class="section card reveal">
    <div class="section-head">
        <div>
            <h2><?= icon_badge('activity') ?> Atualização ativa</h2>
            <p class="muted">Esta é a versão retornada pelo endpoint público de atualização.</p>
        </div>
    </div>
    <div class="stats-grid">
        <div class="stat-card"><span>Nome</span><strong><?= e((string) $active['name']) ?></strong></div>
        <div class="stat-card"><span>Versão</span><strong><?= e((string) $active['version']) ?></strong></div>
        <div class="stat-card"><span>VersionCode</span><strong><?= e((string) $active['version_code']) ?></strong></div>
    </div>
    <p class="muted"><strong>SHA-256:</strong> <code><?= e((string) $active['sha256']) ?></code></p>
    <p class="muted"><strong>Link:</strong> <code><?= e((string) $active['download_url']) ?></code></p>
</section>
<?php endif; ?>

<section class="section card reveal">
    <div class="section-head">
        <div>
            <h2><?= icon_badge('key') ?> Histórico de versões</h2>
            <p class="muted">Somente uma publicação fica ativa de cada vez.</p>
        </div>
    </div>
    <?php if (!$history): ?>
        <p class="muted">Nenhuma atualização publicada ainda.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="card-table">
                <thead><tr><th>Nome</th><th>Versão</th><th>Code</th><th>Status</th><th>Publicado em</th><th>Responsável</th></tr></thead>
                <tbody>
                <?php foreach ($history as $row): ?>
                    <tr>
                        <td data-label="Nome"><?= e((string) $row['name']) ?></td>
                        <td data-label="Versão"><?= e((string) $row['version']) ?></td>
                        <td data-label="Code"><?= e((string) $row['version_code']) ?></td>
                        <td data-label="Status"><span class="pill <?= (int) $row['is_active'] === 1 ? 'green' : 'yellow' ?>"><?= (int) $row['is_active'] === 1 ? 'Ativa' : 'Histórico' ?></span></td>
                        <td data-label="Publicado em"><?= fmt_date((string) $row['released_at']) ?></td>
                        <td data-label="Responsável"><?= e((string) $row['created_by_name']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
<?php render_footer(); ?>
