<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/PublicProductService.php';
require dirname(__DIR__) . '/app/PublicLayout.php';
require __DIR__ . '/_layout.php';

$user = require_owner();
$error = '';
$success = '';
$editId = filter_var($_GET['edit'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    if (!rate_limit('admin-dll', 30, 60)) {
        $error = 'Muitas operações em sequência.';
    } else {
        try {
            $action = trim((string) ($_POST['action'] ?? ''));
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if ($action === 'create') {
                PublicProductService::create($_POST, (int) $user['id']);
                $success = 'Item adicionado.';
                $editId = null;
            } elseif ($action === 'update' && $id) {
                PublicProductService::update((int) $id, $_POST, (int) $user['id']);
                $success = 'Item atualizado.';
                $editId = (int) $id;
            } elseif ($action === 'delete' && $id) {
                PublicProductService::delete((int) $id, (int) $user['id']);
                $success = 'Item apagado.';
                $editId = null;
            } elseif ($action === 'toggle' && $id) {
                PublicProductService::setActive((int) $id, (string) ($_POST['active'] ?? '0') === '1', (int) $user['id']);
                $success = 'Status atualizado.';
                $editId = (int) $id;
            } else {
                throw new InvalidArgumentException('Ação inválida.');
            }
        } catch (Throwable $e) {
            $error = $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível concluir a operação.';
        }
    }
}

$items = PublicProductService::listAll(200);
$edit = $editId ? PublicProductService::find((int) $editId) : null;

render_header('DLL', 'dll', $user);
?>
<header class="topbar"><div><h1>DLL</h1></div></header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="notice success"><?= e($success) ?></p><?php endif; ?>

<section class="section card reveal">
    <div class="section-head"><h2><?= icon_badge($edit ? 'settings' : 'plus') ?> <?= $edit ? 'Editar' : 'Adicionar' ?></h2></div>
    <form method="post" class="form-grid" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
        <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>
        <label>Título
            <input name="title" maxlength="120" required value="<?= e((string) ($edit['title'] ?? '')) ?>">
        </label>
        <label>Descrição
            <textarea name="description" maxlength="500" rows="3"><?= e((string) ($edit['description'] ?? '')) ?></textarea>
        </label>
        <label>Link Thumb
            <input type="url" name="thumb_url" maxlength="2048" required value="<?= e((string) ($edit['thumb_url'] ?? '')) ?>">
        </label>
        <label>Classificação
            <select name="platform">
                <?php $platform = (string) ($edit['platform'] ?? 'android'); ?>
                <option value="android" <?= $platform === 'android' ? 'selected' : '' ?>>Android</option>
                <option value="iphone" <?= $platform === 'iphone' ? 'selected' : '' ?>>iPhone</option>
                <option value="pc" <?= $platform === 'pc' ? 'selected' : '' ?>>PC</option>
            </select>
        </label>
        <label>Versão do APK
            <input name="apk_version" maxlength="32" value="<?= e((string) ($edit['apk_version'] ?? '')) ?>">
        </label>
        <label>Tipo de link
            <?php $downloadType = (string) ($edit['download_type'] ?? 'direct'); ?>
            <select name="download_type">
                <option value="direct" <?= $downloadType === 'direct' ? 'selected' : '' ?>>Link direto</option>
                <option value="shortened" <?= $downloadType === 'shortened' ? 'selected' : '' ?>>Link encurtado</option>
            </select>
        </label>
        <label>Link de download
            <input type="url" name="download_url" maxlength="2048" required value="<?= e((string) ($edit['download_url'] ?? '')) ?>">
        </label>
        <label>Ordem
            <input type="number" name="sort_order" min="-1000000" max="1000000" value="<?= (int) ($edit['sort_order'] ?? 0) ?>">
        </label>
        <div class="wide actions">
            <button class="btn primary" type="submit"><?= icon($edit ? 'check' : 'plus') ?> <?= $edit ? 'Salvar' : 'Adicionar' ?></button>
            <?php if ($edit): ?><a class="btn" href="/admin/dll.php">Cancelar</a><?php endif; ?>
        </div>
    </form>
</section>

<section class="section card reveal">
    <div class="section-head"><h2><?= icon_badge('box') ?> Itens</h2><span class="pill"><?= count($items) ?></span></div>
    <div class="table-wrap">
        <table class="management-table card-table">
            <thead><tr><th>Item</th><th>Classificação</th><th>Versão</th><th>Link</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td data-label="Item" class="td-stack"><strong><?= e((string) $item['title']) ?></strong><span class="muted"><?= e((string) $item['description']) ?></span></td>
                    <td data-label="Classificação"><span class="pill"><?= e(public_platform_label((string) $item['platform'])) ?></span></td>
                    <td data-label="Versão"><?= trim((string) $item['apk_version']) !== '' ? 'v' . e((string) $item['apk_version']) : '<span class="muted">—</span>' ?></td>
                    <td data-label="Link"><span class="pill <?= $item['download_type'] === 'shortened' ? 'yellow' : 'green' ?>"><?= $item['download_type'] === 'shortened' ? 'Encurtado' : 'Direto' ?></span></td>
                    <td data-label="Status"><span class="pill <?= (int) $item['is_active'] === 1 ? 'green' : 'red' ?>"><?= (int) $item['is_active'] === 1 ? 'Ativo' : 'Oculto' ?></span></td>
                    <td data-label="Ações" class="td-stack">
                        <div class="actions">
                            <a class="btn compact" href="/admin/dll.php?edit=<?= (int) $item['id'] ?>">Editar</a>
                            <form method="post">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                                <input type="hidden" name="action" value="toggle">
                                <input type="hidden" name="active" value="<?= (int) $item['is_active'] === 1 ? '0' : '1' ?>">
                                <button class="btn compact" type="submit"><?= (int) $item['is_active'] === 1 ? 'Ocultar' : 'Ativar' ?></button>
                            </form>
                            <form method="post">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                                <input type="hidden" name="action" value="delete">
                                <button class="btn compact danger" type="submit" data-confirm="Apagar este item permanentemente?" data-confirm-title="Apagar item" data-confirm-ok="Apagar" data-confirm-target="<?= e((string) $item['title']) ?>">Apagar</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; if (!$items): ?>
                <tr><td colspan="6"><div class="empty-state"><?= icon('inbox') ?></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php render_footer(); ?>
