<?php
declare(strict_types=1);

require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Totp.php';
require dirname(__DIR__) . '/app/Auth.php';
require __DIR__ . '/_layout.php';

AccessGuard::enforce();

if (current_user()) {
    redirect_to('/admin/index.php');
}

if (Auth::hasPendingTwoFactor()) {
    redirect_to('/admin/verify_2fa.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);

    if (trim((string) ($_POST['website'] ?? '')) !== '') {
        audit('admin_login_honeypot', null, 'admin_user', null);
        usleep(random_int(200000, 500000));
        $error = 'Usuário ou senha inválidos.';
    } else {
        $result = Auth::login(
            (string) ($_POST['username'] ?? ''),
            (string) ($_POST['password'] ?? '')
        );

        if ($result['ok']) {
            redirect_to(
                !empty($result['requires_2fa'])
                    ? '/admin/verify_2fa.php'
                    : '/admin/index.php'
            );
        }

        $error = (string) $result['error'];
    }
}
?>
<?php render_auth_header('Entrar'); ?>
    <h1>Entrar no painel</h1>

    <?php if ($error): ?>
        <p class="notice danger"><?= e($error) ?></p>
    <?php endif; ?>

    <form method="post" autocomplete="on">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

        <div class="hp-field" aria-hidden="true">
            <label>
                Website
                <input type="text" name="website" tabindex="-1" autocomplete="off">
            </label>
        </div>

        <input type="hidden" id="js_issued" name="js_issued" value="<?= time() ?>">
        <input type="hidden" id="js_proof" name="js_proof" value="">

        <label>
            Usuário
            <input name="username" required maxlength="190" autocomplete="username" autofocus>
        </label>

        <label>
            Senha
            <input name="password" type="password" required autocomplete="current-password">
        </label>

        <button class="btn primary btn-block" type="submit"><?= icon('key') ?> Entrar</button>
    </form>
<?php render_auth_footer(); ?>
