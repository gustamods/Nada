<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Totp.php';
require dirname(__DIR__) . '/app/Auth.php';
require __DIR__ . '/_layout.php';

if (current_user()) {
    redirect_to('/admin/index.php');
}
if (!Auth::hasPendingTwoFactor()) {
    redirect_to('/admin/login.php');
}
AccessGuard::blockTor();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    if (($_POST['cancel'] ?? '') === '1') {
        Auth::clearPendingTwoFactor();
        redirect_to('/admin/login.php');
    }
    $result = Auth::completeTwoFactor((string) ($_POST['code'] ?? ''));
    if ($result['ok']) {
        redirect_to('/admin/index.php');
    }
    $error = (string) $result['error'];
}
?>
<?php render_auth_header('Verificação em duas etapas'); ?>
    <h1><?= icon('shield') ?> Verificação em duas etapas</h1>
    <p class="muted">Digite o código de 6 dígitos do seu aplicativo autenticador.</p>
    <?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
    <form method="post" autocomplete="off" data-autosubmit-code>
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <label>Código
            <input name="code" inputmode="numeric" pattern="[0-9]{6}" autocomplete="one-time-code" maxlength="6" minlength="6" required autofocus>
        </label>
        <button class="btn primary btn-block" type="submit"><?= icon('check') ?> Confirmar</button>
    </form>
    <form method="post" class="link-form">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="cancel" value="1">
        <button class="link-btn" type="submit">Cancelar e voltar ao login</button>
    </form>
<?php render_auth_footer(); ?>
