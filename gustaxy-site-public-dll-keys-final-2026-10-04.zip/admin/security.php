<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Totp.php';
require dirname(__DIR__) . '/app/Auth.php';
require __DIR__ . '/_layout.php';
$user = require_admin();

$error = '';
$success = '';

$migrationReady = true;
$totpEnabled = false;
$totpConfirmedAt = null;
try {
    $stmt = db()->prepare('SELECT totp_confirmed_at FROM admin_users WHERE id = ? LIMIT 1');
    $stmt->execute([(int) $user['id']]);
    $row = $stmt->fetch();
    $totpConfirmedAt = $row['totp_confirmed_at'] ?? null;
    $totpEnabled = !empty($totpConfirmedAt);
} catch (Throwable) {
    $migrationReady = false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    $formAction = (string) ($_POST['form_action'] ?? '');

    if ($formAction === 'change_password') {
        $current = (string) ($_POST['current_password'] ?? '');
        $new = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['new_password_confirm'] ?? '');
        if ($new !== $confirm) {
            $error = 'A confirmação não coincide com a nova senha.';
        } else {
            $result = Auth::changePassword((int) $user['id'], $current, $new);
            if ($result['ok']) {
                $success = 'Senha atualizada com sucesso.';
            } else {
                $error = (string) $result['error'];
            }
        }
    } elseif ($formAction === 'totp_generate' && $migrationReady) {
        Auth::beginTotpEnrollment((string) $user['username']);
        redirect_to('/admin/security.php');
    } elseif ($formAction === 'totp_cancel') {
        unset($_SESSION['pending_totp_secret']);
        redirect_to('/admin/security.php');
    } elseif ($formAction === 'totp_confirm' && $migrationReady) {
        $result = Auth::confirmTotpEnrollment((int) $user['id'], (string) ($_POST['code'] ?? ''));
        if ($result['ok']) {
            redirect_to('/admin/security.php');
        }
        $error = (string) $result['error'];
    } elseif ($formAction === 'totp_disable' && $migrationReady) {
        $result = Auth::disableTotp((int) $user['id'], (string) ($_POST['current_password'] ?? ''));
        if ($result['ok']) {
            $success = 'Verificação em duas etapas desativada.';
            $totpEnabled = false;
        } else {
            $error = (string) $result['error'];
        }
    }
}

$pendingSecret = (string) ($_SESSION['pending_totp_secret'] ?? '');
$provisioningUri = $pendingSecret !== '' ? Totp::provisioningUri($pendingSecret, (string) $user['username']) : '';

render_header('Segurança', 'security', $user);
?><header class="topbar">
    <div><h1>Segurança da conta</h1></div>
</header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="notice success"><?= e($success) ?></p><?php endif; ?>
<?php if (!$migrationReady): ?>
<p class="notice">A verificação em duas etapas ainda não está disponível: rode <code>database/migration_2fa.sql</code> no banco de dados para habilitar este recurso.</p>
<?php endif; ?>

<section class="section card reveal">
    <div class="section-head">
        <h2><?= icon_badge('lock') ?> Trocar senha</h2>
    </div>
    <form method="post" class="form-grid" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="form_action" value="change_password">
        <label>Senha atual
            <input type="password" name="current_password" required autocomplete="current-password">
        </label>
        <div></div>
        <label>Nova senha
            <span class="field-help">Pelo menos 12 caracteres, única para este painel.</span>
            <input type="password" name="new_password" required minlength="12" autocomplete="new-password">
        </label>
        <label>Confirmar nova senha
            <input type="password" name="new_password_confirm" required minlength="12" autocomplete="new-password">
        </label>
        <div class="wide">
            <button class="btn primary" type="submit"><?= icon('check') ?> Atualizar senha</button>
        </div>
    </form>
</section>

<?php if ($migrationReady): ?>
<section class="section card reveal">
    <div class="section-head">
        <h2><?= icon_badge('shield') ?> Verificação em duas etapas</h2>
        <span class="pill <?= $totpEnabled ? 'green' : 'yellow' ?>"><?= $totpEnabled ? 'Ativa' : 'Desativada' ?></span>
    </div>

    <?php if ($totpEnabled): ?>
        <p class="muted">Ativada em <?= fmt_date((string) $totpConfirmedAt) ?>.</p>
        <form method="post" class="form-grid">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="form_action" value="totp_disable">
            <label>Confirme sua senha para desativar
                <input type="password" name="current_password" required autocomplete="current-password">
            </label>
            <div class="wide">
                <button class="btn danger" type="submit" data-confirm="Desativar a verificação em duas etapas desta conta?">Desativar 2FA</button>
            </div>
        </form>
    <?php elseif ($pendingSecret !== ''): ?>
        <p class="muted">Abra seu app autenticador (Google Authenticator, Aegis, Authy...), escolha "adicionar manualmente" e digite o código secreto abaixo. Depois confirme com o código de 6 dígitos gerado pelo app.</p>
        <div class="secret-box">
            <span class="secret-label">Código secreto</span>
            <code class="secret-value"><?= e(Totp::formatForDisplay($pendingSecret)) ?></code>
        </div>
        <p class="field-help">URI de provisionamento (para importação manual): <code class="muted"><?= e($provisioningUri) ?></code></p>
        <form method="post" class="form-grid">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="form_action" value="totp_confirm">
            <label>Código de 6 dígitos
                <input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" minlength="6" required autocomplete="one-time-code">
            </label>
            <div></div>
            <div class="wide actions">
                <button class="btn primary" type="submit"><?= icon('check') ?> Confirmar e ativar</button>
                <button class="btn" type="submit" name="form_action" value="totp_cancel">Cancelar</button>
            </div>
        </form>
    <?php else: ?>
        <p class="muted">Exige um código de 6 dígitos do seu app autenticador a cada login, além da senha.</p>
        <form method="post">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="form_action" value="totp_generate">
            <button class="btn primary" type="submit"><?= icon('shield') ?> Ativar verificação em duas etapas</button>
        </form>
    <?php endif; ?>
</section>
<?php endif; ?>
<?php render_footer(); ?>
