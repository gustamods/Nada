<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Settings.php';
require dirname(__DIR__) . '/app/Reseller.php';
require __DIR__ . '/_layout.php';
$user = require_admin();
$isOwner = Reseller::isOwner($user);

$totalKeys = (int) db()->query('SELECT COUNT(*) FROM api_keys')->fetchColumn();
$activeKeys = (int) db()->query("SELECT COUNT(*) FROM api_keys WHERE status = 'active' AND expires_at > CURRENT_TIMESTAMP")->fetchColumn();
$pausedKeys = (int) db()->query("SELECT COUNT(*) FROM api_keys WHERE status = 'paused'")->fetchColumn();
$devices = (int) db()->query('SELECT COUNT(*) FROM devices WHERE revoked_at IS NULL')->fetchColumn();
$loginCutoff = cfg('DB_DRIVER', 'mysql') === 'sqlite' ? "datetime('now', '-1 day')" : '(CURRENT_TIMESTAMP - INTERVAL 1 DAY)';
$logins24 = (int) db()->query("SELECT COUNT(*) FROM login_logs WHERE created_at >= $loginCutoff")->fetchColumn();

$maintenance = Settings::maintenance();
$keysArePaused = Settings::keysPaused();
render_header('Início', 'home', $user);
?>
<header class="topbar">
    <a class="btn primary" href="/admin/generate.php"><?= icon('plus') ?> Gerar keys</a>
</header>

<section class="grid">
    <div class="card stat-card reveal">
        <div class="stat-top"><span class="metric-label">Keys criadas</span><?= icon('key') ?></div>
        <div class="metric"><?= $totalKeys ?></div>
    </div>
    <div class="card stat-card reveal">
        <div class="stat-top"><span class="metric-label">Keys ativas</span><?= icon('check') ?></div>
        <div class="metric"><?= $activeKeys ?></div>
    </div>
    <div class="card stat-card reveal">
        <div class="stat-top"><span class="metric-label">Keys pausadas</span><?= icon('pause') ?></div>
        <div class="metric"><?= $pausedKeys ?></div>
    </div>
    <div class="card stat-card reveal">
        <div class="stat-top"><span class="metric-label">Devices ativos</span><?= icon('devices') ?></div>
        <div class="metric"><?= $devices ?></div>
    </div>
    <div class="card stat-card reveal">
        <div class="stat-top"><span class="metric-label">Login em 24h</span><?= icon('activity') ?></div>
        <div class="metric"><?= $logins24 ?></div>
    </div>
</section>

<?php if ($isOwner): ?><section class="section grid two">
    <div class="card reveal">
        <div class="section-head">
            <h2><?= icon_badge('settings') ?> Configuração global</h2>
            <span class="pill <?= $maintenance['enabled'] ? 'yellow' : 'green' ?>"><?= $maintenance['enabled'] ? 'Manutenção on' : 'Off' ?></span>
        </div>
        <a class="btn" href="/admin/settings.php">Abrir configurações</a>
    </div>
    <div class="card reveal">
        <div class="section-head">
            <h2><?= icon_badge('pause') ?> Pausar Keys</h2>
            <span class="pill <?= $keysArePaused ? 'yellow' : 'green' ?>"><?= $keysArePaused ? 'Pausadas' : 'Normais' ?></span>
        </div>
        <p class="muted">Pausa todas as keys ativas.</p>
        <div class="actions">
            <form method="post" action="/admin/action.php">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="return" value="/admin/index.php">
                <button class="btn" name="action" value="global_pause_keys" <?= $keysArePaused ? 'disabled' : '' ?>>Pausar keys</button>
            </form>
            <form method="post" action="/admin/action.php">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="return" value="/admin/index.php">
                <button class="btn primary" name="action" value="global_resume_keys" <?= !$keysArePaused ? 'disabled' : '' ?>>Despausar keys</button>
            </form>
        </div>
    </div>
</section><?php endif; ?>

<section class="section card reveal">
    <div class="section-head">
        <h2><?= icon_badge('key') ?> Keys geradas</h2>
        <a class="btn" href="/admin/keys.php">Ver todas</a>
    </div>
</section>
<?php render_footer(); ?>
