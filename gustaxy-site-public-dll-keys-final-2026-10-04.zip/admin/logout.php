<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Auth.php';
// Só sai por POST com CSRF: um link/imagem em outro site não consegue deslogar o admin.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    redirect_to('/admin/index.php');
}
if (!current_user()) {
    redirect_to('/admin/login.php');
}
verify_csrf($_POST['csrf'] ?? null);
Auth::logout();
redirect_to('/admin/login.php');
