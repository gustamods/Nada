<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Settings.php';
require dirname(__DIR__) . '/app/Blacklist.php';
require __DIR__ . '/_layout.php';

$user = require_owner();
$error = '';
$success = '';
$settings = Settings::all();

function save_uploaded_image(array $upload, string $publicDir, string $prefix): string
{
    $error = (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE);
    $tmp = (string) ($upload['tmp_name'] ?? '');
    if ($error !== UPLOAD_ERR_OK || !is_uploaded_file($tmp)) {
        throw new RuntimeException('Não foi possível receber a imagem enviada.');
    }

    $size = (int) ($upload['size'] ?? 0);
    if ($size <= 0 || $size > 2 * 1024 * 1024) {
        throw new RuntimeException('A imagem deve ter no máximo 2 MB.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string) $finfo->file($tmp);
    $extensions = [
        'image/png' => 'png',
        'image/jpeg' => 'jpg',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
    ];
    if (!isset($extensions[$mime])) {
        throw new RuntimeException('Formato de imagem não permitido. Use PNG, JPG, WEBP ou GIF.');
    }

    $dimensions = @getimagesize($tmp);
    $width = (int) ($dimensions[0] ?? 0);
    $height = (int) ($dimensions[1] ?? 0);
    if (!is_array($dimensions) || $width < 1 || $height < 1 || $width > 4096 || $height > 4096 || ($width * $height) > 16000000) {
        throw new RuntimeException('Dimensões da imagem não permitidas.');
    }

    $directory = GUSTAXY_ROOT . $publicDir;
    if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
        throw new RuntimeException('Não foi possível preparar o diretório de imagens.');
    }

    $filename = $prefix . bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
    $destination = $directory . '/' . $filename;
    if (!move_uploaded_file($tmp, $destination)) {
        throw new RuntimeException('Não foi possível salvar a imagem.');
    }

    @chmod($destination, 0640);
    return rtrim($publicDir, '/') . '/' . $filename;
}

function maintenance_image_data_uri(string $path): string
{
    $path = trim($path);
    if ($path === '' || preg_match('~^[a-z][a-z0-9+.-]*:~i', $path)) {
        return $path;
    }

    $normalized = '/' . ltrim($path, '/');
    $allowedRoots = [
        '/assets/uploads/maintenance/',
        '/assets/uploads/tamper/',
    ];
    $allowed = false;
    foreach ($allowedRoots as $root) {
        if (str_starts_with($normalized, $root)) {
            $allowed = true;
            break;
        }
    }
    if (!$allowed) {
        return '';
    }

    $full = GUSTAXY_ROOT . $normalized;
    if (!is_file($full) || !is_readable($full) || filesize($full) > 2 * 1024 * 1024) {
        return '';
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string) $finfo->file($full);
    if (!in_array($mime, ['image/png', 'image/jpeg', 'image/webp', 'image/gif'], true)) {
        return '';
    }
    return 'data:' . $mime . ';base64,' . base64_encode((string) file_get_contents($full));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    if (!rate_limit('admin-settings-save', 20, 60)) {
        $error = 'Muitas tentativas em sequência. Aguarde um instante.';
    } else {
        $formAction = (string) ($_POST['form_action'] ?? '');
        try {
            if ($formAction === 'maintenance') {
                $enabled = ($_POST['maintenance_enabled'] ?? '') === '1' ? '1' : '0';
                $title = mb_substr(trim((string) ($_POST['maintenance_title'] ?? '')), 0, 120);
                $description = mb_substr(trim((string) ($_POST['maintenance_description'] ?? '')), 0, 1000);
                if ($title === '') {
                    throw new InvalidArgumentException('Informe um título para o diálogo de manutenção.');
                }
                if ($description === '') {
                    throw new InvalidArgumentException('Informe uma descrição para o diálogo de manutenção.');
                }

                $imagePath = (string) ($settings['maintenance_image_path'] ?? '');
                if (isset($_FILES['maintenance_image']) && (int) $_FILES['maintenance_image']['error'] !== UPLOAD_ERR_NO_FILE) {
                    $imagePath = save_uploaded_image($_FILES['maintenance_image'], '/assets/uploads/maintenance', 'maintenance_');
                }

                Settings::set('maintenance_enabled', $enabled, (int) $user['id']);
                Settings::set('maintenance_title', $title, (int) $user['id']);
                Settings::set('maintenance_description', $description, (int) $user['id']);
                Settings::set('maintenance_image_path', $imagePath, (int) $user['id']);
                audit('settings_updated', (int) $user['id'], 'global', 'maintenance', [
                    'enabled' => $enabled,
                    'has_image' => $imagePath !== '',
                ]);
                $success = 'Configurações de manutenção salvas.';
            } elseif ($formAction === 'tamper_security') {
                $tamperEnabled = ($_POST['tamper_notice_enabled'] ?? '') === '1' ? '1' : '0';
                $tamperMode = (string) ($_POST['tamper_notice_mode'] ?? 'automatic');
                if (!in_array($tamperMode, ['automatic', 'manual'], true)) {
                    $tamperMode = 'automatic';
                }

                $tamperTitle = mb_substr(trim((string) ($_POST['tamper_notice_title'] ?? '')), 0, 120);
                $tamperDescription = mb_substr(trim((string) ($_POST['tamper_notice_description'] ?? '')), 0, 1000);
                $tamperImagePath = (string) ($settings['tamper_notice_image_path'] ?? '');
                if (isset($_FILES['tamper_notice_image']) && (int) $_FILES['tamper_notice_image']['error'] !== UPLOAD_ERR_NO_FILE) {
                    $tamperImagePath = save_uploaded_image($_FILES['tamper_notice_image'], '/assets/uploads/tamper', 'tamper_');
                }

                if ($tamperMode === 'manual') {
                    if ($tamperTitle === '') {
                        throw new InvalidArgumentException('Informe o título do aviso de APK modificado.');
                    }
                    if ($tamperDescription === '') {
                        throw new InvalidArgumentException('Informe a mensagem do aviso de APK modificado.');
                    }
                }
                if ($tamperEnabled && $tamperImagePath === '') {
                    throw new InvalidArgumentException('Envie uma imagem para ativar o aviso de APK modificado.');
                }

                $threshold = filter_var($_POST['tamper_blacklist_threshold'] ?? 3, FILTER_VALIDATE_INT, [
                    'options' => ['min_range' => 1, 'max_range' => 20],
                ]);
                if ($threshold === false) {
                    throw new InvalidArgumentException('O limite automático deve estar entre 1 e 20 ocorrências.');
                }
                $blacklistEnabled = ($_POST['tamper_blacklist_enabled'] ?? '') === '1' ? '1' : '0';

                Settings::set('tamper_notice_enabled', $tamperEnabled, (int) $user['id']);
                Settings::set('tamper_notice_mode', $tamperMode, (int) $user['id']);
                Settings::set('tamper_notice_title', $tamperTitle !== '' ? $tamperTitle : 'Aplicativo modificado', (int) $user['id']);
                Settings::set('tamper_notice_description', $tamperDescription !== '' ? $tamperDescription : 'Foi detectada uma alteração não autorizada neste aplicativo.', (int) $user['id']);
                Settings::set('tamper_notice_image_path', $tamperImagePath, (int) $user['id']);
                Settings::set('tamper_blacklist_threshold', (string) $threshold, (int) $user['id']);
                Settings::set('tamper_blacklist_enabled', $blacklistEnabled, (int) $user['id']);
                audit('settings_updated', (int) $user['id'], 'global', 'apk_security', [
                    'notice_enabled' => $tamperEnabled,
                    'mode' => $tamperMode,
                    'has_image' => $tamperImagePath !== '',
                    'blacklist_enabled' => $blacklistEnabled,
                    'threshold' => (int) $threshold,
                ]);
                $success = 'Aviso e segurança do APK salvos.';
            } else {
                throw new InvalidArgumentException('Formulário inválido.');
            }
            $settings = Settings::all();
        } catch (Throwable $e) {
            $error = $e instanceof InvalidArgumentException || $e instanceof RuntimeException
                ? $e->getMessage()
                : 'Não foi possível salvar as configurações.';
            $settings = Settings::all();
        }
    }
}

$maintenance = Settings::maintenance();
$tamperEnabled = (string) ($settings['tamper_notice_enabled'] ?? '0') === '1';
$tamperMode = (string) ($settings['tamper_notice_mode'] ?? 'automatic');
$tamperTitle = (string) ($settings['tamper_notice_title'] ?? 'Aplicativo modificado');
$tamperDescription = (string) ($settings['tamper_notice_description'] ?? 'Foi detectada uma alteração não autorizada neste aplicativo.');
$tamperImagePath = (string) ($settings['tamper_notice_image_path'] ?? '');
$tamperThreshold = (int) ($settings['tamper_blacklist_threshold'] ?? 3);
$tamperBlacklistEnabled = (string) ($settings['tamper_blacklist_enabled'] ?? '1') === '1';

render_header('Configurações', 'settings', $user);
?>
<header class="topbar">
    <div><h1>Manutenção</h1></div>
</header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="notice success"><?= e($success) ?></p><?php endif; ?>

<section class="section card reveal">
    <div class="section-head">
        <h2><?= icon_badge('alert') ?> Modo de manutenção</h2>
        <span class="pill <?= $maintenance['enabled'] ? 'yellow' : 'green' ?>"><?= $maintenance['enabled'] ? 'Ativo' : 'Desativado' ?></span>
    </div>
    <form method="post" enctype="multipart/form-data" class="form-grid">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="form_action" value="maintenance">
        <label class="toggle-row">
            <input type="checkbox" role="switch" name="maintenance_enabled" value="1" <?= $maintenance['enabled'] ? 'checked' : '' ?>>
            <span>Ativar modo de manutenção</span>
        </label>
        <div></div>
        <label>Título
            <input type="text" name="maintenance_title" maxlength="120" value="<?= e((string) $settings['maintenance_title']) ?>" required>
        </label>
        <label>Descrição
            <textarea name="maintenance_description" maxlength="1000" required><?= e((string) $settings['maintenance_description']) ?></textarea>
        </label>
        <label>Imagem
            <span class="field-help">PNG, JPG, WEBP ou GIF; máximo de 2 MB. O nome do arquivo no upload pode ser qualquer um.</span>
            <input type="file" name="maintenance_image" accept="image/png,image/jpeg,image/webp,image/gif">
        </label>
        <div class="preview-card">
            <?php $maintenancePreview = maintenance_image_data_uri((string) $maintenance['image_path']); ?>
            <?php if ($maintenancePreview): ?>
                <img src="<?= e($maintenancePreview) ?>" alt="Imagem atual da manutenção">
                <span class="muted">Imagem atual</span>
            <?php else: ?>
                <?= icon('image') ?>
                <span class="muted">Nenhuma imagem configurada.</span>
            <?php endif; ?>
        </div>
        <div class="wide"><button class="btn primary" type="submit"><?= icon('check') ?> Salvar</button></div>
    </form>
</section>

<section class="section card reveal">
    <div class="section-head">
        <div>
            <h2><?= icon_badge('shield') ?> Aviso de APK modificado</h2>
            <p class="muted">O servidor contabiliza falhas de integridade por dispositivo. O aviso é exibido uma vez no limite definido e o dispositivo pode ser bloqueado automaticamente.</p>
        </div>
        <span class="pill <?= $tamperEnabled ? 'green' : 'yellow' ?>"><?= $tamperEnabled ? 'Ativo' : 'Desativado' ?></span>
    </div>
    <form method="post" enctype="multipart/form-data" class="form-grid">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="form_action" value="tamper_security">
        <label class="toggle-row">
            <input type="checkbox" role="switch" name="tamper_notice_enabled" value="1" <?= $tamperEnabled ? 'checked' : '' ?>>
            <span>Ativar aviso após detecções de integridade</span>
        </label>
        <div></div>
        <label>Modo
            <select name="tamper_notice_mode">
                <option value="automatic" <?= $tamperMode === 'automatic' ? 'selected' : '' ?>>Automático</option>
                <option value="manual" <?= $tamperMode === 'manual' ? 'selected' : '' ?>>Manual</option>
            </select>
            <span class="field-help">Automático usa o texto padrão. Manual usa o título e a mensagem definidos abaixo.</span>
        </label>
        <label>Imagem do aviso
            <span class="field-help">PNG, JPG, WEBP ou GIF; máximo de 2 MB. O arquivo recebe um nome aleatório seguro no servidor.</span>
            <input type="file" name="tamper_notice_image" accept="image/png,image/jpeg,image/webp,image/gif">
        </label>
        <label>Título (manual)
            <input type="text" name="tamper_notice_title" maxlength="120" value="<?= e($tamperTitle) ?>">
        </label>
        <label>Mensagem (manual)
            <textarea name="tamper_notice_description" maxlength="1000"><?= e($tamperDescription) ?></textarea>
        </label>
        <label>Banimento automático após
            <input type="number" name="tamper_blacklist_threshold" min="1" max="20" value="<?= e((string) $tamperThreshold) ?>">
            <span class="field-help">Padrão: 3 ocorrências do mesmo dispositivo. Eventos repetidos do mesmo lançamento não são contados duas vezes.</span>
        </label>
        <label class="toggle-row">
            <input type="checkbox" role="switch" name="tamper_blacklist_enabled" value="1" <?= $tamperBlacklistEnabled ? 'checked' : '' ?>>
            <span>Adicionar automaticamente à lista negra</span>
        </label>
        <div class="preview-card">
            <?php $tamperPreview = maintenance_image_data_uri($tamperImagePath); ?>
            <?php if ($tamperPreview): ?>
                <img src="<?= e($tamperPreview) ?>" alt="Imagem atual do aviso de APK modificado">
                <span class="muted">Imagem atual</span>
            <?php else: ?>
                <?= icon('image') ?>
                <span class="muted">Nenhuma imagem configurada.</span>
            <?php endif; ?>
        </div>
        <div class="wide"><button class="btn primary" type="submit"><?= icon('check') ?> Salvar aviso e segurança</button></div>
    </form>
</section>

<section class="section card reveal">
    <div class="section-head">
        <div>
            <h2><?= icon_badge('pause') ?> Pausar keys</h2>
            <p class="muted">Congela o tempo restante das keys ativas. Ao despausar, volta a contar normalmente.</p>
        </div>
        <span class="pill <?= Settings::keysPaused() ? 'yellow' : 'green' ?>"><?= Settings::keysPaused() ? 'Pausadas' : 'Normais' ?></span>
    </div>
    <div class="actions">
        <form method="post" action="/admin/action.php">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="return" value="/admin/settings.php">
            <button class="btn" name="action" value="global_pause_keys" <?= Settings::keysPaused() ? 'disabled' : '' ?>>Pausar todas as keys</button>
        </form>
        <form method="post" action="/admin/action.php">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="return" value="/admin/settings.php">
            <button class="btn primary" name="action" value="global_resume_keys" <?= !Settings::keysPaused() ? 'disabled' : '' ?>>Despausar todas as keys</button>
        </form>
    </div>
</section>
<?php render_footer(); ?>
