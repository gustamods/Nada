<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Settings.php';
require dirname(__DIR__) . '/app/KeyService.php';
require __DIR__ . '/_layout.php';
$user = require_admin();

$keys = db()->query(
    "SELECT k.id, k.key_prefix, k.key_ciphertext, k.max_devices, k.expires_at, k.status, k.created_at, k.paused_at, k.pause_started_at, k.revoked_at,
            SUM(CASE WHEN d.id IS NOT NULL AND d.revoked_at IS NULL THEN 1 ELSE 0 END) AS used_devices
     FROM api_keys k
     LEFT JOIN devices d ON d.api_key_id = k.id
     GROUP BY k.id, k.key_prefix, k.key_ciphertext, k.max_devices, k.expires_at, k.status, k.created_at, k.paused_at, k.pause_started_at, k.revoked_at
     ORDER BY k.id DESC
     LIMIT 100"
)->fetchAll();

$devicesByKey = [];
if ($keys) {
    $ids = array_map(static fn(array $key): int => (int) $key['id'], $keys);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare("SELECT id, api_key_id, device_name, app_version, android_version, device_id_hash, first_seen_at, last_seen_at, login_count, revoked_at FROM devices WHERE api_key_id IN ($placeholders) ORDER BY last_seen_at DESC");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $device) {
        $devicesByKey[(int) $device['api_key_id']][] = $device;
    }
}

$statusLabels = ['active' => 'Ativa', 'paused' => 'Pausada', 'expired' => 'Expirada', 'revoked' => 'Desativada'];
$statusCounts = ['active' => 0, 'paused' => 0, 'expired' => 0, 'revoked' => 0];
foreach ($keys as $countedKey) {
    $countedStatus = (string) $countedKey['status'];
    if ($countedStatus === 'active' && strtotime((string) $countedKey['expires_at'] . ' UTC') <= time()) {
        $countedStatus = 'expired';
    }
    if (isset($statusCounts[$countedStatus])) {
        $statusCounts[$countedStatus]++;
    }
}

render_header('Keys geradas', 'keys-list', $user);
?>
<header class="topbar">
    <div class="keys-heading"><h1>Keys geradas</h1></div>
    <div class="keys-tools">
        <label class="keys-search" aria-label="Pesquisar keys">
            <?= icon('eye', 'icon') ?>
            <input type="search" id="keys-search" autocomplete="off" placeholder="Pesquisar">
        </label>
        <div class="filter-chips" role="group" aria-label="Filtrar por status">
            <button type="button" class="chip" data-key-filter="all" aria-pressed="true">Todas <span><?= count($keys) ?></span></button>
            <?php foreach (['active' => 'Ativas', 'paused' => 'Pausadas', 'expired' => 'Expiradas', 'revoked' => 'Desativadas'] as $chipStatus => $chipLabel): ?>
                <button type="button" class="chip" data-key-filter="<?= $chipStatus ?>" aria-pressed="false"><?= $chipLabel ?> <span><?= (int) $statusCounts[$chipStatus] ?></span></button>
            <?php endforeach; ?>
        </div>
        <a class="btn primary" href="/admin/generate.php"><?= icon('plus') ?> Gerar key</a>
    </div>
</header>

<form method="post" action="/admin/action.php" id="keys-bulk-form" class="keys-bulk" data-no-lock>
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="return" value="/admin/keys.php">
    <div class="keys-bulk-main"><span data-selected-count>0 selecionadas</span></div>
    <div class="keys-bulk-actions">
        <button class="btn compact" type="submit" name="bulk_action" value="pause" data-bulk-require="active">Pausar</button>
        <button class="btn compact" type="submit" name="bulk_action" value="resume" data-bulk-require="paused">Despausar</button>
        <button class="btn compact danger" type="submit" name="bulk_action" value="revoke" data-bulk-confirm="Desativar as keys selecionadas e revogar seus tokens?">Desativar</button>
        <button class="btn compact danger" type="submit" name="bulk_action" value="delete_key" data-bulk-confirm="Excluir permanentemente as keys selecionadas? Esta ação não pode ser desfeita.">Excluir</button>
    </div>
</form>

<section class="section card reveal">
    <div class="section-head">
        <h2><?= icon_badge('key') ?> Todas as keys</h2>
        <span class="pill"><?= count($keys) ?> no total</span>
    </div>
    <div class="table-wrap">
        <table class="management-table card-table">
            <thead>
                <tr><th class="check-cell"><input type="checkbox" id="keys-select-all" aria-label="Selecionar todas"></th><th>Key</th><th>Uso</th><th>Expira em</th><th>Status</th><th>Dispositivos</th><th>Ações</th></tr>
            </thead>
            <tbody>
            <?php foreach ($keys as $key):
                $keyId = (int) $key['id'];
                $used = (int) $key['used_devices'];
                $max = (int) $key['max_devices'];
                $status = (string) $key['status'];
                if ($status === 'active' && strtotime((string) $key['expires_at'] . ' UTC') <= time()) {
                    $status = 'expired';
                }
                $occupancy = $used === 0 ? 'Livre' : ($used < $max ? 'Parcial' : 'Cheia');
                $occupancyClass = $used === 0 ? 'green' : ($used < $max ? 'yellow' : 'red');
                $statusClass = $status === 'active' ? 'green' : ($status === 'paused' ? 'yellow' : 'red');
                $ciphertext = (string) ($key['key_ciphertext'] ?? '');
                $plain = $ciphertext !== '' ? KeyService::decryptKey($ciphertext) : '';
                $activeDevices = array_values(array_filter($devicesByKey[$keyId] ?? [], static fn(array $d): bool => empty($d['revoked_at'])));
            ?>
                <tr data-key-status="<?= e($status) ?>" data-key-id="<?= $keyId ?>" data-key-search="<?= e(strtolower(trim(
                    $plain . ' ' .
                    (string) ($key['key_prefix'] ?? '') . ' ' .
                    (string) ($statusLabels[$status] ?? $status) . ' ' .
                    implode(' ', array_map(static fn(array $d): string => implode(' ', [
                        (string) ($d['device_name'] ?? ''),
                        (string) ($d['android_version'] ?? ''),
                        (string) ($d['app_version'] ?? ''),
                        (string) ($d['device_id_hash'] ?? ''),
                    ]), $activeDevices))
                ))) ?>">
                    <td data-label="Selecionar" class="check-cell"><input type="checkbox" class="key-select" value="<?= $keyId ?>" aria-label="Selecionar key <?= e($plain !== '' ? $plain : (string) $key['key_prefix']) ?>"></td>
                    <td data-label="Key" class="td-stack">
                        <span class="key-cell">
                            <?php if ($plain !== ''): ?>
                                <code class="key-plaintext"><?= e($plain) ?></code>
                                <button type="button" class="btn compact copy-key" data-copy="<?= e($plain) ?>"><?= icon('copy') ?> Copiar</button>
                            <?php else: ?>
                                <span class="muted">Indisponível</span>
                            <?php endif; ?>
                        </span>
                    </td>
                    <td data-label="Uso"><span class="pill <?= $occupancyClass ?>"><?= $occupancy ?></span><span class="muted"><?= $used ?>/<?= $max ?></span></td>
                    <td data-label="Expira em"><?= fmt_date((string) $key['expires_at']) ?></td>
                    <td data-label="Status"><span class="pill <?= $statusClass ?>"><?= e($statusLabels[$status] ?? $status) ?></span></td>
                    <td data-label="Dispositivos" class="td-stack">
                        <?php if (!$activeDevices): ?>
                            <span class="muted">Nenhum device vinculado</span>
                        <?php else: ?>
                        <details>
                            <summary><?= e((string) (($activeDevices[0]['device_name'] ?? '') ?: 'Android')) ?><?= count($activeDevices) > 1 ? ' <span class="muted">+' . (count($activeDevices) - 1) . '</span>' : '' ?></summary>
                            <div class="device-list details-panel">
                                <?php foreach ($activeDevices as $device): ?>
                                    <div class="device-card">
                                        <div>
                                            <span class="dev-name"><?= e((string) ($device['device_name'] ?: 'Android')) ?></span>
                                            <span class="muted"> · <?= e((string) ($device['android_version'] ?: 'versão desconhecida')) ?></span><br>
                                            <small class="muted">Último acesso <?= fmt_date((string) $device['last_seen_at']) ?> · <?= (int) $device['login_count'] ?> login(s)</small>
                                        </div>
                                        <div class="actions">
                                            <form method="post" action="/admin/action.php">
                                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                                <input type="hidden" name="id" value="<?= (int) $device['id'] ?>">
                                                <input type="hidden" name="return" value="/admin/keys.php">
                                                <button class="btn compact danger" name="action" value="reset_device" data-confirm="Resetar este dispositivo e exigir novo vínculo?" data-confirm-title="Resetar dispositivo" data-confirm-ok="Resetar" data-confirm-target="<?= e($plain !== '' ? $plain : (string) $key['key_prefix']) ?>">Resetar device</button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </details>
                        <?php endif; ?>
                    </td>
                    <td data-label="Ações" class="td-stack td-actions">
                        <div class="actions">
                            <form method="post" action="/admin/action.php">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="id" value="<?= $keyId ?>">
                                <input type="hidden" name="return" value="/admin/keys.php">
                                <?php if ($status === 'active'): ?>
                                    <button class="btn compact" name="action" value="pause"><?= icon('pause') ?> Pausar</button>
                                <?php elseif ($status === 'paused'): ?>
                                    <button class="btn compact" name="action" value="resume"><?= icon('check') ?> Despausar</button>
                                <?php endif; ?>
                                <?php if ($status !== 'revoked'): ?>
                                    <button class="btn compact danger" name="action" value="revoke" data-confirm="Desativar esta key e revogar seus tokens?" data-confirm-title="Desativar key" data-confirm-ok="Desativar" data-confirm-target="<?= e($plain !== '' ? $plain : (string) $key['key_prefix']) ?>"><?= icon('lock') ?> Desativar</button>
                                <?php endif; ?>
                                <button class="btn compact danger" name="action" value="reset_key" data-confirm="Resetar todos os devices desta key?" data-confirm-title="Resetar key" data-confirm-ok="Resetar" data-confirm-target="<?= e($plain !== '' ? $plain : (string) $key['key_prefix']) ?>"><?= icon('devices') ?> Resetar</button>
                                <button class="btn compact danger" name="action" value="delete_key" data-confirm="Excluir esta key permanentemente? Esta ação não pode ser desfeita." data-confirm-title="Excluir key" data-confirm-ok="Excluir" data-confirm-target="<?= e($plain !== '' ? $plain : (string) $key['key_prefix']) ?>"><?= icon('alert') ?> Excluir</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; if (!$keys): ?>
                <tr><td colspan="7">
                    <div class="empty-state">
                        <?= icon('inbox') ?>
                        <strong>Nenhuma key criada</strong>
                        <span>Use Gerar key para criar a primeira.</span>
                    </div>
                </td></tr>
            <?php endif; ?>
            <tr id="keys-no-results" hidden><td colspan="7">
                <div class="empty-state"><?= icon('inbox') ?></div>
            </td></tr>
            </tbody>
        </table>
    </div>
</section>
<?php render_footer(); ?>
