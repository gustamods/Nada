<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Settings.php';
require dirname(__DIR__) . '/app/KeyService.php';
require dirname(__DIR__) . '/app/UpdateService.php';
require dirname(__DIR__) . '/app/ResourceVaultService.php';
require dirname(__DIR__) . '/app/IntegrationTokenService.php';
require __DIR__ . '/_layout.php';

$user = require_owner();
$error = '';
$createdToken = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    if (!rate_limit('admin-integration-token', 10, 300)) {
        $error = 'Muitas operações em sequência.';
    } else {
        try {
            $action = (string) ($_POST['action'] ?? '');
            if ($action === 'create_token') {
                $scopes = isset($_POST['scopes']) && is_array($_POST['scopes']) ? $_POST['scopes'] : [];
                $createdToken = IntegrationTokenService::create(
                    (string) ($_POST['label'] ?? ''),
                    $scopes,
                    (int) ($_POST['expires_days'] ?? 90),
                    (int) $user['id'],
                    (string) ($_POST['ip_allowlist'] ?? '')
                );
            } elseif ($action === 'revoke_token') {
                IntegrationTokenService::revoke((string) ($_POST['id'] ?? ''), (int) $user['id']);
            }
        } catch (Throwable $e) {
            $error = $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível concluir a operação.';
        }
    }
}

$tokens = IntegrationTokenService::all();
$base = rtrim((string) cfg('APP_URL', ''), '/');
$endpoints = [
    ['method' => 'GET', 'path' => '/api/v1/config', 'auth' => 'Público', 'desc' => 'Configuração pública e manutenção.', 'scope' => '—'],
    ['method' => 'GET', 'path' => '/api/v1/update?version_code=15', 'auth' => 'Público', 'desc' => 'Verifica atualização disponível para o APK.', 'scope' => '—'],
    ['method' => 'POST', 'path' => '/api/v1/auth/login', 'auth' => 'APK', 'desc' => 'Valida key, dispositivo e cria sessão do aplicativo.', 'scope' => '—'],
    ['method' => 'POST', 'path' => '/api/v1/integrity/report', 'auth' => 'APK', 'desc' => 'Registra evento de integridade e bloqueio.', 'scope' => '—'],
    ['method' => 'GET', 'path' => '/api/v1/auth/me', 'auth' => 'Bearer', 'desc' => 'Retorna o estado da sessão do APK.', 'scope' => '—'],
    ['method' => 'POST', 'path' => '/api/v1/auth/logout', 'auth' => 'Bearer', 'desc' => 'Revoga a sessão do APK.', 'scope' => '—'],
    ['method' => 'GET', 'path' => '/api/v1/resources/manifest', 'auth' => 'APK', 'desc' => 'Entrega metadados e um ticket curto para o BIN privado.', 'scope' => '—'],
    ['method' => 'GET', 'path' => '/api/v1/resources/download?ticket=...', 'auth' => 'Ticket', 'desc' => 'Baixa o BIN. Ticket único e vinculado ao dispositivo.', 'scope' => '—'],
    ['method' => 'GET', 'path' => '/api/v1/integration/status', 'auth' => 'Token', 'desc' => 'Status da API, key global, atualização e BIN.', 'scope' => 'read'],
    ['method' => 'POST', 'path' => '/api/v1/integration/keys/generate', 'auth' => 'Token', 'desc' => 'Gera uma ou várias keys.', 'scope' => 'keys.generate'],
    ['method' => 'GET', 'path' => '/api/v1/integration/keys/list', 'auth' => 'Token', 'desc' => 'Lista metadados das keys sem expor a key completa.', 'scope' => 'read'],
    ['method' => 'POST', 'path' => '/api/v1/integration/keys/pause', 'auth' => 'Token', 'desc' => 'Pausa uma key.', 'scope' => 'keys.manage'],
    ['method' => 'POST', 'path' => '/api/v1/integration/keys/resume', 'auth' => 'Token', 'desc' => 'Retoma uma key.', 'scope' => 'keys.manage'],
    ['method' => 'POST', 'path' => '/api/v1/integration/keys/revoke', 'auth' => 'Token', 'desc' => 'Revoga uma key.', 'scope' => 'keys.manage'],
    ['method' => 'POST', 'path' => '/api/v1/integration/keys/reset-device', 'auth' => 'Token', 'desc' => 'Libera o vínculo de dispositivo da key.', 'scope' => 'keys.manage'],
    ['method' => 'POST', 'path' => '/api/v1/integration/keys/reset', 'auth' => 'Token', 'desc' => 'Reseta os dispositivos vinculados à key.', 'scope' => 'keys.manage'],
    ['method' => 'POST', 'path' => '/api/v1/integration/keys/delete', 'auth' => 'Token', 'desc' => 'Exclui uma key.', 'scope' => 'keys.manage'],
    ['method' => 'POST', 'path' => '/api/v1/integration/keys/global-pause', 'auth' => 'Token', 'desc' => 'Ativa a pausa global.', 'scope' => 'keys.manage'],
    ['method' => 'POST', 'path' => '/api/v1/integration/keys/global-resume', 'auth' => 'Token', 'desc' => 'Desativa a pausa global.', 'scope' => 'keys.manage'],
    ['method' => 'POST', 'path' => '/api/v1/update/publish', 'auth' => 'Token', 'desc' => 'Publica uma atualização do APK por link HTTPS.', 'scope' => 'updates.publish'],
    ['method' => 'POST', 'path' => '/api/v1/resources/publish', 'auth' => 'Token', 'desc' => 'Importa o BIN por link e mantém a cópia ativa em storage privado.', 'scope' => 'resources.publish'],
];

render_header('API', 'api', $user);
?>
<header class="topbar">
    <div>
        <h1>API</h1>
        <p class="sub">Endpoints, permissões e tokens de integração.</p>
    </div>
</header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($createdToken): ?>
<section class="section card reveal">
    <div class="section-head"><h2><?= icon_badge('key') ?> Token criado</h2><span class="pill green">Exibir uma vez</span></div>
    <div class="secret-box">
        <span class="secret-label">TOKEN</span>
        <span class="secret-value" id="new-api-token"><?= e((string) $createdToken['token']) ?></span>
        <button type="button" class="btn compact" data-copy="<?= e((string) $createdToken['token']) ?>"><?= icon('copy') ?> Copiar</button>
    </div>
    <p class="muted tiny">Depois desta tela o valor completo não é recuperável. Guarde no seu bot.</p>
</section>
<?php endif; ?>

<section class="section card reveal">
    <div class="section-head"><h2><?= icon_badge('shield') ?> Tokens</h2></div>
    <form method="post" class="form-grid" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="create_token">
        <label>Nome
            <input type="text" name="label" maxlength="80" required placeholder="Bot Telegram">
        </label>
        <label>Validade
            <select name="expires_days">
                <option value="7">7 dias</option>
                <option value="30">30 dias</option>
                <option value="90" selected>90 dias</option>
                <option value="180">180 dias</option>
                <option value="365">365 dias</option>
            </select>
        </label>
        <label class="wide">IPs permitidos
            <input type="text" name="ip_allowlist" maxlength="1000" placeholder="Opcional: 1.2.3.4, 5.6.7.8">
        </label>
        <div class="wide">
            <div class="api-scope-grid">
<?php foreach (IntegrationTokenService::SCOPES as $scope => $label): ?>
                <label class="api-scope"><input type="checkbox" name="scopes[]" value="<?= e($scope) ?>"> <span><?= e($label) ?></span><code><?= e($scope) ?></code></label>
<?php endforeach; ?>
            </div>
        </div>
        <div class="wide"><button class="btn primary" type="submit"><?= icon('plus') ?> Criar token</button></div>
    </form>
</section>

<section class="section card reveal">
    <div class="section-head"><h2><?= icon_badge('lock') ?> Tokens ativos</h2></div>
    <?php if (!$tokens): ?>
        <div class="empty-state"><span>Nenhum token criado.</span></div>
    <?php else: ?>
    <div class="table-wrap">
        <table class="card-table">
            <thead><tr><th>Nome</th><th>Prefixo</th><th>Permissões</th><th>Expira</th><th>Último uso</th><th></th></tr></thead>
            <tbody>
<?php foreach ($tokens as $token): ?>
<?php $activeToken = empty($token['revoked_at']) && strtotime($token['expires_at'] . ' UTC') > time(); ?>
                <tr>
                    <td data-label="Nome"><strong><?= e($token['label']) ?></strong></td>
                    <td data-label="Prefixo"><code><?= e($token['token_prefix']) ?>…</code></td>
                    <td data-label="Permissões"><span class="break-all tiny"><?= e(implode(', ', $token['scopes'])) ?></span></td>
                    <td data-label="Expira"><?= fmt_date($token['expires_at']) ?></td>
                    <td data-label="Último uso"><?= fmt_date($token['last_used_at']) ?></td>
                    <td data-label="Ação" class="td-actions">
<?php if ($activeToken): ?>
                        <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="revoke_token"><input type="hidden" name="id" value="<?= e($token['id']) ?>"><button class="btn compact danger" type="submit" data-confirm="Revogar este token?">Revogar</button></form>
<?php else: ?><span class="pill red">Inativo</span><?php endif; ?>
                    </td>
                </tr>
<?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</section>

<section class="section api-library reveal">
    <div class="section-head"><h2><?= icon_badge('terminal') ?> Biblioteca de endpoints</h2></div>
    <div class="api-endpoints">
<?php foreach ($endpoints as $endpoint): ?>
        <details class="api-endpoint">
            <summary>
                <span class="api-method api-<?= strtolower($endpoint['method']) ?>"><?= e($endpoint['method']) ?></span>
                <code><?= e($endpoint['path']) ?></code>
                <span class="pill"><?= e($endpoint['auth']) ?></span>
            </summary>
            <div class="api-endpoint-body">
                <p><?= e($endpoint['desc']) ?></p>
                <div class="api-meta"><span>Permissão</span><code><?= e($endpoint['scope']) ?></code></div>
                <?php if ($endpoint['path'] === '/api/v1/integration/keys/generate'): ?>
                <pre class="api-code">POST <?= e($base) ?>/api/v1/integration/keys/generate
X-Gustaxy-Api-Token: SEU_TOKEN
Content-Type: application/json

{"quantity":1,"max_devices":1,"amount":30,"unit":"days","prefix":"BOT"}</pre>
                <?php elseif ($endpoint['path'] === '/api/v1/integration/keys/pause' || $endpoint['path'] === '/api/v1/integration/keys/resume' || $endpoint['path'] === '/api/v1/integration/keys/revoke' || $endpoint['path'] === '/api/v1/integration/keys/reset-device' || $endpoint['path'] === '/api/v1/integration/keys/reset' || $endpoint['path'] === '/api/v1/integration/keys/delete' || $endpoint['path'] === '/api/v1/integration/keys/global-pause' || $endpoint['path'] === '/api/v1/integration/keys/global-resume'): ?>
                <pre class="api-code">POST <?= e($base) . $endpoint['path'] ?>
X-Gustaxy-Api-Token: SEU_TOKEN
Content-Type: application/json

{"id":123}</pre>
                <?php elseif ($endpoint['path'] === '/api/v1/update/publish'): ?>
                <pre class="api-code">POST <?= e($base) ?>/api/v1/update/publish
X-Gustaxy-Api-Token: SEU_TOKEN
Content-Type: application/json

{"name":"GUSTAXY PROXY","version":"2.2","version_code":16,"download_url":"https://.../GustaxyProxy.apk","sha256":"64_HEX","size_bytes":1234567}</pre>
                <?php elseif ($endpoint['path'] === '/api/v1/resources/publish'): ?>
                <pre class="api-code">POST <?= e($base) ?>/api/v1/resources/publish
X-Gustaxy-Api-Token: SEU_TOKEN
Content-Type: application/json

{"url":"https://.../gx_7c91e4a2.bin"}</pre>
                <?php elseif (str_starts_with($endpoint['path'], '/api/v1/integration/status')): ?>
                <pre class="api-code">GET <?= e($base) ?>/api/v1/integration/status
X-Gustaxy-Api-Token: SEU_TOKEN</pre>
                <?php elseif (str_starts_with($endpoint['path'], '/api/v1/integration/keys/list')): ?>
                <pre class="api-code">GET <?= e($base) ?>/api/v1/integration/keys/list
X-Gustaxy-Api-Token: SEU_TOKEN</pre>
                <?php endif; ?>
            </div>
        </details>
<?php endforeach; ?>
    </div>
    <p class="muted tiny api-note">Envie o token no header <code>X-Gustaxy-Api-Token: SEU_TOKEN</code> ou <code>Authorization: Bearer SEU_TOKEN</code>. O envio por <code>?token=</code> na URL está desativado, porque a URL aparece em logs do servidor.</p>
</section>
<?php render_footer(); ?>
