<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Reseller.php';
require dirname(__DIR__) . '/app/UserAdmin.php';
require __DIR__ . '/_layout.php';

$user = require_owner();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    $action = (string) ($_POST['action'] ?? '');

    if (!rate_limit('admin-accounts', 20, 60)) {
        $error = 'Muitas tentativas em sequência. Aguarde um instante.';
    } else {
        try {
            switch ($action) {
                case 'create_reseller':
                    Reseller::create(
                        (string) ($_POST['username'] ?? ''),
                        (string) ($_POST['password'] ?? ''),
                        (int) ($_POST['credits'] ?? 0),
                        (string) ($_POST['is_active'] ?? '1') === '1',
                        '',
                        (int) $user['id']
                    );
                    $success = 'Revendedor criado.';
                    break;

                case 'create_admin':
                    UserAdmin::createStaff(
                        (string) ($_POST['username'] ?? ''),
                        (string) ($_POST['password'] ?? ''),
                        'admin',
                        (string) ($_POST['is_active'] ?? '1') === '1',
                        (int) $user['id']
                    );
                    $success = 'Administrador criado.';
                    break;

                case 'ban':
                case 'unban':
                    $shouldActivate = $action === 'unban';
                    UserAdmin::setActive((int) ($_POST['user_id'] ?? 0), $shouldActivate, $user);
                    $success = $shouldActivate ? 'Conta desbanida.' : 'Conta banida. O acesso foi cortado imediatamente.';
                    break;

                case 'reset_password':
                    UserAdmin::resetPassword((int) ($_POST['user_id'] ?? 0), (string) ($_POST['password'] ?? ''), $user);
                    $success = 'Senha redefinida.';
                    break;

                default:
                    $error = 'Ação desconhecida.';
            }
        } catch (Throwable $exception) {
            $error = $exception instanceof InvalidArgumentException
                ? $exception->getMessage()
                : 'Não foi possível concluir a operação.';
        }
    }
}

$staff = [];
$resellers = [];
try {
    $staff = UserAdmin::listStaff();
    $resellers = Reseller::listAll();
} catch (Throwable) {
    $error = $error ?: 'Execute database/migration_resellers.sql antes de usar esta aba.';
}

$csrf = csrf_token();

function account_actions(array $row, array $viewer, string $csrf): void
{
    $id = (int) $row['id'];
    $role = (string) ($row['role'] ?? 'reseller');
    $isActive = (int) $row['is_active'] === 1;
    $isSelf = $id === (int) $viewer['id'];

    if ($role === 'owner') {
        echo '<span class="muted tiny">Conta de criador — protegida</span>';
        return;
    }
    if ($isSelf) {
        echo '<span class="muted tiny">Esta é a sua conta</span>';
        return;
    }
    ?>
    <div class="actions">
        <form method="post" class="inline-form">
            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
            <input type="hidden" name="user_id" value="<?= $id ?>">
            <input type="hidden" name="action" value="<?= $isActive ? 'ban' : 'unban' ?>">
            <button
                class="btn <?= $isActive ? 'danger' : '' ?>"
                type="submit"
                data-confirm="<?= $isActive ? 'Banir ' . e((string) $row['username']) . '? O acesso cai na hora.' : 'Liberar o acesso de ' . e((string) $row['username']) . '?' ?>">
                <?= icon($isActive ? 'lock' : 'check') ?> <?= $isActive ? 'Banir' : 'Desbanir' ?>
            </button>
        </form>
        <details class="inline-details">
            <summary class="btn"><?= icon('key') ?> Nova senha</summary>
            <div class="details-panel">
                <form method="post" class="inline-form" autocomplete="off">
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <input type="hidden" name="user_id" value="<?= $id ?>">
                    <input type="hidden" name="action" value="reset_password">
                    <input name="password" type="password" minlength="12" required placeholder="Mínimo 12 caracteres" autocomplete="new-password">
                    <button class="btn" type="submit">Salvar</button>
                </form>
            </div>
        </details>
    </div>
    <?php
}

render_header('Contas', 'resellers', $user);
?>
<header class="topbar">
    <div>
        <h1>Contas</h1>
        <p class="muted">Administradores e revendedores. Banir corta o acesso na hora, sem apagar nada: as keys já geradas e o extrato de créditos continuam no lugar.</p>
    </div>
</header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="notice success"><?= e($success) ?></p><?php endif; ?>

<section class="section card reveal">
    <div class="section-head">
        <h2><?= icon_badge('shield') ?> Criar administrador</h2>
        <p class="muted">Gera e gerencia keys, vê logs e segurança. Não acessa esta tela de contas, manutenção global nem pausa global — isso continua só com você.</p>
    </div>
    <form method="post" class="form-grid" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
        <input type="hidden" name="action" value="create_admin">
        <label>Usuário
            <input name="username" maxlength="190" required autocomplete="off">
        </label>
        <label>Senha inicial
            <input name="password" type="password" minlength="12" required autocomplete="new-password">
        </label>
        <label>Status
            <select name="is_active">
                <option value="1" selected>Ativo</option>
                <option value="0">Banido</option>
            </select>
        </label>
        <div class="wide"><button class="btn primary" type="submit"><?= icon('plus') ?> Criar administrador</button></div>
    </form>
</section>

<section class="section card reveal">
    <div class="section-head"><h2><?= icon_badge('users') ?> Administradores</h2></div>
    <div class="table-wrap">
        <table class="management-table card-table">
            <thead><tr><th>Usuário</th><th>Papel</th><th>Status</th><th>2FA</th><th>Keys</th><th>Último acesso</th><th>Ações</th></tr></thead>
            <tbody>
            <?php foreach ($staff as $row): ?>
                <tr>
                    <td data-label="Usuário"><strong><?= e((string) $row['username']) ?></strong></td>
                    <td data-label="Papel"><span class="pill"><?= e(UserAdmin::roleLabel((string) $row['role'])) ?></span></td>
                    <td data-label="Status">
                        <span class="pill <?= (int) $row['is_active'] === 1 ? 'green' : 'red' ?>">
                            <?= (int) $row['is_active'] === 1 ? 'Ativo' : 'Banido' ?>
                        </span>
                    </td>
                    <td data-label="2FA">
                        <span class="pill <?= !empty($row['totp_confirmed_at']) ? 'green' : 'yellow' ?>">
                            <?= !empty($row['totp_confirmed_at']) ? 'Ativo' : 'Sem 2FA' ?>
                        </span>
                    </td>
                    <td data-label="Keys"><?= (int) $row['keys_created'] ?></td>
                    <td data-label="Último acesso"><?= fmt_date((string) ($row['last_login_at'] ?? '')) ?></td>
                    <td data-label="Ações" class="td-stack"><?php account_actions($row, $user, $csrf); ?></td>
                </tr>
            <?php endforeach; if (!$staff): ?>
                <tr><td colspan="7">
                    <div class="empty-state">
                        <?= icon('users') ?>
                        <strong>Nenhum administrador</strong>
                        <span>Crie o primeiro no formulário acima.</span>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="section card reveal">
    <div class="section-head">
        <h2><?= icon_badge('plus') ?> Criar revendedor</h2>
        <p class="muted">Só gera key para si mesmo, gastando créditos. Sem reset, pausa, revogação ou exclusão.</p>
    </div>
    <form method="post" class="form-grid" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
        <input type="hidden" name="action" value="create_reseller">
        <label>Usuário
            <input name="username" maxlength="190" required autocomplete="off">
        </label>
        <label>Senha inicial
            <input name="password" type="password" minlength="12" required autocomplete="new-password">
        </label>
        <label>Créditos iniciais
            <input name="credits" type="number" min="0" max="1000000000" value="0" required>
        </label>
        <label>Status
            <select name="is_active">
                <option value="1" selected>Ativo</option>
                <option value="0">Banido</option>
            </select>
        </label>
        <div class="wide"><button class="btn primary" type="submit"><?= icon('plus') ?> Criar revendedor</button></div>
    </form>
</section>

<section class="section card reveal">
    <div class="section-head"><h2><?= icon_badge('wallet') ?> Revendedores cadastrados</h2></div>
    <div class="table-wrap">
        <table class="management-table card-table">
            <thead><tr><th>Usuário</th><th>Créditos</th><th>Status</th><th>Criado em</th><th>Ações</th></tr></thead>
            <tbody>
            <?php foreach ($resellers as $reseller): ?>
                <?php $reseller['role'] = 'reseller'; ?>
                <tr>
                    <td data-label="Usuário"><strong><?= e((string) $reseller['username']) ?></strong></td>
                    <td data-label="Créditos"><?= (int) $reseller['unlimited'] === 1 ? '<strong>&#8734;</strong>' : (int) $reseller['credits'] ?></td>
                    <td data-label="Status">
                        <span class="pill <?= (int) $reseller['is_active'] === 1 ? 'green' : 'red' ?>">
                            <?= (int) $reseller['is_active'] === 1 ? 'Ativo' : 'Banido' ?>
                        </span>
                    </td>
                    <td data-label="Criado em"><?= fmt_date((string) $reseller['created_at']) ?></td>
                    <td data-label="Ações" class="td-stack"><?php account_actions($reseller, $user, $csrf); ?></td>
                </tr>
            <?php endforeach; if (!$resellers): ?>
                <tr><td colspan="5">
                    <div class="empty-state">
                        <?= icon('wallet') ?>
                        <strong>Nenhum revendedor cadastrado</strong>
                        <span>Crie o primeiro no formulário acima.</span>
                    </div>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php render_footer(); ?>
