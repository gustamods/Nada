<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
// Usado pelo aviso "sua sessão expira em 2 min" para renovar a sessão ociosa.
method('POST');
if (!rate_limit('admin-keepalive', 30, 60)) {
    json_response(['ok' => false, 'error' => 'Muitas solicitações.'], 429);
}
if (!current_user()) {
    json_response(['ok' => false, 'error' => 'Sessão expirada.'], 401);
}
$token = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if ($token === '' || !hash_equals((string) ($_SESSION['csrf'] ?? ''), $token)) {
    json_response(['ok' => false, 'error' => 'Token inválido.'], 419);
}
$absolute = (int) cfg('SESSION_ABSOLUTE_TTL', 28800);
$started = (int) ($_SESSION['session_started'] ?? 0);
json_response([
    'ok' => true,
    'idle' => (int) cfg('SESSION_IDLE_TTL', 1800),
    'abs_remaining' => $started > 0 ? max(0, $absolute - (time() - $started)) : $absolute,
]);
