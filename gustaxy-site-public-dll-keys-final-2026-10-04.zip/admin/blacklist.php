<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';
require dirname(__DIR__) . '/app/Blacklist.php';
require __DIR__ . '/_layout.php';
$user = require_owner();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);
    if (!rate_limit('admin-blacklist-action', 40, 60)) {
        $error = 'Muitas ações em sequência. Aguarde um instante.';
    } else {
        try {
            $action = (string) ($_POST['action'] ?? '');
            if ($action === 'ban') {
                $deviceId = filter_var($_POST['device_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                if ($deviceId === false) {
                    throw new InvalidArgumentException('Dispositivo inválido.');
                }
                $reason = mb_substr(trim((string) ($_POST['reason'] ?? '')), 0, 255);
                Blacklist::banDevice((int) $deviceId, (int) $user['id'], $reason);
                $success = 'Dispositivo bloqueado.';
            } elseif ($action === 'unban') {
                $hash = (string) ($_POST['device_hash'] ?? '');
                Blacklist::unbanHash($hash, (int) $user['id']);
                $success = 'Dispositivo desbloqueado.';
            } else {
                throw new InvalidArgumentException('Ação inválida.');
            }
        } catch (Throwable $e) {
            $error = $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível concluir a ação.';
        }
    }
}

$blocked = Blacklist::activeList();
$devices = Blacklist::knownDevices();
render_header('Lista negra', 'blacklist', $user);
?>
<header class="topbar">
    <div>
        <h1>Lista negra</h1>
        <p class="sub">Dispositivos bloqueados pelo sistema de integridade ou manualmente pelo owner.</p>
    </div>
</header>
<?php if ($error): ?><p class="notice danger"><?= e($error) ?></p><?php endif; ?>
<?php if ($success): ?><p class="notice success"><?= e($success) ?></p><?php endif; ?>

<section class="section card reveal">
    <div class="section-head">
        <div>
            <h2><?= icon_badge('lock') ?> Dispositivos bloqueados</h2>
            <p class="muted">O bloqueio revoga os tokens ativos daquele dispositivo e impede novos logins, mesmo com uma key válida.</p>
        </div>
        <span class="pill <?= count($blocked) ? 'red' : 'green' ?>"><?= count($blocked) ?> bloqueado(s)</span>
    </div>
    <?php if (!$blocked): ?>
        <p class="muted">Nenhum dispositivo na lista negra.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="card-table">
                <thead><tr><th>Dispositivo</th><th>Device hash</th><th>Ocorrências</th><th>Keys</th><th>Origem</th><th>Motivo</th><th>Bloqueado em</th><th>Ação</th></tr></thead>
                <tbody>
                <?php foreach ($blocked as $row): ?>
                    <tr>
                        <td data-label="Dispositivo"><?= e((string) ($row['device_name'] ?: 'Desconhecido')) ?></td>
                        <td data-label="Device hash"><code><?= e(substr((string) $row['device_id_hash'], 0, 16)) ?></code></td>
                        <td data-label="Ocorrências"><?= e((string) $row['tamper_count']) ?></td>
                        <td data-label="Keys"><?= e((string) $row['key_count']) ?></td>
                        <td data-label="Origem"><span class="pill <?= $row['source'] === 'automatic' ? 'yellow' : 'red' ?>"><?= $row['source'] === 'automatic' ? 'Automático' : 'Manual' ?></span></td>
                        <td data-label="Motivo"><?= e((string) $row['reason']) ?></td>
                        <td data-label="Bloqueado em"><?= fmt_date((string) $row['banned_at']) ?></td>
                        <td data-label="Ação">
                            <form method="post">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="unban">
                                <input type="hidden" name="device_hash" value="<?= e((string) $row['device_id_hash']) ?>">
                                <button class="btn" type="submit" data-confirm="Desbloquear este dispositivo?">Desbanir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<section class="section card reveal">
    <div class="section-head">
        <div>
            <h2><?= icon_badge('devices') ?> Bloqueio manual</h2>
            <p class="muted">Selecione um dispositivo já registrado pelo servidor.</p>
        </div>
    </div>
    <?php if (!$devices): ?>
        <p class="muted">Ainda não há dispositivos elegíveis para bloqueio manual.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="card-table">
                <thead><tr><th>Dispositivo</th><th>Device hash</th><th>Versão</th><th>Android</th><th>Key</th><th>Último acesso</th><th>Ação</th></tr></thead>
                <tbody>
                <?php foreach ($devices as $row): ?>
                    <tr>
                        <td data-label="Dispositivo"><?= e((string) ($row['device_name'] ?: 'Desconhecido')) ?></td>
                        <td data-label="Device hash"><code><?= e(substr((string) $row['device_id_hash'], 0, 16)) ?></code></td>
                        <td data-label="Versão"><?= e((string) ($row['app_version'] ?: '—')) ?></td>
                        <td data-label="Android"><?= e((string) ($row['android_version'] ?: '—')) ?></td>
                        <td data-label="Key"><code><?= e((string) $row['key_prefix']) ?></code></td>
                        <td data-label="Último acesso"><?= fmt_date((string) $row['last_seen_at']) ?></td>
                        <td data-label="Ação">
                            <form method="post" class="actions">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="ban">
                                <input type="hidden" name="device_id" value="<?= e((string) $row['id']) ?>">
                                <input type="text" name="reason" maxlength="255" placeholder="Motivo (opcional)">
                                <button class="btn danger" type="submit" data-confirm="Bloquear este dispositivo?">Banir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
<?php render_footer(); ?>
