#!/usr/bin/env php
<?php

declare(strict_types=1);

/**
 * Atualiza storage/security/tor_exit_nodes.txt a partir da lista oficial
 * do Tor Project (https://check.torproject.org/torbulkexitlist).
 *
 * Uso (linha de comando ou cron, nunca pelo navegador):
 *   php scripts/update_tor_exit_list.php
 *
 * Este script é deliberadamente independente de config/bootstrap.php: ele
 * não abre sessão nem envia headers HTTP, só lê a rede e escreve um
 * arquivo — então não faz sentido herdar a inicialização pensada para
 * requisições web. Se você mudou ACCESS_GUARD_TOR_LIST_PATH em
 * config/env.php, passe o mesmo caminho aqui via variável de ambiente:
 *   GUSTAXY_TOR_LIST_PATH=/outro/caminho.txt php scripts/update_tor_exit_list.php
 *
 * Já bloqueado para acesso via navegador pelo .htaccess da raiz
 * (RewriteRule ^(?:config|app|database|storage|tests|scripts)(?:/|$) -
 * [F,L,NC]) — mas o teste de SAPI abaixo é uma segunda barreira, caso o
 * arquivo algum dia seja copiado para fora dessa estrutura.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Este script só pode ser executado via linha de comando.\n");
}

const SOURCE_URL = 'https://check.torproject.org/torbulkexitlist';

$destination = getenv('GUSTAXY_TOR_LIST_PATH') ?: (__DIR__ . '/../storage/security/tor_exit_nodes.txt');

function fetch_list(string $url): string
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => 'GustaxyTorListUpdater/1.0',
        ]);
        $body = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($body === false || $status !== 200) {
            throw new RuntimeException('Falha ao baixar a lista via cURL (HTTP ' . $status . '): ' . $error);
        }
        return (string) $body;
    }

    if (ini_get('allow_url_fopen')) {
        $context = stream_context_create(['http' => ['timeout' => 20, 'header' => "User-Agent: GustaxyTorListUpdater/1.0\r\n"]]);
        $body = @file_get_contents($url, false, $context);
        $statusLine = $http_response_header[0] ?? '';
        if ($body === false || !str_contains($statusLine, '200')) {
            throw new RuntimeException('Falha ao baixar a lista via file_get_contents: ' . $statusLine);
        }
        return $body;
    }

    throw new RuntimeException('Nem cURL nem allow_url_fopen estão disponíveis neste PHP; não é possível buscar a lista automaticamente. Baixe ' . SOURCE_URL . ' manualmente e cole o conteúdo em ' . 'storage/security/tor_exit_nodes.txt.');
}

try {
    $raw = fetch_list(SOURCE_URL);
} catch (Throwable $e) {
    fwrite(STDERR, '[update_tor_exit_list] ' . $e->getMessage() . "\n");
    exit(1);
}

$lines = preg_split('/\r\n|\r|\n/', trim($raw)) ?: [];
$ips = [];
foreach ($lines as $line) {
    $line = trim($line);
    if ($line !== '' && filter_var($line, FILTER_VALIDATE_IP)) {
        $ips[] = $line;
    }
}

if (count($ips) < 100) {
    // A lista real tem tipicamente milhares de entradas. Um número muito
    // baixo é sinal de resposta truncada/errada (ex.: página de erro) —
    // melhor não sobrescrever o arquivo atual com algo suspeito.
    fwrite(STDERR, "[update_tor_exit_list] resposta com poucos IPs válidos (" . count($ips) . "); mantendo o arquivo atual sem alterações.\n");
    exit(1);
}

$directory = dirname($destination);
if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
    fwrite(STDERR, "[update_tor_exit_list] não foi possível criar o diretório $directory\n");
    exit(1);
}

$header = "# Lista de saidas Tor - atualizado automaticamente em " . gmdate('Y-m-d H:i:s') . " UTC\n"
    . "# Fonte: " . SOURCE_URL . "\n"
    . "# " . count($ips) . " endereco(s)\n";

$tmpFile = $destination . '.tmp-' . bin2hex(random_bytes(4));
if (file_put_contents($tmpFile, $header . implode("\n", $ips) . "\n", LOCK_EX) === false) {
    fwrite(STDERR, "[update_tor_exit_list] falha ao escrever arquivo temporário\n");
    exit(1);
}
if (!rename($tmpFile, $destination)) {
    @unlink($tmpFile);
    fwrite(STDERR, "[update_tor_exit_list] falha ao mover arquivo temporário para $destination\n");
    exit(1);
}
@chmod($destination, 0600);

echo "[update_tor_exit_list] OK: " . count($ips) . " IPs gravados em $destination\n";
