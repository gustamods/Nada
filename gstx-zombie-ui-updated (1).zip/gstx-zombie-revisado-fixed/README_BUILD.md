# GSTX — revisão de integração e estabilidade

Biblioteca Android ARM64/OpenGL ES. O nome permanece `libloadgame.so` para preservar a chamada de carregamento do projeto.

## Build entregue
O `.so` foi recompilado nesta revisão com Android NDK `27.2.12479018`, C++17, ABI `arm64-v8a`, API mínima 21. O `ndk-build` terminou com código de saída `0`. O binário fica em `build/libs/arm64-v8a/libloadgame.so`; `original-bin/` contém apenas a cópia histórica anterior.

Para recompilar, na raiz do projeto:

```sh
export ANDROID_NDK_HOME=/caminho/para/android-ndk
ndk-build -C build \
  NDK_PROJECT_PATH=build \
  NDK_APPLICATION_MK=build/jni/Application.mk \
  NDK_BUILD_SCRIPT=build/jni/Android.mk \
  APP_ABI=arm64-v8a
```

## Alterações de startup nesta revisão
O hook de `GameStateComponent.Update` não é reaplicado depois que a instalação falha. As buscas de símbolos IL2CPP são refeitas se o primeiro acesso acontecer antes de `libil2cpp.so` estar carregada. Consulte `CRASH_FIX_REPORT.txt` para ressalvas.

## Limites
Não foi executado no aparelho, nem o APK foi recompilado/assinado nesta revisão. Compilação e checagem ELF não provam ausência de crash em runtime. Se o fechamento persistir, é necessário examinar logcat do dispositivo.
